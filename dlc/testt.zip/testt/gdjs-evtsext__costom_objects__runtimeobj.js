
gdjs.evtsExt__costom_objects__RuntimeObj = gdjs.evtsExt__costom_objects__RuntimeObj || {};

/**
 * Object generated from 
 */
gdjs.evtsExt__costom_objects__RuntimeObj.RuntimeObj = class RuntimeObj extends gdjs.CustomRuntimeObject2D {
  constructor(parentInstanceContainer, objectData) {
    super(parentInstanceContainer, objectData);
    this._parentInstanceContainer = parentInstanceContainer;

    this._onceTriggers = new gdjs.OnceTriggers();
    this._objectData = {};
    
    

    // It calls the onCreated super implementation at the end.
    this.onCreated();
  }

  // Hot-reload:
  updateFromObjectData(oldObjectData, newObjectData) {
    super.updateFromObjectData(oldObjectData, newObjectData);

    this.onHotReloading(this._parentInstanceContainer);
    return true;
  }

  // Properties:
  

  

  
}

// Methods:

gdjs.evtsExt__costom_objects__RuntimeObj.RuntimeObj.prototype.doStepPreEvents = function() {
  this._onceTriggers.startNewFrame();
};


gdjs.registerObject("costom_objects::RuntimeObj", gdjs.evtsExt__costom_objects__RuntimeObj.RuntimeObj);
