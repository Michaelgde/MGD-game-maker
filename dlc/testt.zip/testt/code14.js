gdjs.love2d_95lvl_95builderCode = {};
gdjs.love2d_95lvl_95builderCode.localVariables = [];
gdjs.love2d_95lvl_95builderCode.GDobjObjects1= [];
gdjs.love2d_95lvl_95builderCode.GDobjObjects2= [];
gdjs.love2d_95lvl_95builderCode.GDPenObjects1= [];
gdjs.love2d_95lvl_95builderCode.GDPenObjects2= [];
gdjs.love2d_95lvl_95builderCode.GDdebugObjects1= [];
gdjs.love2d_95lvl_95builderCode.GDdebugObjects2= [];
gdjs.love2d_95lvl_95builderCode.GDPen2Objects1= [];
gdjs.love2d_95lvl_95builderCode.GDPen2Objects2= [];


gdjs.love2d_95lvl_95builderCode.userFunc0xf23d78 = function GDJSInlineCode(runtimeScene) {
"use strict";
console.log(runtimeScene._objects.items)

};
gdjs.love2d_95lvl_95builderCode.eventsList0 = function(runtimeScene) {

{


gdjs.love2d_95lvl_95builderCode.userFunc0xf23d78(runtimeScene);

}


};gdjs.love2d_95lvl_95builderCode.eventsList1 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("debug"), gdjs.love2d_95lvl_95builderCode.GDdebugObjects1);
{for(var i = 0, len = gdjs.love2d_95lvl_95builderCode.GDdebugObjects1.length ;i < len;++i) {
    gdjs.love2d_95lvl_95builderCode.GDdebugObjects1[i].getBehavior("Text").setText("cam position" + runtimeScene.getScene().getVariables().getFromIndex(1).getAsString() + " , " + runtimeScene.getScene().getVariables().getFromIndex(2).getAsString() + " , " + runtimeScene.getScene().getVariables().getFromIndex(3).getAsString());
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22624348);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.love2d_95lvl_95builderCode.eventsList0(runtimeScene);} //End of subevents
}

}


{



}


{



}


{



}


{



}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(5).add(0.1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(5).sub(0.1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(4).add(0.1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(4).sub(0.1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(1).add(1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(3).add(10);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(3).sub(10);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(1).sub(1);
}}

}


{



}


{



}


};

gdjs.love2d_95lvl_95builderCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.love2d_95lvl_95builderCode.GDobjObjects1.length = 0;
gdjs.love2d_95lvl_95builderCode.GDobjObjects2.length = 0;
gdjs.love2d_95lvl_95builderCode.GDPenObjects1.length = 0;
gdjs.love2d_95lvl_95builderCode.GDPenObjects2.length = 0;
gdjs.love2d_95lvl_95builderCode.GDdebugObjects1.length = 0;
gdjs.love2d_95lvl_95builderCode.GDdebugObjects2.length = 0;
gdjs.love2d_95lvl_95builderCode.GDPen2Objects1.length = 0;
gdjs.love2d_95lvl_95builderCode.GDPen2Objects2.length = 0;

gdjs.love2d_95lvl_95builderCode.eventsList1(runtimeScene);
gdjs.love2d_95lvl_95builderCode.GDobjObjects1.length = 0;
gdjs.love2d_95lvl_95builderCode.GDobjObjects2.length = 0;
gdjs.love2d_95lvl_95builderCode.GDPenObjects1.length = 0;
gdjs.love2d_95lvl_95builderCode.GDPenObjects2.length = 0;
gdjs.love2d_95lvl_95builderCode.GDdebugObjects1.length = 0;
gdjs.love2d_95lvl_95builderCode.GDdebugObjects2.length = 0;
gdjs.love2d_95lvl_95builderCode.GDPen2Objects1.length = 0;
gdjs.love2d_95lvl_95builderCode.GDPen2Objects2.length = 0;


return;

}

gdjs['love2d_95lvl_95builderCode'] = gdjs.love2d_95lvl_95builderCode;
