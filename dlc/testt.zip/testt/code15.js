gdjs.collEditorCode = {};
gdjs.collEditorCode.localVariables = [];
gdjs.collEditorCode.GDobjObjects1= [];
gdjs.collEditorCode.GDobjObjects2= [];
gdjs.collEditorCode.GDobjObjects3= [];
gdjs.collEditorCode.GDNewPanelSpriteObjects1= [];
gdjs.collEditorCode.GDNewPanelSpriteObjects2= [];
gdjs.collEditorCode.GDNewPanelSpriteObjects3= [];
gdjs.collEditorCode.GDWidthObjects1= [];
gdjs.collEditorCode.GDWidthObjects2= [];
gdjs.collEditorCode.GDWidthObjects3= [];
gdjs.collEditorCode.GDHeightObjects1= [];
gdjs.collEditorCode.GDHeightObjects2= [];
gdjs.collEditorCode.GDHeightObjects3= [];
gdjs.collEditorCode.GDdrawObjects1= [];
gdjs.collEditorCode.GDdrawObjects2= [];
gdjs.collEditorCode.GDdrawObjects3= [];
gdjs.collEditorCode.GDpoint1Objects1= [];
gdjs.collEditorCode.GDpoint1Objects2= [];
gdjs.collEditorCode.GDpoint1Objects3= [];
gdjs.collEditorCode.GDpoint2Objects1= [];
gdjs.collEditorCode.GDpoint2Objects2= [];
gdjs.collEditorCode.GDpoint2Objects3= [];
gdjs.collEditorCode.GDpoint3Objects1= [];
gdjs.collEditorCode.GDpoint3Objects2= [];
gdjs.collEditorCode.GDpoint3Objects3= [];
gdjs.collEditorCode.GDpoint4Objects1= [];
gdjs.collEditorCode.GDpoint4Objects2= [];
gdjs.collEditorCode.GDpoint4Objects3= [];


gdjs.collEditorCode.mapOfGDgdjs_9546collEditorCode_9546GDobjObjects1Objects = Hashtable.newFrom({"obj": gdjs.collEditorCode.GDobjObjects1});
gdjs.collEditorCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NewPanelSprite"), gdjs.collEditorCode.GDNewPanelSpriteObjects2);
gdjs.copyArray(gdjs.collEditorCode.GDobjObjects1, gdjs.collEditorCode.GDobjObjects2);

{for(var i = 0, len = gdjs.collEditorCode.GDNewPanelSpriteObjects2.length ;i < len;++i) {
    gdjs.collEditorCode.GDNewPanelSpriteObjects2[i].setPosition((( gdjs.collEditorCode.GDobjObjects2.length === 0 ) ? 0 :gdjs.collEditorCode.GDobjObjects2[0].getPointX("")),(( gdjs.collEditorCode.GDobjObjects2.length === 0 ) ? 0 :gdjs.collEditorCode.GDobjObjects2[0].getPointY("")));
}
}{for(var i = 0, len = gdjs.collEditorCode.GDNewPanelSpriteObjects2.length ;i < len;++i) {
    gdjs.collEditorCode.GDNewPanelSpriteObjects2[i].getBehavior("Resizable").setSize(runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber());
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Height"), gdjs.collEditorCode.GDHeightObjects1);
gdjs.copyArray(runtimeScene.getObjects("Width"), gdjs.collEditorCode.GDWidthObjects1);
gdjs.copyArray(runtimeScene.getObjects("point1"), gdjs.collEditorCode.GDpoint1Objects1);
gdjs.copyArray(runtimeScene.getObjects("point2"), gdjs.collEditorCode.GDpoint2Objects1);
gdjs.copyArray(runtimeScene.getObjects("point3"), gdjs.collEditorCode.GDpoint3Objects1);
gdjs.copyArray(runtimeScene.getObjects("point4"), gdjs.collEditorCode.GDpoint4Objects1);
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(gdjs.evtTools.common.toNumber((( gdjs.collEditorCode.GDWidthObjects1.length === 0 ) ? "" :gdjs.collEditorCode.GDWidthObjects1[0].getBehavior("Text").getText())));
}{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(gdjs.evtTools.common.toNumber((( gdjs.collEditorCode.GDHeightObjects1.length === 0 ) ? "" :gdjs.collEditorCode.GDHeightObjects1[0].getBehavior("Text").getText())));
}{runtimeScene.getGame().getVariables().getFromIndex(6).getChild(runtimeScene.getGame().getVariables().getFromIndex(5).getAsString()).getChild("width").setNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber());
}{runtimeScene.getGame().getVariables().getFromIndex(6).getChild(runtimeScene.getGame().getVariables().getFromIndex(5).getAsString()).getChild("height").setNumber(runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber());
}{runtimeScene.getGame().getVariables().getFromIndex(6).getChild(runtimeScene.getGame().getVariables().getFromIndex(5).getAsString()).getChild("p1").getChild("x").setNumber((( gdjs.collEditorCode.GDpoint1Objects1.length === 0 ) ? 0 :gdjs.collEditorCode.GDpoint1Objects1[0].getPointX("")));
}{runtimeScene.getGame().getVariables().getFromIndex(6).getChild(runtimeScene.getGame().getVariables().getFromIndex(5).getAsString()).getChild("p1").getChild("y").setNumber((( gdjs.collEditorCode.GDpoint1Objects1.length === 0 ) ? 0 :gdjs.collEditorCode.GDpoint1Objects1[0].getPointY("")));
}{runtimeScene.getGame().getVariables().getFromIndex(6).getChild(runtimeScene.getGame().getVariables().getFromIndex(5).getAsString()).getChild("p2").getChild("x").setNumber((( gdjs.collEditorCode.GDpoint2Objects1.length === 0 ) ? 0 :gdjs.collEditorCode.GDpoint2Objects1[0].getPointX("")));
}{runtimeScene.getGame().getVariables().getFromIndex(6).getChild(runtimeScene.getGame().getVariables().getFromIndex(5).getAsString()).getChild("p2").getChild("y").setNumber((( gdjs.collEditorCode.GDpoint2Objects1.length === 0 ) ? 0 :gdjs.collEditorCode.GDpoint2Objects1[0].getPointY("")));
}{runtimeScene.getGame().getVariables().getFromIndex(6).getChild(runtimeScene.getGame().getVariables().getFromIndex(5).getAsString()).getChild("p3").getChild("x").setNumber((( gdjs.collEditorCode.GDpoint3Objects1.length === 0 ) ? 0 :gdjs.collEditorCode.GDpoint3Objects1[0].getPointX("")));
}{runtimeScene.getGame().getVariables().getFromIndex(6).getChild(runtimeScene.getGame().getVariables().getFromIndex(5).getAsString()).getChild("p3").getChild("y").setNumber((( gdjs.collEditorCode.GDpoint3Objects1.length === 0 ) ? 0 :gdjs.collEditorCode.GDpoint3Objects1[0].getPointY("")));
}{runtimeScene.getGame().getVariables().getFromIndex(6).getChild(runtimeScene.getGame().getVariables().getFromIndex(5).getAsString()).getChild("p4").getChild("x").setNumber((( gdjs.collEditorCode.GDpoint4Objects1.length === 0 ) ? 0 :gdjs.collEditorCode.GDpoint4Objects1[0].getPointX("")));
}{runtimeScene.getGame().getVariables().getFromIndex(6).getChild(runtimeScene.getGame().getVariables().getFromIndex(5).getAsString()).getChild("p4").getChild("y").setNumber((( gdjs.collEditorCode.GDpoint4Objects1.length === 0 ) ? 0 :gdjs.collEditorCode.GDpoint4Objects1[0].getPointY("")));
}}

}


};gdjs.collEditorCode.userFunc0x11fae90 = function GDJSInlineCode(runtimeScene) {
"use strict";
var image = new Image()
image.src = runtimeScene.getGame().getVariables().get('ps').getAsString()
console.log('width '+image.width+' height '+image.height)

};
gdjs.collEditorCode.eventsList1 = function(runtimeScene) {

{


gdjs.collEditorCode.userFunc0x11fae90(runtimeScene);

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.collEditorCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("obj"), gdjs.collEditorCode.GDobjObjects1);
{gdjs.evtsExt__LoadImageFromURL__LoadURLIntoSprite.func(runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(3).getAsString(), gdjs.collEditorCode.mapOfGDgdjs_9546collEditorCode_9546GDobjObjects1Objects, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.collEditorCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Height"), gdjs.collEditorCode.GDHeightObjects1);
gdjs.copyArray(runtimeScene.getObjects("Width"), gdjs.collEditorCode.GDWidthObjects1);
{for(var i = 0, len = gdjs.collEditorCode.GDWidthObjects1.length ;i < len;++i) {
    gdjs.collEditorCode.GDWidthObjects1[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(0).getAsString());
}
}{for(var i = 0, len = gdjs.collEditorCode.GDHeightObjects1.length ;i < len;++i) {
    gdjs.collEditorCode.GDHeightObjects1[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(1).getAsString());
}
}
{ //Subevents
gdjs.collEditorCode.eventsList1(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("draw"), gdjs.collEditorCode.GDdrawObjects1);
gdjs.copyArray(runtimeScene.getObjects("point1"), gdjs.collEditorCode.GDpoint1Objects1);
gdjs.copyArray(runtimeScene.getObjects("point2"), gdjs.collEditorCode.GDpoint2Objects1);
gdjs.copyArray(runtimeScene.getObjects("point3"), gdjs.collEditorCode.GDpoint3Objects1);
gdjs.copyArray(runtimeScene.getObjects("point4"), gdjs.collEditorCode.GDpoint4Objects1);
{for(var i = 0, len = gdjs.collEditorCode.GDdrawObjects1.length ;i < len;++i) {
    gdjs.collEditorCode.GDdrawObjects1[i].drawLineV2((( gdjs.collEditorCode.GDpoint1Objects1.length === 0 ) ? 0 :gdjs.collEditorCode.GDpoint1Objects1[0].getPointX("")), (( gdjs.collEditorCode.GDpoint1Objects1.length === 0 ) ? 0 :gdjs.collEditorCode.GDpoint1Objects1[0].getPointY("")), (( gdjs.collEditorCode.GDpoint2Objects1.length === 0 ) ? 0 :gdjs.collEditorCode.GDpoint2Objects1[0].getPointX("")), (( gdjs.collEditorCode.GDpoint2Objects1.length === 0 ) ? 0 :gdjs.collEditorCode.GDpoint2Objects1[0].getPointY("")), 1);
}
}{for(var i = 0, len = gdjs.collEditorCode.GDdrawObjects1.length ;i < len;++i) {
    gdjs.collEditorCode.GDdrawObjects1[i].drawLineV2((( gdjs.collEditorCode.GDpoint3Objects1.length === 0 ) ? 0 :gdjs.collEditorCode.GDpoint3Objects1[0].getPointX("")), (( gdjs.collEditorCode.GDpoint3Objects1.length === 0 ) ? 0 :gdjs.collEditorCode.GDpoint3Objects1[0].getPointY("")), (( gdjs.collEditorCode.GDpoint4Objects1.length === 0 ) ? 0 :gdjs.collEditorCode.GDpoint4Objects1[0].getPointX("")), (( gdjs.collEditorCode.GDpoint4Objects1.length === 0 ) ? 0 :gdjs.collEditorCode.GDpoint4Objects1[0].getPointY("")), 1);
}
}{for(var i = 0, len = gdjs.collEditorCode.GDdrawObjects1.length ;i < len;++i) {
    gdjs.collEditorCode.GDdrawObjects1[i].drawLineV2((( gdjs.collEditorCode.GDpoint1Objects1.length === 0 ) ? 0 :gdjs.collEditorCode.GDpoint1Objects1[0].getPointX("")), (( gdjs.collEditorCode.GDpoint1Objects1.length === 0 ) ? 0 :gdjs.collEditorCode.GDpoint1Objects1[0].getPointY("")), (( gdjs.collEditorCode.GDpoint3Objects1.length === 0 ) ? 0 :gdjs.collEditorCode.GDpoint3Objects1[0].getPointX("")), (( gdjs.collEditorCode.GDpoint3Objects1.length === 0 ) ? 0 :gdjs.collEditorCode.GDpoint3Objects1[0].getPointY("")), 1);
}
}{for(var i = 0, len = gdjs.collEditorCode.GDdrawObjects1.length ;i < len;++i) {
    gdjs.collEditorCode.GDdrawObjects1[i].drawLineV2((( gdjs.collEditorCode.GDpoint2Objects1.length === 0 ) ? 0 :gdjs.collEditorCode.GDpoint2Objects1[0].getPointX("")), (( gdjs.collEditorCode.GDpoint2Objects1.length === 0 ) ? 0 :gdjs.collEditorCode.GDpoint2Objects1[0].getPointY("")), (( gdjs.collEditorCode.GDpoint4Objects1.length === 0 ) ? 0 :gdjs.collEditorCode.GDpoint4Objects1[0].getPointX("")), (( gdjs.collEditorCode.GDpoint4Objects1.length === 0 ) ? 0 :gdjs.collEditorCode.GDpoint4Objects1[0].getPointY("")), 1);
}
}}

}


};

gdjs.collEditorCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.collEditorCode.GDobjObjects1.length = 0;
gdjs.collEditorCode.GDobjObjects2.length = 0;
gdjs.collEditorCode.GDobjObjects3.length = 0;
gdjs.collEditorCode.GDNewPanelSpriteObjects1.length = 0;
gdjs.collEditorCode.GDNewPanelSpriteObjects2.length = 0;
gdjs.collEditorCode.GDNewPanelSpriteObjects3.length = 0;
gdjs.collEditorCode.GDWidthObjects1.length = 0;
gdjs.collEditorCode.GDWidthObjects2.length = 0;
gdjs.collEditorCode.GDWidthObjects3.length = 0;
gdjs.collEditorCode.GDHeightObjects1.length = 0;
gdjs.collEditorCode.GDHeightObjects2.length = 0;
gdjs.collEditorCode.GDHeightObjects3.length = 0;
gdjs.collEditorCode.GDdrawObjects1.length = 0;
gdjs.collEditorCode.GDdrawObjects2.length = 0;
gdjs.collEditorCode.GDdrawObjects3.length = 0;
gdjs.collEditorCode.GDpoint1Objects1.length = 0;
gdjs.collEditorCode.GDpoint1Objects2.length = 0;
gdjs.collEditorCode.GDpoint1Objects3.length = 0;
gdjs.collEditorCode.GDpoint2Objects1.length = 0;
gdjs.collEditorCode.GDpoint2Objects2.length = 0;
gdjs.collEditorCode.GDpoint2Objects3.length = 0;
gdjs.collEditorCode.GDpoint3Objects1.length = 0;
gdjs.collEditorCode.GDpoint3Objects2.length = 0;
gdjs.collEditorCode.GDpoint3Objects3.length = 0;
gdjs.collEditorCode.GDpoint4Objects1.length = 0;
gdjs.collEditorCode.GDpoint4Objects2.length = 0;
gdjs.collEditorCode.GDpoint4Objects3.length = 0;

gdjs.collEditorCode.eventsList2(runtimeScene);
gdjs.collEditorCode.GDobjObjects1.length = 0;
gdjs.collEditorCode.GDobjObjects2.length = 0;
gdjs.collEditorCode.GDobjObjects3.length = 0;
gdjs.collEditorCode.GDNewPanelSpriteObjects1.length = 0;
gdjs.collEditorCode.GDNewPanelSpriteObjects2.length = 0;
gdjs.collEditorCode.GDNewPanelSpriteObjects3.length = 0;
gdjs.collEditorCode.GDWidthObjects1.length = 0;
gdjs.collEditorCode.GDWidthObjects2.length = 0;
gdjs.collEditorCode.GDWidthObjects3.length = 0;
gdjs.collEditorCode.GDHeightObjects1.length = 0;
gdjs.collEditorCode.GDHeightObjects2.length = 0;
gdjs.collEditorCode.GDHeightObjects3.length = 0;
gdjs.collEditorCode.GDdrawObjects1.length = 0;
gdjs.collEditorCode.GDdrawObjects2.length = 0;
gdjs.collEditorCode.GDdrawObjects3.length = 0;
gdjs.collEditorCode.GDpoint1Objects1.length = 0;
gdjs.collEditorCode.GDpoint1Objects2.length = 0;
gdjs.collEditorCode.GDpoint1Objects3.length = 0;
gdjs.collEditorCode.GDpoint2Objects1.length = 0;
gdjs.collEditorCode.GDpoint2Objects2.length = 0;
gdjs.collEditorCode.GDpoint2Objects3.length = 0;
gdjs.collEditorCode.GDpoint3Objects1.length = 0;
gdjs.collEditorCode.GDpoint3Objects2.length = 0;
gdjs.collEditorCode.GDpoint3Objects3.length = 0;
gdjs.collEditorCode.GDpoint4Objects1.length = 0;
gdjs.collEditorCode.GDpoint4Objects2.length = 0;
gdjs.collEditorCode.GDpoint4Objects3.length = 0;


return;

}

gdjs['collEditorCode'] = gdjs.collEditorCode;
