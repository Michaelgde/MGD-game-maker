gdjs.startCode = {};
gdjs.startCode.localVariables = [];
gdjs.startCode.GDselect_9595gameObjects1= [];
gdjs.startCode.GDselect_9595gameObjects2= [];
gdjs.startCode.GDselect_9595gameObjects3= [];
gdjs.startCode.GDNewSpriteObjects1= [];
gdjs.startCode.GDNewSpriteObjects2= [];
gdjs.startCode.GDNewSpriteObjects3= [];
gdjs.startCode.GDopen_9595projectObjects1= [];
gdjs.startCode.GDopen_9595projectObjects2= [];
gdjs.startCode.GDopen_9595projectObjects3= [];
gdjs.startCode.GDimport_9595projectObjects1= [];
gdjs.startCode.GDimport_9595projectObjects2= [];
gdjs.startCode.GDimport_9595projectObjects3= [];
gdjs.startCode.GDspriteObjects1= [];
gdjs.startCode.GDspriteObjects2= [];
gdjs.startCode.GDspriteObjects3= [];
gdjs.startCode.GDnew_9595projectObjects1= [];
gdjs.startCode.GDnew_9595projectObjects2= [];
gdjs.startCode.GDnew_9595projectObjects3= [];
gdjs.startCode.GDadvicorObjects1= [];
gdjs.startCode.GDadvicorObjects2= [];
gdjs.startCode.GDadvicorObjects3= [];
gdjs.startCode.GDselect_9595game2Objects1= [];
gdjs.startCode.GDselect_9595game2Objects2= [];
gdjs.startCode.GDselect_9595game2Objects3= [];
gdjs.startCode.GDessentialsObjects1= [];
gdjs.startCode.GDessentialsObjects2= [];
gdjs.startCode.GDessentialsObjects3= [];
gdjs.startCode.GDtutObjects1= [];
gdjs.startCode.GDtutObjects2= [];
gdjs.startCode.GDtutObjects3= [];


gdjs.startCode.mapOfGDgdjs_9546startCode_9546GDspriteObjects1Objects = Hashtable.newFrom({"sprite": gdjs.startCode.GDspriteObjects1});
gdjs.startCode.mapOfGDgdjs_9546startCode_9546GDspriteObjects1Objects = Hashtable.newFrom({"sprite": gdjs.startCode.GDspriteObjects1});
gdjs.startCode.mapOfGDgdjs_9546startCode_9546GDopen_95959595projectObjects1Objects = Hashtable.newFrom({"open_project": gdjs.startCode.GDopen_9595projectObjects1});
gdjs.startCode.mapOfGDgdjs_9546startCode_9546GDnew_95959595projectObjects1Objects = Hashtable.newFrom({"new_project": gdjs.startCode.GDnew_9595projectObjects1});
gdjs.startCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "scene2", false);
}}

}


};gdjs.startCode.mapOfGDgdjs_9546startCode_9546GDimport_95959595projectObjects1Objects = Hashtable.newFrom({"import_project": gdjs.startCode.GDimport_9595projectObjects1});
gdjs.startCode.eventsList1 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "scene2", false);
}}

}


};gdjs.startCode.asyncCallback21913252 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.startCode.localVariables);

{ //Subevents
gdjs.startCode.eventsList1(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.startCode.localVariables.length = 0;
}
gdjs.startCode.eventsList2 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.startCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.startCode.asyncCallback21913252(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.startCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("sprite"), gdjs.startCode.GDspriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.startCode.mapOfGDgdjs_9546startCode_9546GDspriteObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
/* Reuse gdjs.startCode.GDspriteObjects1 */
{for(var i = 0, len = gdjs.startCode.GDspriteObjects1.length ;i < len;++i) {
    gdjs.startCode.GDspriteObjects1[i].getBehavior("Effect").setEffectStringParameter("Effect", "newColor", "58;58;58");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("sprite"), gdjs.startCode.GDspriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.startCode.mapOfGDgdjs_9546startCode_9546GDspriteObjects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
/* Reuse gdjs.startCode.GDspriteObjects1 */
{for(var i = 0, len = gdjs.startCode.GDspriteObjects1.length ;i < len;++i) {
    gdjs.startCode.GDspriteObjects1[i].getBehavior("Effect").setEffectStringParameter("Effect", "newColor", "0;0;0");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("open_project"), gdjs.startCode.GDopen_9595projectObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.startCode.mapOfGDgdjs_9546startCode_9546GDopen_95959595projectObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(21909444);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "scene2", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("new_project"), gdjs.startCode.GDnew_9595projectObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.startCode.mapOfGDgdjs_9546startCode_9546GDnew_95959595projectObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(21910444);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(12).setBoolean(true);
}
{ //Subevents
gdjs.startCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("import_project"), gdjs.startCode.GDimport_9595projectObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.startCode.mapOfGDgdjs_9546startCode_9546GDimport_95959595projectObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(21911948);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtsExt__UploadDownloadTextFile__UploadTextFile.func(runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(0), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__UploadDownloadTextFile__UploadFinished.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(21913036);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.network.jsonToVariableStructure(runtimeScene.getScene().getVariables().getFromIndex(0).getAsString(), runtimeScene.getGame().getVariables().getFromIndex(13));
}{runtimeScene.getGame().getVariables().getFromIndex(12).setBoolean(true);
}
{ //Subevents
gdjs.startCode.eventsList2(runtimeScene);} //End of subevents
}

}


};

gdjs.startCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.startCode.GDselect_9595gameObjects1.length = 0;
gdjs.startCode.GDselect_9595gameObjects2.length = 0;
gdjs.startCode.GDselect_9595gameObjects3.length = 0;
gdjs.startCode.GDNewSpriteObjects1.length = 0;
gdjs.startCode.GDNewSpriteObjects2.length = 0;
gdjs.startCode.GDNewSpriteObjects3.length = 0;
gdjs.startCode.GDopen_9595projectObjects1.length = 0;
gdjs.startCode.GDopen_9595projectObjects2.length = 0;
gdjs.startCode.GDopen_9595projectObjects3.length = 0;
gdjs.startCode.GDimport_9595projectObjects1.length = 0;
gdjs.startCode.GDimport_9595projectObjects2.length = 0;
gdjs.startCode.GDimport_9595projectObjects3.length = 0;
gdjs.startCode.GDspriteObjects1.length = 0;
gdjs.startCode.GDspriteObjects2.length = 0;
gdjs.startCode.GDspriteObjects3.length = 0;
gdjs.startCode.GDnew_9595projectObjects1.length = 0;
gdjs.startCode.GDnew_9595projectObjects2.length = 0;
gdjs.startCode.GDnew_9595projectObjects3.length = 0;
gdjs.startCode.GDadvicorObjects1.length = 0;
gdjs.startCode.GDadvicorObjects2.length = 0;
gdjs.startCode.GDadvicorObjects3.length = 0;
gdjs.startCode.GDselect_9595game2Objects1.length = 0;
gdjs.startCode.GDselect_9595game2Objects2.length = 0;
gdjs.startCode.GDselect_9595game2Objects3.length = 0;
gdjs.startCode.GDessentialsObjects1.length = 0;
gdjs.startCode.GDessentialsObjects2.length = 0;
gdjs.startCode.GDessentialsObjects3.length = 0;
gdjs.startCode.GDtutObjects1.length = 0;
gdjs.startCode.GDtutObjects2.length = 0;
gdjs.startCode.GDtutObjects3.length = 0;

gdjs.startCode.eventsList3(runtimeScene);
gdjs.startCode.GDselect_9595gameObjects1.length = 0;
gdjs.startCode.GDselect_9595gameObjects2.length = 0;
gdjs.startCode.GDselect_9595gameObjects3.length = 0;
gdjs.startCode.GDNewSpriteObjects1.length = 0;
gdjs.startCode.GDNewSpriteObjects2.length = 0;
gdjs.startCode.GDNewSpriteObjects3.length = 0;
gdjs.startCode.GDopen_9595projectObjects1.length = 0;
gdjs.startCode.GDopen_9595projectObjects2.length = 0;
gdjs.startCode.GDopen_9595projectObjects3.length = 0;
gdjs.startCode.GDimport_9595projectObjects1.length = 0;
gdjs.startCode.GDimport_9595projectObjects2.length = 0;
gdjs.startCode.GDimport_9595projectObjects3.length = 0;
gdjs.startCode.GDspriteObjects1.length = 0;
gdjs.startCode.GDspriteObjects2.length = 0;
gdjs.startCode.GDspriteObjects3.length = 0;
gdjs.startCode.GDnew_9595projectObjects1.length = 0;
gdjs.startCode.GDnew_9595projectObjects2.length = 0;
gdjs.startCode.GDnew_9595projectObjects3.length = 0;
gdjs.startCode.GDadvicorObjects1.length = 0;
gdjs.startCode.GDadvicorObjects2.length = 0;
gdjs.startCode.GDadvicorObjects3.length = 0;
gdjs.startCode.GDselect_9595game2Objects1.length = 0;
gdjs.startCode.GDselect_9595game2Objects2.length = 0;
gdjs.startCode.GDselect_9595game2Objects3.length = 0;
gdjs.startCode.GDessentialsObjects1.length = 0;
gdjs.startCode.GDessentialsObjects2.length = 0;
gdjs.startCode.GDessentialsObjects3.length = 0;
gdjs.startCode.GDtutObjects1.length = 0;
gdjs.startCode.GDtutObjects2.length = 0;
gdjs.startCode.GDtutObjects3.length = 0;


return;

}

gdjs['startCode'] = gdjs.startCode;
