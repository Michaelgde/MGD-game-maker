gdjs.scene2Code = {};
gdjs.scene2Code.localVariables = [];
gdjs.scene2Code.GDsaveObjects1_1final = [];

gdjs.scene2Code.forEachIndex2 = 0;

gdjs.scene2Code.forEachIndex3 = 0;

gdjs.scene2Code.forEachObjects2 = [];

gdjs.scene2Code.forEachObjects3 = [];

gdjs.scene2Code.forEachTemporary2 = null;

gdjs.scene2Code.forEachTemporary3 = null;

gdjs.scene2Code.forEachTotalCount2 = 0;

gdjs.scene2Code.forEachTotalCount3 = 0;

gdjs.scene2Code.GDspriteObjects1= [];
gdjs.scene2Code.GDspriteObjects2= [];
gdjs.scene2Code.GDspriteObjects3= [];
gdjs.scene2Code.GDspriteObjects4= [];
gdjs.scene2Code.GDspriteObjects5= [];
gdjs.scene2Code.GDspriteObjects6= [];
gdjs.scene2Code.GDspriteObjects7= [];
gdjs.scene2Code.GDspriteObjects8= [];
gdjs.scene2Code.GDspriteObjects9= [];
gdjs.scene2Code.GDspriteObjects10= [];
gdjs.scene2Code.GDdebugObjects1= [];
gdjs.scene2Code.GDdebugObjects2= [];
gdjs.scene2Code.GDdebugObjects3= [];
gdjs.scene2Code.GDdebugObjects4= [];
gdjs.scene2Code.GDdebugObjects5= [];
gdjs.scene2Code.GDdebugObjects6= [];
gdjs.scene2Code.GDdebugObjects7= [];
gdjs.scene2Code.GDdebugObjects8= [];
gdjs.scene2Code.GDdebugObjects9= [];
gdjs.scene2Code.GDdebugObjects10= [];
gdjs.scene2Code.GDdialougObjects1= [];
gdjs.scene2Code.GDdialougObjects2= [];
gdjs.scene2Code.GDdialougObjects3= [];
gdjs.scene2Code.GDdialougObjects4= [];
gdjs.scene2Code.GDdialougObjects5= [];
gdjs.scene2Code.GDdialougObjects6= [];
gdjs.scene2Code.GDdialougObjects7= [];
gdjs.scene2Code.GDdialougObjects8= [];
gdjs.scene2Code.GDdialougObjects9= [];
gdjs.scene2Code.GDdialougObjects10= [];
gdjs.scene2Code.GDobject_9595var_9595inputObjects1= [];
gdjs.scene2Code.GDobject_9595var_9595inputObjects2= [];
gdjs.scene2Code.GDobject_9595var_9595inputObjects3= [];
gdjs.scene2Code.GDobject_9595var_9595inputObjects4= [];
gdjs.scene2Code.GDobject_9595var_9595inputObjects5= [];
gdjs.scene2Code.GDobject_9595var_9595inputObjects6= [];
gdjs.scene2Code.GDobject_9595var_9595inputObjects7= [];
gdjs.scene2Code.GDobject_9595var_9595inputObjects8= [];
gdjs.scene2Code.GDobject_9595var_9595inputObjects9= [];
gdjs.scene2Code.GDobject_9595var_9595inputObjects10= [];
gdjs.scene2Code.GDobjectNamesObjects1= [];
gdjs.scene2Code.GDobjectNamesObjects2= [];
gdjs.scene2Code.GDobjectNamesObjects3= [];
gdjs.scene2Code.GDobjectNamesObjects4= [];
gdjs.scene2Code.GDobjectNamesObjects5= [];
gdjs.scene2Code.GDobjectNamesObjects6= [];
gdjs.scene2Code.GDobjectNamesObjects7= [];
gdjs.scene2Code.GDobjectNamesObjects8= [];
gdjs.scene2Code.GDobjectNamesObjects9= [];
gdjs.scene2Code.GDobjectNamesObjects10= [];
gdjs.scene2Code.GDobjectNameObjects1= [];
gdjs.scene2Code.GDobjectNameObjects2= [];
gdjs.scene2Code.GDobjectNameObjects3= [];
gdjs.scene2Code.GDobjectNameObjects4= [];
gdjs.scene2Code.GDobjectNameObjects5= [];
gdjs.scene2Code.GDobjectNameObjects6= [];
gdjs.scene2Code.GDobjectNameObjects7= [];
gdjs.scene2Code.GDobjectNameObjects8= [];
gdjs.scene2Code.GDobjectNameObjects9= [];
gdjs.scene2Code.GDobjectNameObjects10= [];
gdjs.scene2Code.GDdragNdropObjects1= [];
gdjs.scene2Code.GDdragNdropObjects2= [];
gdjs.scene2Code.GDdragNdropObjects3= [];
gdjs.scene2Code.GDdragNdropObjects4= [];
gdjs.scene2Code.GDdragNdropObjects5= [];
gdjs.scene2Code.GDdragNdropObjects6= [];
gdjs.scene2Code.GDdragNdropObjects7= [];
gdjs.scene2Code.GDdragNdropObjects8= [];
gdjs.scene2Code.GDdragNdropObjects9= [];
gdjs.scene2Code.GDdragNdropObjects10= [];
gdjs.scene2Code.GDobj_9595scpObjects1= [];
gdjs.scene2Code.GDobj_9595scpObjects2= [];
gdjs.scene2Code.GDobj_9595scpObjects3= [];
gdjs.scene2Code.GDobj_9595scpObjects4= [];
gdjs.scene2Code.GDobj_9595scpObjects5= [];
gdjs.scene2Code.GDobj_9595scpObjects6= [];
gdjs.scene2Code.GDobj_9595scpObjects7= [];
gdjs.scene2Code.GDobj_9595scpObjects8= [];
gdjs.scene2Code.GDobj_9595scpObjects9= [];
gdjs.scene2Code.GDobj_9595scpObjects10= [];
gdjs.scene2Code.GDobjectName2Objects1= [];
gdjs.scene2Code.GDobjectName2Objects2= [];
gdjs.scene2Code.GDobjectName2Objects3= [];
gdjs.scene2Code.GDobjectName2Objects4= [];
gdjs.scene2Code.GDobjectName2Objects5= [];
gdjs.scene2Code.GDobjectName2Objects6= [];
gdjs.scene2Code.GDobjectName2Objects7= [];
gdjs.scene2Code.GDobjectName2Objects8= [];
gdjs.scene2Code.GDobjectName2Objects9= [];
gdjs.scene2Code.GDobjectName2Objects10= [];
gdjs.scene2Code.GDfake_9595cuObjects1= [];
gdjs.scene2Code.GDfake_9595cuObjects2= [];
gdjs.scene2Code.GDfake_9595cuObjects3= [];
gdjs.scene2Code.GDfake_9595cuObjects4= [];
gdjs.scene2Code.GDfake_9595cuObjects5= [];
gdjs.scene2Code.GDfake_9595cuObjects6= [];
gdjs.scene2Code.GDfake_9595cuObjects7= [];
gdjs.scene2Code.GDfake_9595cuObjects8= [];
gdjs.scene2Code.GDfake_9595cuObjects9= [];
gdjs.scene2Code.GDfake_9595cuObjects10= [];
gdjs.scene2Code.GDijObjects1= [];
gdjs.scene2Code.GDijObjects2= [];
gdjs.scene2Code.GDijObjects3= [];
gdjs.scene2Code.GDijObjects4= [];
gdjs.scene2Code.GDijObjects5= [];
gdjs.scene2Code.GDijObjects6= [];
gdjs.scene2Code.GDijObjects7= [];
gdjs.scene2Code.GDijObjects8= [];
gdjs.scene2Code.GDijObjects9= [];
gdjs.scene2Code.GDijObjects10= [];
gdjs.scene2Code.GDscrObjects1= [];
gdjs.scene2Code.GDscrObjects2= [];
gdjs.scene2Code.GDscrObjects3= [];
gdjs.scene2Code.GDscrObjects4= [];
gdjs.scene2Code.GDscrObjects5= [];
gdjs.scene2Code.GDscrObjects6= [];
gdjs.scene2Code.GDscrObjects7= [];
gdjs.scene2Code.GDscrObjects8= [];
gdjs.scene2Code.GDscrObjects9= [];
gdjs.scene2Code.GDscrObjects10= [];
gdjs.scene2Code.GDwidthObjects1= [];
gdjs.scene2Code.GDwidthObjects2= [];
gdjs.scene2Code.GDwidthObjects3= [];
gdjs.scene2Code.GDwidthObjects4= [];
gdjs.scene2Code.GDwidthObjects5= [];
gdjs.scene2Code.GDwidthObjects6= [];
gdjs.scene2Code.GDwidthObjects7= [];
gdjs.scene2Code.GDwidthObjects8= [];
gdjs.scene2Code.GDwidthObjects9= [];
gdjs.scene2Code.GDwidthObjects10= [];
gdjs.scene2Code.GDheightObjects1= [];
gdjs.scene2Code.GDheightObjects2= [];
gdjs.scene2Code.GDheightObjects3= [];
gdjs.scene2Code.GDheightObjects4= [];
gdjs.scene2Code.GDheightObjects5= [];
gdjs.scene2Code.GDheightObjects6= [];
gdjs.scene2Code.GDheightObjects7= [];
gdjs.scene2Code.GDheightObjects8= [];
gdjs.scene2Code.GDheightObjects9= [];
gdjs.scene2Code.GDheightObjects10= [];
gdjs.scene2Code.GDxObjects1= [];
gdjs.scene2Code.GDxObjects2= [];
gdjs.scene2Code.GDxObjects3= [];
gdjs.scene2Code.GDxObjects4= [];
gdjs.scene2Code.GDxObjects5= [];
gdjs.scene2Code.GDxObjects6= [];
gdjs.scene2Code.GDxObjects7= [];
gdjs.scene2Code.GDxObjects8= [];
gdjs.scene2Code.GDxObjects9= [];
gdjs.scene2Code.GDxObjects10= [];
gdjs.scene2Code.GDyObjects1= [];
gdjs.scene2Code.GDyObjects2= [];
gdjs.scene2Code.GDyObjects3= [];
gdjs.scene2Code.GDyObjects4= [];
gdjs.scene2Code.GDyObjects5= [];
gdjs.scene2Code.GDyObjects6= [];
gdjs.scene2Code.GDyObjects7= [];
gdjs.scene2Code.GDyObjects8= [];
gdjs.scene2Code.GDyObjects9= [];
gdjs.scene2Code.GDyObjects10= [];
gdjs.scene2Code.GDNewTextObjects1= [];
gdjs.scene2Code.GDNewTextObjects2= [];
gdjs.scene2Code.GDNewTextObjects3= [];
gdjs.scene2Code.GDNewTextObjects4= [];
gdjs.scene2Code.GDNewTextObjects5= [];
gdjs.scene2Code.GDNewTextObjects6= [];
gdjs.scene2Code.GDNewTextObjects7= [];
gdjs.scene2Code.GDNewTextObjects8= [];
gdjs.scene2Code.GDNewTextObjects9= [];
gdjs.scene2Code.GDNewTextObjects10= [];
gdjs.scene2Code.GDstateObjects1= [];
gdjs.scene2Code.GDstateObjects2= [];
gdjs.scene2Code.GDstateObjects3= [];
gdjs.scene2Code.GDstateObjects4= [];
gdjs.scene2Code.GDstateObjects5= [];
gdjs.scene2Code.GDstateObjects6= [];
gdjs.scene2Code.GDstateObjects7= [];
gdjs.scene2Code.GDstateObjects8= [];
gdjs.scene2Code.GDstateObjects9= [];
gdjs.scene2Code.GDstateObjects10= [];
gdjs.scene2Code.GDboxObjects1= [];
gdjs.scene2Code.GDboxObjects2= [];
gdjs.scene2Code.GDboxObjects3= [];
gdjs.scene2Code.GDboxObjects4= [];
gdjs.scene2Code.GDboxObjects5= [];
gdjs.scene2Code.GDboxObjects6= [];
gdjs.scene2Code.GDboxObjects7= [];
gdjs.scene2Code.GDboxObjects8= [];
gdjs.scene2Code.GDboxObjects9= [];
gdjs.scene2Code.GDboxObjects10= [];
gdjs.scene2Code.GDaddObjects1= [];
gdjs.scene2Code.GDaddObjects2= [];
gdjs.scene2Code.GDaddObjects3= [];
gdjs.scene2Code.GDaddObjects4= [];
gdjs.scene2Code.GDaddObjects5= [];
gdjs.scene2Code.GDaddObjects6= [];
gdjs.scene2Code.GDaddObjects7= [];
gdjs.scene2Code.GDaddObjects8= [];
gdjs.scene2Code.GDaddObjects9= [];
gdjs.scene2Code.GDaddObjects10= [];
gdjs.scene2Code.GDobj_9595name_9595giverObjects1= [];
gdjs.scene2Code.GDobj_9595name_9595giverObjects2= [];
gdjs.scene2Code.GDobj_9595name_9595giverObjects3= [];
gdjs.scene2Code.GDobj_9595name_9595giverObjects4= [];
gdjs.scene2Code.GDobj_9595name_9595giverObjects5= [];
gdjs.scene2Code.GDobj_9595name_9595giverObjects6= [];
gdjs.scene2Code.GDobj_9595name_9595giverObjects7= [];
gdjs.scene2Code.GDobj_9595name_9595giverObjects8= [];
gdjs.scene2Code.GDobj_9595name_9595giverObjects9= [];
gdjs.scene2Code.GDobj_9595name_9595giverObjects10= [];
gdjs.scene2Code.GDcreateObjects1= [];
gdjs.scene2Code.GDcreateObjects2= [];
gdjs.scene2Code.GDcreateObjects3= [];
gdjs.scene2Code.GDcreateObjects4= [];
gdjs.scene2Code.GDcreateObjects5= [];
gdjs.scene2Code.GDcreateObjects6= [];
gdjs.scene2Code.GDcreateObjects7= [];
gdjs.scene2Code.GDcreateObjects8= [];
gdjs.scene2Code.GDcreateObjects9= [];
gdjs.scene2Code.GDcreateObjects10= [];
gdjs.scene2Code.GDreObjects1= [];
gdjs.scene2Code.GDreObjects2= [];
gdjs.scene2Code.GDreObjects3= [];
gdjs.scene2Code.GDreObjects4= [];
gdjs.scene2Code.GDreObjects5= [];
gdjs.scene2Code.GDreObjects6= [];
gdjs.scene2Code.GDreObjects7= [];
gdjs.scene2Code.GDreObjects8= [];
gdjs.scene2Code.GDreObjects9= [];
gdjs.scene2Code.GDreObjects10= [];
gdjs.scene2Code.GDscriptIDEObjects1= [];
gdjs.scene2Code.GDscriptIDEObjects2= [];
gdjs.scene2Code.GDscriptIDEObjects3= [];
gdjs.scene2Code.GDscriptIDEObjects4= [];
gdjs.scene2Code.GDscriptIDEObjects5= [];
gdjs.scene2Code.GDscriptIDEObjects6= [];
gdjs.scene2Code.GDscriptIDEObjects7= [];
gdjs.scene2Code.GDscriptIDEObjects8= [];
gdjs.scene2Code.GDscriptIDEObjects9= [];
gdjs.scene2Code.GDscriptIDEObjects10= [];
gdjs.scene2Code.GDexportObjects1= [];
gdjs.scene2Code.GDexportObjects2= [];
gdjs.scene2Code.GDexportObjects3= [];
gdjs.scene2Code.GDexportObjects4= [];
gdjs.scene2Code.GDexportObjects5= [];
gdjs.scene2Code.GDexportObjects6= [];
gdjs.scene2Code.GDexportObjects7= [];
gdjs.scene2Code.GDexportObjects8= [];
gdjs.scene2Code.GDexportObjects9= [];
gdjs.scene2Code.GDexportObjects10= [];
gdjs.scene2Code.GDbuttonObjects1= [];
gdjs.scene2Code.GDbuttonObjects2= [];
gdjs.scene2Code.GDbuttonObjects3= [];
gdjs.scene2Code.GDbuttonObjects4= [];
gdjs.scene2Code.GDbuttonObjects5= [];
gdjs.scene2Code.GDbuttonObjects6= [];
gdjs.scene2Code.GDbuttonObjects7= [];
gdjs.scene2Code.GDbuttonObjects8= [];
gdjs.scene2Code.GDbuttonObjects9= [];
gdjs.scene2Code.GDbuttonObjects10= [];
gdjs.scene2Code.GDhtmlObjects1= [];
gdjs.scene2Code.GDhtmlObjects2= [];
gdjs.scene2Code.GDhtmlObjects3= [];
gdjs.scene2Code.GDhtmlObjects4= [];
gdjs.scene2Code.GDhtmlObjects5= [];
gdjs.scene2Code.GDhtmlObjects6= [];
gdjs.scene2Code.GDhtmlObjects7= [];
gdjs.scene2Code.GDhtmlObjects8= [];
gdjs.scene2Code.GDhtmlObjects9= [];
gdjs.scene2Code.GDhtmlObjects10= [];
gdjs.scene2Code.GDmainMenuObjects1= [];
gdjs.scene2Code.GDmainMenuObjects2= [];
gdjs.scene2Code.GDmainMenuObjects3= [];
gdjs.scene2Code.GDmainMenuObjects4= [];
gdjs.scene2Code.GDmainMenuObjects5= [];
gdjs.scene2Code.GDmainMenuObjects6= [];
gdjs.scene2Code.GDmainMenuObjects7= [];
gdjs.scene2Code.GDmainMenuObjects8= [];
gdjs.scene2Code.GDmainMenuObjects9= [];
gdjs.scene2Code.GDmainMenuObjects10= [];
gdjs.scene2Code.GDsaveObjects1= [];
gdjs.scene2Code.GDsaveObjects2= [];
gdjs.scene2Code.GDsaveObjects3= [];
gdjs.scene2Code.GDsaveObjects4= [];
gdjs.scene2Code.GDsaveObjects5= [];
gdjs.scene2Code.GDsaveObjects6= [];
gdjs.scene2Code.GDsaveObjects7= [];
gdjs.scene2Code.GDsaveObjects8= [];
gdjs.scene2Code.GDsaveObjects9= [];
gdjs.scene2Code.GDsaveObjects10= [];
gdjs.scene2Code.GDbehaveObjects1= [];
gdjs.scene2Code.GDbehaveObjects2= [];
gdjs.scene2Code.GDbehaveObjects3= [];
gdjs.scene2Code.GDbehaveObjects4= [];
gdjs.scene2Code.GDbehaveObjects5= [];
gdjs.scene2Code.GDbehaveObjects6= [];
gdjs.scene2Code.GDbehaveObjects7= [];
gdjs.scene2Code.GDbehaveObjects8= [];
gdjs.scene2Code.GDbehaveObjects9= [];
gdjs.scene2Code.GDbehaveObjects10= [];
gdjs.scene2Code.GDmoreObjects1= [];
gdjs.scene2Code.GDmoreObjects2= [];
gdjs.scene2Code.GDmoreObjects3= [];
gdjs.scene2Code.GDmoreObjects4= [];
gdjs.scene2Code.GDmoreObjects5= [];
gdjs.scene2Code.GDmoreObjects6= [];
gdjs.scene2Code.GDmoreObjects7= [];
gdjs.scene2Code.GDmoreObjects8= [];
gdjs.scene2Code.GDmoreObjects9= [];
gdjs.scene2Code.GDmoreObjects10= [];
gdjs.scene2Code.GDNewSpriteObjects1= [];
gdjs.scene2Code.GDNewSpriteObjects2= [];
gdjs.scene2Code.GDNewSpriteObjects3= [];
gdjs.scene2Code.GDNewSpriteObjects4= [];
gdjs.scene2Code.GDNewSpriteObjects5= [];
gdjs.scene2Code.GDNewSpriteObjects6= [];
gdjs.scene2Code.GDNewSpriteObjects7= [];
gdjs.scene2Code.GDNewSpriteObjects8= [];
gdjs.scene2Code.GDNewSpriteObjects9= [];
gdjs.scene2Code.GDNewSpriteObjects10= [];


gdjs.scene2Code.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


};gdjs.scene2Code.eventsList1 = function(runtimeScene) {

{



}


};gdjs.scene2Code.eventsList2 = function(runtimeScene) {

{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setString("{");
variables._declare("dat", variable);
}
gdjs.scene2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.scene2Code.eventsList1(runtimeScene);} //End of subevents
}
gdjs.scene2Code.localVariables.pop();

}


};gdjs.scene2Code.mapOfEmptyGDspriteObjects = Hashtable.newFrom({"sprite": []});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects2Objects = Hashtable.newFrom({"sprite": gdjs.scene2Code.GDspriteObjects2});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects2Objects = Hashtable.newFrom({"sprite": gdjs.scene2Code.GDspriteObjects2});
gdjs.scene2Code.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(gdjs.scene2Code.localVariables[1].getFromIndex(0)) == gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects2Objects);
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.scene2Code.GDstateObjects1, gdjs.scene2Code.GDstateObjects3);

{gdjs.evtTools.variable.variablePushCopy(gdjs.scene2Code.localVariables[1].getFromIndex(3), runtimeScene.getGame().getVariables().getFromIndex(1));
}{gdjs.evtTools.variable.variablePushCopy(gdjs.scene2Code.localVariables[1].getFromIndex(3), runtimeScene.getGame().getVariables().getFromIndex(7));
}{gdjs.evtTools.variable.variablePushCopy(gdjs.scene2Code.localVariables[1].getFromIndex(3), runtimeScene.getGame().getVariables().getFromIndex(6));
}{gdjs.evtTools.variable.variablePushCopy(gdjs.scene2Code.localVariables[1].getFromIndex(3), runtimeScene.getGame().getVariables().getFromIndex(9));
}{gdjs.evtTools.variable.variablePushCopy(gdjs.scene2Code.localVariables[1].getFromIndex(3), runtimeScene.getGame().getVariables().getFromIndex(2));
}{gdjs.evtTools.variable.variablePushCopy(gdjs.scene2Code.localVariables[1].getFromIndex(3), runtimeScene.getGame().getVariables().getFromIndex(8));
}{gdjs.evtTools.variable.variablePushCopy(gdjs.scene2Code.localVariables[1].getFromIndex(3), runtimeScene.getGame().getVariables().getFromIndex(0));
}{runtimeScene.getScene().getVariables().getFromIndex(10).setBoolean(false);
}{for(var i = 0, len = gdjs.scene2Code.GDstateObjects3.length ;i < len;++i) {
    gdjs.scene2Code.GDstateObjects3[i].getBehavior("Text").setText("just started ide");
}
}{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "g2");
}}

}


};gdjs.scene2Code.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("sprite"), gdjs.scene2Code.GDspriteObjects1);

for (gdjs.scene2Code.forEachIndex2 = 0;gdjs.scene2Code.forEachIndex2 < gdjs.scene2Code.GDspriteObjects1.length;++gdjs.scene2Code.forEachIndex2) {
gdjs.scene2Code.GDspriteObjects2.length = 0;


gdjs.scene2Code.forEachTemporary2 = gdjs.scene2Code.GDspriteObjects1[gdjs.scene2Code.forEachIndex2];
gdjs.scene2Code.GDspriteObjects2.push(gdjs.scene2Code.forEachTemporary2);
let isConditionTrue_0 = false;
if (true) {
{runtimeScene.getScene().getVariables().getFromIndex(18).getChild("height").setNumber((( gdjs.scene2Code.GDspriteObjects2.length === 0 ) ? 0 :gdjs.scene2Code.GDspriteObjects2[0].getHeight()));
}{runtimeScene.getScene().getVariables().getFromIndex(18).getChild("width").setNumber((( gdjs.scene2Code.GDspriteObjects2.length === 0 ) ? 0 :gdjs.scene2Code.GDspriteObjects2[0].getWidth()));
}{gdjs.evtTools.variable.variablePushCopy(runtimeScene.getGame().getVariables().getFromIndex(7).getChild(((gdjs.scene2Code.GDspriteObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.scene2Code.GDspriteObjects2[0].getVariables()).get("name").getAsString()), runtimeScene.getScene().getVariables().getFromIndex(18));
}{runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[1].getFromIndex(0).getAsNumber()).getChild("name").setString(((gdjs.scene2Code.GDspriteObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.scene2Code.GDspriteObjects2[0].getVariables()).get("name").getAsString());
}{runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[1].getFromIndex(0).getAsNumber()).getChild("type").setString((( gdjs.scene2Code.GDspriteObjects2.length === 0 ) ? "" :gdjs.scene2Code.GDspriteObjects2[0].getName()));
}{runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[1].getFromIndex(0).getAsNumber()).getChild("x").setNumber((( gdjs.scene2Code.GDspriteObjects2.length === 0 ) ? 0 :gdjs.scene2Code.GDspriteObjects2[0].getPointX("")));
}{runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[1].getFromIndex(0).getAsNumber()).getChild("y").setNumber((( gdjs.scene2Code.GDspriteObjects2.length === 0 ) ? 0 :gdjs.scene2Code.GDspriteObjects2[0].getPointY("")));
}{runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[1].getFromIndex(0).getAsNumber()).getChild("width").setNumber((( gdjs.scene2Code.GDspriteObjects2.length === 0 ) ? 0 :gdjs.scene2Code.GDspriteObjects2[0].getWidth()));
}{runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[1].getFromIndex(0).getAsNumber()).getChild("height").setNumber((( gdjs.scene2Code.GDspriteObjects2.length === 0 ) ? 0 :gdjs.scene2Code.GDspriteObjects2[0].getHeight()));
}{runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[1].getFromIndex(0).getAsNumber()).getChild("image").setString(runtimeScene.getScene().getVariables().getFromIndex(8).getChild("images").getChild(((gdjs.scene2Code.GDspriteObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.scene2Code.GDspriteObjects2[0].getVariables()).get("name").getAsString()).getAsString());
}{gdjs.scene2Code.localVariables[0].getFromIndex(0).add(1);
}{gdjs.scene2Code.localVariables[1].getFromIndex(0).add(1);
}{runtimeScene.getGame().getVariables().getFromIndex(9).setNumber(gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects2Objects));
}
{ //Subevents: 
gdjs.scene2Code.eventsList3(runtimeScene);} //Subevents end.
}
}

}


};gdjs.scene2Code.eventsList5 = function(runtimeScene) {

{



}


{



}


{



}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("count", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("runtimeScene.getVariables().get('json').fromJSON(JSON.stringify(json))\n\n};\ngdjs.external_32lvlCode.eventsList0 = function(runtimeScene) {\n\n{\n\n\ngdjs.external_32lvlCode.userFunc0xb78110(runtimeScene);\n\n}\n\n\n};gdjs.external_32lvlCode.asyncCallback14219068 = function (runtimeScene, asyncObjectsList) {\nasyncObjectsList.restoreLocalVariablesContainers(gdjs.external_32lvlCode.localVariables);\n{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, \"g2\", false);\n}gdjs.external_32lvlCode.localVariables.length = 0;\n}\ngdjs.external_32lvlCode.eventsList1 = function(runtimeScene) {\n\n{\n\n\n{\n{\nconst asyncObjectsList = new gdjs.LongLivedObjectsList();\nasyncObjectsList.backupLocalVariablesContainers(gdjs.external_32lvlCode.localVariables);\nruntimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.external_32lvlCode.asyncCallback14219068(runtimeScene, asyncObjectsList)));\n}\n}\n\n}\n\n\n};gdjs.external_32lvlCode.eventsList2 = function(runtimeScene) {\n\n{\n\n\nlet isConditionTrue_0 = false;\nisConditionTrue_0 = false;\n{isConditionTrue_0 = (gdjs.evtTools.string.strLen(runtimeScene.getGame().getVariables().getFromIndex(0).getAsString()) > 6);\n}\nif (isConditionTrue_0) {\n\n{ //Subevents\ngdjs.external_32lvlCode.eventsList1(runtimeScene);} //End of subevents\n}\n\n}\n\n\n};gdjs.external_32lvlCode.eventsList3 = function(runtimeScene) {\n\n{\n\n\nlet isConditionTrue_0 = false;\nisConditionTrue_0 = false;\n{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15500276);\n}\nif (isConditionTrue_0) {\n\n{ //Subevents\ngdjs.external_32lvlCode.eventsList0(runtimeScene);} //End of subevents\n}\n\n}\n\n\n{\n\n\n\n}\n\n\n{\n\n\nlet isConditionTrue_0 = false;\nisConditionTrue_0 = false;\nisConditionTrue_0 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(0)) >= 7;\nif (isConditionTrue_0) {\n{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(0).getChild(0)), runtimeScene.getGame().getVariables().getFromIndex(1));\n}{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(0).getChild(1)), runtimeScene.getGame().getVariables().getFromIndex(7));\n}{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(0).getChild(2)), runtimeScene.getGame().getVariables().getFromIndex(6));\n}{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(0).getChild(3)), runtimeScene.getGame().getVariables().getFromIndex(9));\n}{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(0).getChild(4)), runtimeScene.getGame().getVariables().getFromIndex(2));\n}{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(0).getChild(5)), runtimeScene.getGame().getVariables().getFromIndex(8));\n}{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(0).getChild(6)), runtimeScene.getGame().getVariables().getFromIndex(0));\n}\n{ //Subevents\ngdjs.external_32lvlCode.eventsList2(runtimeScene);} //End of subevents\n}\n\n}\n\n\n};\n\ngdjs.external_32lvlCode.func = function(runtimeScene) {\nruntimeScene.getOnceTriggers().startNewFrame();\n\ngdjs.external_32lvlCode.GDdebugObjects1.length = 0;\ngdjs.external_32lvlCode.GDdebugObjects2.length = 0;\n\ngdjs.external_32lvlCode.eventsList3(runtimeScene);\ngdjs.external_32lvlCode.GDdebugObjects1.length = 0;\ngdjs.external_32lvlCode.GDdebugObjects2.length = 0;\n\n\nreturn;\n\n}\n\ngdjs['external_32lvlCode'] = gdjs.external_32lvlCode;\n");
variables._declare("htmlDATA2", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("gdjs.external_32lvlCode = {};\ngdjs.external_32lvlCode.localVariables = [];\ngdjs.external_32lvlCode.GDdebugObjects1= [];\ngdjs.external_32lvlCode.GDdebugObjects2= [];\n\n\ngdjs.external_32lvlCode.userFunc0xb78110 = function GDJSInlineCode(runtimeScene) {\n\"use strict\";\nvar json = ");
variables._declare("htmlDATA1", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("");
variables._declare("q", variable);
}
gdjs.scene2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.scene2Code.eventsList4(runtimeScene);} //End of subevents
}
gdjs.scene2Code.localVariables.pop();

}


};gdjs.scene2Code.mapOfEmptyGDspriteObjects = Hashtable.newFrom({"sprite": []});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDhtmlObjects2Objects = Hashtable.newFrom({"html": gdjs.scene2Code.GDhtmlObjects2});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects3Objects = Hashtable.newFrom({"sprite": gdjs.scene2Code.GDspriteObjects3});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects3Objects = Hashtable.newFrom({"sprite": gdjs.scene2Code.GDspriteObjects3});
gdjs.scene2Code.eventsList6 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(gdjs.scene2Code.localVariables[1].getFromIndex(0)) == gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects3Objects);
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.scene2Code.GDstateObjects2, gdjs.scene2Code.GDstateObjects4);

{gdjs.evtTools.variable.variablePushCopy(gdjs.scene2Code.localVariables[1].getFromIndex(3), runtimeScene.getGame().getVariables().getFromIndex(1));
}{gdjs.evtTools.variable.variablePushCopy(gdjs.scene2Code.localVariables[1].getFromIndex(3), runtimeScene.getGame().getVariables().getFromIndex(7));
}{gdjs.evtTools.variable.variablePushCopy(gdjs.scene2Code.localVariables[1].getFromIndex(3), runtimeScene.getGame().getVariables().getFromIndex(6));
}{gdjs.evtTools.variable.variablePushCopy(gdjs.scene2Code.localVariables[1].getFromIndex(3), runtimeScene.getGame().getVariables().getFromIndex(9));
}{gdjs.evtTools.variable.variablePushCopy(gdjs.scene2Code.localVariables[1].getFromIndex(3), runtimeScene.getGame().getVariables().getFromIndex(2));
}{gdjs.evtTools.variable.variablePushCopy(gdjs.scene2Code.localVariables[1].getFromIndex(3), runtimeScene.getGame().getVariables().getFromIndex(8));
}{gdjs.evtTools.variable.variablePushCopy(gdjs.scene2Code.localVariables[1].getFromIndex(3), runtimeScene.getGame().getVariables().getFromIndex(0));
}{runtimeScene.getScene().getVariables().getFromIndex(10).setBoolean(false);
}{gdjs.evtsExt__UploadDownloadTextFile__DownloadTextFile.func(runtimeScene, "code3.js", gdjs.scene2Code.localVariables[1].getFromIndex(2).getAsString() + gdjs.evtTools.network.variableStructureToJSON(gdjs.scene2Code.localVariables[1].getFromIndex(3)) + gdjs.evtTools.string.newLine() + gdjs.scene2Code.localVariables[1].getFromIndex(1).getAsString(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.scene2Code.GDstateObjects4.length ;i < len;++i) {
    gdjs.scene2Code.GDstateObjects4[i].getBehavior("Text").setText("export complete");
}
}}

}


};gdjs.scene2Code.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("sprite"), gdjs.scene2Code.GDspriteObjects2);

for (gdjs.scene2Code.forEachIndex3 = 0;gdjs.scene2Code.forEachIndex3 < gdjs.scene2Code.GDspriteObjects2.length;++gdjs.scene2Code.forEachIndex3) {
gdjs.scene2Code.GDspriteObjects3.length = 0;


gdjs.scene2Code.forEachTemporary3 = gdjs.scene2Code.GDspriteObjects2[gdjs.scene2Code.forEachIndex3];
gdjs.scene2Code.GDspriteObjects3.push(gdjs.scene2Code.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {
{runtimeScene.getScene().getVariables().getFromIndex(18).getChild("height").setNumber((( gdjs.scene2Code.GDspriteObjects3.length === 0 ) ? 0 :gdjs.scene2Code.GDspriteObjects3[0].getHeight()));
}{runtimeScene.getScene().getVariables().getFromIndex(18).getChild("width").setNumber((( gdjs.scene2Code.GDspriteObjects3.length === 0 ) ? 0 :gdjs.scene2Code.GDspriteObjects3[0].getWidth()));
}{gdjs.evtTools.variable.variablePushCopy(runtimeScene.getGame().getVariables().getFromIndex(7).getChild(((gdjs.scene2Code.GDspriteObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.scene2Code.GDspriteObjects3[0].getVariables()).get("name").getAsString()), runtimeScene.getScene().getVariables().getFromIndex(18));
}{runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[1].getFromIndex(0).getAsNumber()).getChild("name").setString(((gdjs.scene2Code.GDspriteObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.scene2Code.GDspriteObjects3[0].getVariables()).get("name").getAsString());
}{runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[1].getFromIndex(0).getAsNumber()).getChild("type").setString((( gdjs.scene2Code.GDspriteObjects3.length === 0 ) ? "" :gdjs.scene2Code.GDspriteObjects3[0].getName()));
}{runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[1].getFromIndex(0).getAsNumber()).getChild("x").setNumber((( gdjs.scene2Code.GDspriteObjects3.length === 0 ) ? 0 :gdjs.scene2Code.GDspriteObjects3[0].getPointX("")));
}{runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[1].getFromIndex(0).getAsNumber()).getChild("y").setNumber((( gdjs.scene2Code.GDspriteObjects3.length === 0 ) ? 0 :gdjs.scene2Code.GDspriteObjects3[0].getPointY("")));
}{runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[1].getFromIndex(0).getAsNumber()).getChild("width").setNumber((( gdjs.scene2Code.GDspriteObjects3.length === 0 ) ? 0 :gdjs.scene2Code.GDspriteObjects3[0].getWidth()));
}{runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[1].getFromIndex(0).getAsNumber()).getChild("height").setNumber((( gdjs.scene2Code.GDspriteObjects3.length === 0 ) ? 0 :gdjs.scene2Code.GDspriteObjects3[0].getHeight()));
}{runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[1].getFromIndex(0).getAsNumber()).getChild("image").setString(runtimeScene.getScene().getVariables().getFromIndex(8).getChild("images").getChild(((gdjs.scene2Code.GDspriteObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.scene2Code.GDspriteObjects3[0].getVariables()).get("name").getAsString()).getAsString());
}{gdjs.scene2Code.localVariables[0].getFromIndex(0).add(1);
}{gdjs.scene2Code.localVariables[1].getFromIndex(0).add(1);
}{runtimeScene.getGame().getVariables().getFromIndex(9).setNumber(gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects3Objects));
}
{ //Subevents: 
gdjs.scene2Code.eventsList6(runtimeScene);} //Subevents end.
}
}

}


};gdjs.scene2Code.eventsList8 = function(runtimeScene) {

{



}


{



}


{



}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("count", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("runtimeScene.getVariables().get('json').fromJSON(JSON.stringify(json))\n\n};\ngdjs.external_32lvlCode.eventsList0 = function(runtimeScene) {\n\n{\n\n\ngdjs.external_32lvlCode.userFunc0xb78110(runtimeScene);\n\n}\n\n\n};gdjs.external_32lvlCode.asyncCallback14219068 = function (runtimeScene, asyncObjectsList) {\nasyncObjectsList.restoreLocalVariablesContainers(gdjs.external_32lvlCode.localVariables);\n{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, \"g2\", false);\n}gdjs.external_32lvlCode.localVariables.length = 0;\n}\ngdjs.external_32lvlCode.eventsList1 = function(runtimeScene) {\n\n{\n\n\n{\n{\nconst asyncObjectsList = new gdjs.LongLivedObjectsList();\nasyncObjectsList.backupLocalVariablesContainers(gdjs.external_32lvlCode.localVariables);\nruntimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.external_32lvlCode.asyncCallback14219068(runtimeScene, asyncObjectsList)));\n}\n}\n\n}\n\n\n};gdjs.external_32lvlCode.eventsList2 = function(runtimeScene) {\n\n{\n\n\nlet isConditionTrue_0 = false;\nisConditionTrue_0 = false;\n{isConditionTrue_0 = (gdjs.evtTools.string.strLen(runtimeScene.getGame().getVariables().getFromIndex(0).getAsString()) > 6);\n}\nif (isConditionTrue_0) {\n\n{ //Subevents\ngdjs.external_32lvlCode.eventsList1(runtimeScene);} //End of subevents\n}\n\n}\n\n\n};gdjs.external_32lvlCode.eventsList3 = function(runtimeScene) {\n\n{\n\n\nlet isConditionTrue_0 = false;\nisConditionTrue_0 = false;\n{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15500276);\n}\nif (isConditionTrue_0) {\n\n{ //Subevents\ngdjs.external_32lvlCode.eventsList0(runtimeScene);} //End of subevents\n}\n\n}\n\n\n{\n\n\n\n}\n\n\n{\n\n\nlet isConditionTrue_0 = false;\nisConditionTrue_0 = false;\nisConditionTrue_0 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(0)) >= 7;\nif (isConditionTrue_0) {\n{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(0).getChild(0)), runtimeScene.getGame().getVariables().getFromIndex(1));\n}{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(0).getChild(1)), runtimeScene.getGame().getVariables().getFromIndex(7));\n}{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(0).getChild(2)), runtimeScene.getGame().getVariables().getFromIndex(6));\n}{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(0).getChild(3)), runtimeScene.getGame().getVariables().getFromIndex(9));\n}{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(0).getChild(4)), runtimeScene.getGame().getVariables().getFromIndex(2));\n}{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(0).getChild(5)), runtimeScene.getGame().getVariables().getFromIndex(8));\n}{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(0).getChild(6)), runtimeScene.getGame().getVariables().getFromIndex(0));\n}\n{ //Subevents\ngdjs.external_32lvlCode.eventsList2(runtimeScene);} //End of subevents\n}\n\n}\n\n\n};\n\ngdjs.external_32lvlCode.func = function(runtimeScene) {\nruntimeScene.getOnceTriggers().startNewFrame();\n\ngdjs.external_32lvlCode.GDdebugObjects1.length = 0;\ngdjs.external_32lvlCode.GDdebugObjects2.length = 0;\n\ngdjs.external_32lvlCode.eventsList3(runtimeScene);\ngdjs.external_32lvlCode.GDdebugObjects1.length = 0;\ngdjs.external_32lvlCode.GDdebugObjects2.length = 0;\n\n\nreturn;\n\n}\n\ngdjs['external_32lvlCode'] = gdjs.external_32lvlCode;\n");
variables._declare("htmlDATA2", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("gdjs.external_32lvlCode = {};\ngdjs.external_32lvlCode.localVariables = [];\ngdjs.external_32lvlCode.GDdebugObjects1= [];\ngdjs.external_32lvlCode.GDdebugObjects2= [];\n\n\ngdjs.external_32lvlCode.userFunc0xb78110 = function GDJSInlineCode(runtimeScene) {\n\"use strict\";\nvar json = ");
variables._declare("htmlDATA1", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("");
variables._declare("q", variable);
}
gdjs.scene2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.scene2Code.eventsList7(runtimeScene);} //End of subevents
}
gdjs.scene2Code.localVariables.pop();

}


};gdjs.scene2Code.mapOfEmptyGDspriteObjects = Hashtable.newFrom({"sprite": []});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDhtmlObjects2Objects = Hashtable.newFrom({"html": gdjs.scene2Code.GDhtmlObjects2});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDmainMenuObjects1Objects = Hashtable.newFrom({"mainMenu": gdjs.scene2Code.GDmainMenuObjects1});
gdjs.scene2Code.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("html"), gdjs.scene2Code.GDhtmlObjects2);

{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("countr", variable);
}
gdjs.scene2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.scene2Code.mapOfEmptyGDspriteObjects) > 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDhtmlObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(11), true, false);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("state"), gdjs.scene2Code.GDstateObjects2);
{for(var i = 0, len = gdjs.scene2Code.GDstateObjects2.length ;i < len;++i) {
    gdjs.scene2Code.GDstateObjects2[i].getBehavior("Text").setText("collecting object position....");
}
}{gdjs.evtTools.variable.variableClearChildren(runtimeScene.getGame().getVariables().getFromIndex(1));
}
{ //Subevents
gdjs.scene2Code.eventsList8(runtimeScene);} //End of subevents
}
gdjs.scene2Code.localVariables.pop();

}


{

gdjs.copyArray(runtimeScene.getObjects("html"), gdjs.scene2Code.GDhtmlObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.scene2Code.mapOfEmptyGDspriteObjects) > 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDhtmlObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(11), false, false);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("state"), gdjs.scene2Code.GDstateObjects2);
{for(var i = 0, len = gdjs.scene2Code.GDstateObjects2.length ;i < len;++i) {
    gdjs.scene2Code.GDstateObjects2[i].getBehavior("Text").setText("preview game before building");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("mainMenu"), gdjs.scene2Code.GDmainMenuObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDmainMenuObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "start", true);
}}

}


};gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects8Objects = Hashtable.newFrom({"sprite": gdjs.scene2Code.GDspriteObjects8});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects8Objects = Hashtable.newFrom({"sprite": gdjs.scene2Code.GDspriteObjects8});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects8Objects = Hashtable.newFrom({"sprite": gdjs.scene2Code.GDspriteObjects8});
gdjs.scene2Code.eventsList10 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(gdjs.scene2Code.localVariables[1].getFromIndex(0)) == gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects8Objects);
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(3).setString("h");
}}

}


};gdjs.scene2Code.eventsList11 = function(runtimeScene, asyncObjectsList) {

{


const repeatCount8 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(1));
for (let repeatIndex8 = 0;repeatIndex8 < repeatCount8;++repeatIndex8) {
gdjs.scene2Code.GDspriteObjects8.length = 0;


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects8Objects, runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[1].getFromIndex(0).getAsNumber()).getChild("type").getAsString(), runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[1].getFromIndex(0).getAsNumber()).getChild("x").getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[1].getFromIndex(0).getAsNumber()).getChild("y").getAsNumber(), "");
}{for(var i = 0, len = gdjs.scene2Code.GDspriteObjects8.length ;i < len;++i) {
    gdjs.scene2Code.GDspriteObjects8[i].returnVariable(gdjs.scene2Code.GDspriteObjects8[i].getVariables().get("name")).setString(runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[1].getFromIndex(0).getAsNumber()).getChild("name").getAsString());
}
}{gdjs.evtsExt__resize_image_from_url__LoadURLIntoSprite.func(runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(8).getChild("images").getChild(((gdjs.scene2Code.GDspriteObjects8.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.scene2Code.GDspriteObjects8[0].getVariables()).get("name").getAsString()).getAsString(), gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects8Objects, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.scene2Code.GDspriteObjects8.length ;i < len;++i) {
    gdjs.scene2Code.GDspriteObjects8[i].getBehavior("Resizable").setSize(runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[1].getFromIndex(0).getAsNumber()).getChild("width").getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[1].getFromIndex(0).getAsNumber()).getChild("height").getAsNumber());
}
}{gdjs.scene2Code.localVariables[1].getFromIndex(0).add(1);
}
{ //Subevents: 
gdjs.scene2Code.eventsList10(runtimeScene, asyncObjectsList);} //Subevents end.
}
}

}


};gdjs.scene2Code.userFunc0xb87e68 = function GDJSInlineCode(runtimeScene, objects) {
"use strict";
console.log(objects[0])

};
gdjs.scene2Code.eventsList12 = function(runtimeScene, asyncObjectsList) {

{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("climb", variable);
}
gdjs.scene2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.scene2Code.eventsList11(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.scene2Code.localVariables.pop();

}


{

gdjs.copyArray(runtimeScene.getObjects("x"), gdjs.scene2Code.GDxObjects6);

var objects = [];
objects.push.apply(objects,gdjs.scene2Code.GDxObjects6);
gdjs.scene2Code.userFunc0xb87e68(runtimeScene, objects);

}


};gdjs.scene2Code.asyncCallback24215068 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.scene2Code.localVariables);

{ //Subevents
gdjs.scene2Code.eventsList12(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.scene2Code.localVariables.length = 0;
}
gdjs.scene2Code.eventsList13 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.scene2Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.scene2Code.asyncCallback24215068(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.scene2Code.asyncCallback24214516 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.scene2Code.localVariables);
{gdjs.evtTools.network.jsonToVariableStructure(gdjs.scene2Code.localVariables[0].getFromIndex(2).getAsString(), runtimeScene.getGame().getVariables().getFromIndex(6));
}
{ //Subevents
gdjs.scene2Code.eventsList13(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.scene2Code.localVariables.length = 0;
}
gdjs.scene2Code.eventsList14 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.scene2Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.scene2Code.asyncCallback24214516(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.scene2Code.asyncCallback24214028 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.scene2Code.localVariables);
{gdjs.evtTools.network.jsonToVariableStructure(gdjs.scene2Code.localVariables[0].getFromIndex(3).getAsString(), runtimeScene.getScene().getVariables().getFromIndex(1));
}
{ //Subevents
gdjs.scene2Code.eventsList14(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.scene2Code.localVariables.length = 0;
}
gdjs.scene2Code.eventsList15 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.scene2Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.scene2Code.asyncCallback24214028(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.scene2Code.asyncCallback24213676 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.scene2Code.localVariables);
{gdjs.evtTools.network.jsonToVariableStructure(gdjs.scene2Code.localVariables[0].getFromIndex(1).getAsString(), runtimeScene.getScene().getVariables().getFromIndex(8));
}
{ //Subevents
gdjs.scene2Code.eventsList15(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.scene2Code.localVariables.length = 0;
}
gdjs.scene2Code.eventsList16 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.scene2Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.scene2Code.asyncCallback24213676(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects7Objects = Hashtable.newFrom({"sprite": gdjs.scene2Code.GDspriteObjects7});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects7Objects = Hashtable.newFrom({"sprite": gdjs.scene2Code.GDspriteObjects7});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects7Objects = Hashtable.newFrom({"sprite": gdjs.scene2Code.GDspriteObjects7});
gdjs.scene2Code.eventsList17 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(gdjs.scene2Code.localVariables[1].getFromIndex(0)) == gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects7Objects);
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(3).setString("h");
}}

}


};gdjs.scene2Code.eventsList18 = function(runtimeScene, asyncObjectsList) {

{


const repeatCount7 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(1));
for (let repeatIndex7 = 0;repeatIndex7 < repeatCount7;++repeatIndex7) {
gdjs.scene2Code.GDspriteObjects7.length = 0;


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects7Objects, runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[1].getFromIndex(0).getAsNumber()).getChild("type").getAsString(), runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[1].getFromIndex(0).getAsNumber()).getChild("x").getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[1].getFromIndex(0).getAsNumber()).getChild("y").getAsNumber(), "");
}{for(var i = 0, len = gdjs.scene2Code.GDspriteObjects7.length ;i < len;++i) {
    gdjs.scene2Code.GDspriteObjects7[i].returnVariable(gdjs.scene2Code.GDspriteObjects7[i].getVariables().get("name")).setString(runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[1].getFromIndex(0).getAsNumber()).getChild("name").getAsString());
}
}{gdjs.evtsExt__resize_image_from_url__LoadURLIntoSprite.func(runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(8).getChild("images").getChild(((gdjs.scene2Code.GDspriteObjects7.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.scene2Code.GDspriteObjects7[0].getVariables()).get("name").getAsString()).getAsString(), gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects7Objects, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.scene2Code.GDspriteObjects7.length ;i < len;++i) {
    gdjs.scene2Code.GDspriteObjects7[i].getBehavior("Resizable").setSize(runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[1].getFromIndex(0).getAsNumber()).getChild("width").getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[1].getFromIndex(0).getAsNumber()).getChild("height").getAsNumber());
}
}{gdjs.scene2Code.localVariables[1].getFromIndex(0).add(1);
}
{ //Subevents: 
gdjs.scene2Code.eventsList17(runtimeScene, asyncObjectsList);} //Subevents end.
}
}

}


};gdjs.scene2Code.userFunc0x11f9a08 = function GDJSInlineCode(runtimeScene, objects) {
"use strict";
console.log(objects[0])

};
gdjs.scene2Code.eventsList19 = function(runtimeScene, asyncObjectsList) {

{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("climb", variable);
}
gdjs.scene2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.scene2Code.eventsList18(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.scene2Code.localVariables.pop();

}


{

gdjs.copyArray(runtimeScene.getObjects("x"), gdjs.scene2Code.GDxObjects5);

var objects = [];
objects.push.apply(objects,gdjs.scene2Code.GDxObjects5);
gdjs.scene2Code.userFunc0x11f9a08(runtimeScene, objects);

}


};gdjs.scene2Code.asyncCallback24222580 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.scene2Code.localVariables);
{runtimeScene.getGame().getVariables().getFromIndex(0).setString(runtimeScene.getGame().getVariables().getFromIndex(13).getChild("script").getAsString());
}
{ //Subevents
gdjs.scene2Code.eventsList19(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.scene2Code.localVariables.length = 0;
}
gdjs.scene2Code.eventsList20 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.scene2Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.scene2Code.asyncCallback24222580(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.scene2Code.asyncCallback24222484 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.scene2Code.localVariables);
{gdjs.evtTools.network.jsonToVariableStructure(runtimeScene.getGame().getVariables().getFromIndex(13).getChild("DataJson").getAsString(), runtimeScene.getGame().getVariables().getFromIndex(6));
}
{ //Subevents
gdjs.scene2Code.eventsList20(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.scene2Code.localVariables.length = 0;
}
gdjs.scene2Code.eventsList21 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.scene2Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.scene2Code.asyncCallback24222484(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.scene2Code.asyncCallback24222084 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.scene2Code.localVariables);
{gdjs.evtTools.network.jsonToVariableStructure(runtimeScene.getGame().getVariables().getFromIndex(13).getChild("TOjsom").getAsString(), runtimeScene.getScene().getVariables().getFromIndex(1));
}
{ //Subevents
gdjs.scene2Code.eventsList21(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.scene2Code.localVariables.length = 0;
}
gdjs.scene2Code.eventsList22 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.scene2Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.scene2Code.asyncCallback24222084(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.scene2Code.asyncCallback24221668 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.scene2Code.localVariables);
{gdjs.evtTools.network.jsonToVariableStructure(runtimeScene.getGame().getVariables().getFromIndex(13).getChild("Rjson").getAsString(), runtimeScene.getScene().getVariables().getFromIndex(8));
}
{ //Subevents
gdjs.scene2Code.eventsList22(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.scene2Code.localVariables.length = 0;
}
gdjs.scene2Code.eventsList23 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.scene2Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.scene2Code.asyncCallback24221668(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.scene2Code.eventsList24 = function(runtimeScene) {

{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setString("");
variables._declare("Ojson", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("");
variables._declare("Rjson", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("");
variables._declare("DataJson", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("");
variables._declare("TOjsom", variable);
}
gdjs.scene2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(12), false, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readStringFromJSONFile("MGDproject", "object", runtimeScene, gdjs.scene2Code.localVariables[0].getFromIndex(0));
}{gdjs.evtTools.storage.readStringFromJSONFile("MGDproject", "resources", runtimeScene, gdjs.scene2Code.localVariables[0].getFromIndex(1));
}{gdjs.evtTools.storage.readStringFromJSONFile("MGDproject", "ObjInstaceData", runtimeScene, gdjs.scene2Code.localVariables[0].getFromIndex(3));
}{gdjs.evtTools.storage.readStringFromJSONFile("MGDproject", "data", runtimeScene, gdjs.scene2Code.localVariables[0].getFromIndex(2));
}{gdjs.evtTools.storage.readStringFromJSONFile("MGDproject", "script", runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(0));
}{gdjs.evtTools.network.jsonToVariableStructure(gdjs.scene2Code.localVariables[0].getFromIndex(0).getAsString(), runtimeScene.getScene().getVariables().getFromIndex(0));
}
{ //Subevents
gdjs.scene2Code.eventsList16(runtimeScene);} //End of subevents
}
gdjs.scene2Code.localVariables.pop();

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setString("");
variables._declare("Ojson", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("");
variables._declare("Rjson", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("");
variables._declare("DataJson", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("");
variables._declare("TOjsom", variable);
}
gdjs.scene2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(12), true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.network.jsonToVariableStructure(runtimeScene.getGame().getVariables().getFromIndex(13).getChild("Ojson").getAsString(), runtimeScene.getScene().getVariables().getFromIndex(0));
}
{ //Subevents
gdjs.scene2Code.eventsList23(runtimeScene);} //End of subevents
}
gdjs.scene2Code.localVariables.pop();

}


};gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDexportObjects2Objects = Hashtable.newFrom({"export": gdjs.scene2Code.GDexportObjects2});
gdjs.scene2Code.asyncCallback24234188 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.scene2Code.localVariables);
{gdjs.evtsExt__UploadDownloadTextFile__DownloadTextFile.func(runtimeScene, "game project.json", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getGame().getVariables().getFromIndex(13)), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}gdjs.scene2Code.localVariables.length = 0;
}
gdjs.scene2Code.eventsList25 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.scene2Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.scene2Code.asyncCallback24234188(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDexportObjects1Objects = Hashtable.newFrom({"export": gdjs.scene2Code.GDexportObjects1});
gdjs.scene2Code.eventsList26 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("export"), gdjs.scene2Code.GDexportObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(11), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDexportObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(24230740);
}
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(13).getChild("Ojson").setString(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(0)));
}{runtimeScene.getGame().getVariables().getFromIndex(13).getChild("Rjson").setString(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(8)));
}{runtimeScene.getGame().getVariables().getFromIndex(13).getChild("TOjsom").setString(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(1)));
}{runtimeScene.getGame().getVariables().getFromIndex(13).getChild("DataJson").setString(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getGame().getVariables().getFromIndex(6)));
}{runtimeScene.getGame().getVariables().getFromIndex(13).getChild("script").setString(runtimeScene.getGame().getVariables().getFromIndex(0).getAsString());
}
{ //Subevents
gdjs.scene2Code.eventsList25(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("export"), gdjs.scene2Code.GDexportObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(11), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDexportObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(24236292);
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("state"), gdjs.scene2Code.GDstateObjects1);
{for(var i = 0, len = gdjs.scene2Code.GDstateObjects1.length ;i < len;++i) {
    gdjs.scene2Code.GDstateObjects1[i].getBehavior("Text").setText("preview game before export");
}
}}

}


};gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects1Objects = Hashtable.newFrom({"sprite": gdjs.scene2Code.GDspriteObjects1});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects2Objects = Hashtable.newFrom({"sprite": gdjs.scene2Code.GDspriteObjects2});
gdjs.scene2Code.eventsList27 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(gdjs.scene2Code.localVariables[0].getFromIndex(0)) == gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects2Objects);
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(3).setString("p");
}}

}


};gdjs.scene2Code.asyncCallback24240148 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.scene2Code.localVariables);

{ //Subevents
gdjs.scene2Code.eventsList27(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.scene2Code.localVariables.length = 0;
}
gdjs.scene2Code.eventsList28 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.scene2Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.3), (runtimeScene) => (gdjs.scene2Code.asyncCallback24240148(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.scene2Code.eventsList29 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("sprite"), gdjs.scene2Code.GDspriteObjects1);

for (gdjs.scene2Code.forEachIndex2 = 0;gdjs.scene2Code.forEachIndex2 < gdjs.scene2Code.GDspriteObjects1.length;++gdjs.scene2Code.forEachIndex2) {
gdjs.scene2Code.GDspriteObjects2.length = 0;


gdjs.scene2Code.forEachTemporary2 = gdjs.scene2Code.GDspriteObjects1[gdjs.scene2Code.forEachIndex2];
gdjs.scene2Code.GDspriteObjects2.push(gdjs.scene2Code.forEachTemporary2);
let isConditionTrue_0 = false;
if (true) {
{for(var i = 0, len = gdjs.scene2Code.GDspriteObjects2.length ;i < len;++i) {
    gdjs.scene2Code.GDspriteObjects2[i].getBehavior("Resizable").setSize(runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[0].getFromIndex(0).getAsNumber()).getChild("width").getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[0].getFromIndex(0).getAsNumber()).getChild("height").getAsNumber());
}
}{gdjs.scene2Code.localVariables[0].getFromIndex(0).add(1);
}
{ //Subevents: 
gdjs.scene2Code.eventsList28(runtimeScene);} //Subevents end.
}
}

}


};gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDsaveObjects2Objects = Hashtable.newFrom({"save": gdjs.scene2Code.GDsaveObjects2});
gdjs.scene2Code.eventsList30 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("state"), gdjs.scene2Code.GDstateObjects4);
{gdjs.evtTools.storage.writeStringInJSONFile("MGDproject", "ObjInstaceData", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(1)));
}{for(var i = 0, len = gdjs.scene2Code.GDstateObjects4.length ;i < len;++i) {
    gdjs.scene2Code.GDstateObjects4[i].getBehavior("Text").setText("saving...");
}
}}

}


};gdjs.scene2Code.eventsList31 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("sprite"), gdjs.scene2Code.GDspriteObjects2);

for (gdjs.scene2Code.forEachIndex3 = 0;gdjs.scene2Code.forEachIndex3 < gdjs.scene2Code.GDspriteObjects2.length;++gdjs.scene2Code.forEachIndex3) {
gdjs.scene2Code.GDspriteObjects3.length = 0;


gdjs.scene2Code.forEachTemporary3 = gdjs.scene2Code.GDspriteObjects2[gdjs.scene2Code.forEachIndex3];
gdjs.scene2Code.GDspriteObjects3.push(gdjs.scene2Code.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {
{runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[0].getFromIndex(0).getAsNumber()).getChild("name").setString(((gdjs.scene2Code.GDspriteObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.scene2Code.GDspriteObjects3[0].getVariables()).get("name").getAsString());
}{runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[0].getFromIndex(0).getAsNumber()).getChild("type").setString((( gdjs.scene2Code.GDspriteObjects3.length === 0 ) ? "" :gdjs.scene2Code.GDspriteObjects3[0].getName()));
}{runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[0].getFromIndex(0).getAsNumber()).getChild("x").setNumber((( gdjs.scene2Code.GDspriteObjects3.length === 0 ) ? 0 :gdjs.scene2Code.GDspriteObjects3[0].getPointX("")));
}{runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[0].getFromIndex(0).getAsNumber()).getChild("y").setNumber((( gdjs.scene2Code.GDspriteObjects3.length === 0 ) ? 0 :gdjs.scene2Code.GDspriteObjects3[0].getPointY("")));
}{runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[0].getFromIndex(0).getAsNumber()).getChild("width").setNumber((( gdjs.scene2Code.GDspriteObjects3.length === 0 ) ? 0 :gdjs.scene2Code.GDspriteObjects3[0].getWidth()));
}{runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[0].getFromIndex(0).getAsNumber()).getChild("height").setNumber((( gdjs.scene2Code.GDspriteObjects3.length === 0 ) ? 0 :gdjs.scene2Code.GDspriteObjects3[0].getHeight()));
}{gdjs.scene2Code.localVariables[0].getFromIndex(0).add(1);
}
{ //Subevents: 
gdjs.scene2Code.eventsList30(runtimeScene);} //Subevents end.
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("state"), gdjs.scene2Code.GDstateObjects1);
{for(var i = 0, len = gdjs.scene2Code.GDstateObjects1.length ;i < len;++i) {
    gdjs.scene2Code.GDstateObjects1[i].getBehavior("Text").setText("saved");
}
}}

}


};gdjs.scene2Code.eventsList32 = function(runtimeScene) {

{



}


{



}


{



}


};gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects2Objects = Hashtable.newFrom({"sprite": gdjs.scene2Code.GDspriteObjects2});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects2Objects = Hashtable.newFrom({"sprite": gdjs.scene2Code.GDspriteObjects2});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects2Objects = Hashtable.newFrom({"sprite": gdjs.scene2Code.GDspriteObjects2});
gdjs.scene2Code.eventsList33 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.scene2Code.GDNewSpriteObjects2);
{for(var i = 0, len = gdjs.scene2Code.GDNewSpriteObjects2.length ;i < len;++i) {
    gdjs.scene2Code.GDNewSpriteObjects2[i].setPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0),gdjs.evtTools.input.getCursorY(runtimeScene, "", 0));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("sprite"), gdjs.scene2Code.GDspriteObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.scene2Code.GDspriteObjects2.length;i<l;++i) {
    if ( gdjs.scene2Code.GDspriteObjects2[i].getBehavior("Draggable").wasJustDropped() ) {
        isConditionTrue_0 = true;
        gdjs.scene2Code.GDspriteObjects2[k] = gdjs.scene2Code.GDspriteObjects2[i];
        ++k;
    }
}
gdjs.scene2Code.GDspriteObjects2.length = k;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("behave"), gdjs.scene2Code.GDbehaveObjects2);
gdjs.copyArray(runtimeScene.getObjects("height"), gdjs.scene2Code.GDheightObjects2);
gdjs.copyArray(runtimeScene.getObjects("objectName2"), gdjs.scene2Code.GDobjectName2Objects2);
/* Reuse gdjs.scene2Code.GDspriteObjects2 */
gdjs.copyArray(runtimeScene.getObjects("width"), gdjs.scene2Code.GDwidthObjects2);
gdjs.copyArray(runtimeScene.getObjects("x"), gdjs.scene2Code.GDxObjects2);
gdjs.copyArray(runtimeScene.getObjects("y"), gdjs.scene2Code.GDyObjects2);
{gdjs.scene2Code.localVariables[0].getFromIndex(0).setString(((gdjs.scene2Code.GDspriteObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.scene2Code.GDspriteObjects2[0].getVariables()).get("name").getAsString());
}{for(var i = 0, len = gdjs.scene2Code.GDobjectName2Objects2.length ;i < len;++i) {
    gdjs.scene2Code.GDobjectName2Objects2[i].getBehavior("Text").setText(gdjs.scene2Code.localVariables[0].getFromIndex(0).getAsString());
}
}{for(var i = 0, len = gdjs.scene2Code.GDwidthObjects2.length ;i < len;++i) {
    gdjs.scene2Code.GDwidthObjects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString((( gdjs.scene2Code.GDspriteObjects2.length === 0 ) ? 0 :gdjs.scene2Code.GDspriteObjects2[0].getWidth())));
}
}{for(var i = 0, len = gdjs.scene2Code.GDheightObjects2.length ;i < len;++i) {
    gdjs.scene2Code.GDheightObjects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString((( gdjs.scene2Code.GDspriteObjects2.length === 0 ) ? 0 :gdjs.scene2Code.GDspriteObjects2[0].getHeight())));
}
}{for(var i = 0, len = gdjs.scene2Code.GDyObjects2.length ;i < len;++i) {
    gdjs.scene2Code.GDyObjects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString((( gdjs.scene2Code.GDspriteObjects2.length === 0 ) ? 0 :gdjs.scene2Code.GDspriteObjects2[0].getPointY(""))));
}
}{for(var i = 0, len = gdjs.scene2Code.GDxObjects2.length ;i < len;++i) {
    gdjs.scene2Code.GDxObjects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString((( gdjs.scene2Code.GDspriteObjects2.length === 0 ) ? 0 :gdjs.scene2Code.GDspriteObjects2[0].getPointX(""))));
}
}{for(var i = 0, len = gdjs.scene2Code.GDbehaveObjects2.length ;i < len;++i) {
    gdjs.scene2Code.GDbehaveObjects2[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(6).getChild(((gdjs.scene2Code.GDspriteObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.scene2Code.GDspriteObjects2[0].getVariables()).getFromIndex(1).getAsString()).getChild("behavior").getAsString());
}
}{for(var i = 0, len = gdjs.scene2Code.GDobjectName2Objects2.length ;i < len;++i) {
    gdjs.scene2Code.GDobjectName2Objects2[i].setColor("255;255;255");
}
}{runtimeScene.getScene().getVariables().getFromIndex(13).add(1);
}{for(var i = 0, len = gdjs.scene2Code.GDspriteObjects2.length ;i < len;++i) {
    gdjs.scene2Code.GDspriteObjects2[i].returnVariable(gdjs.scene2Code.GDspriteObjects2[i].getVariables().get("id")).setNumber(runtimeScene.getScene().getVariables().getFromIndex(13).getAsNumber());
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("sprite"), gdjs.scene2Code.GDspriteObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
/* Reuse gdjs.scene2Code.GDspriteObjects2 */
{for(var i = 0, len = gdjs.scene2Code.GDspriteObjects2.length ;i < len;++i) {
    gdjs.scene2Code.GDspriteObjects2[i].returnVariable(gdjs.scene2Code.GDspriteObjects2[i].getVariables().get("id")).setNumber(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("sprite"), gdjs.scene2Code.GDspriteObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("more"), gdjs.scene2Code.GDmoreObjects2);
/* Reuse gdjs.scene2Code.GDspriteObjects2 */
{for(var i = 0, len = gdjs.scene2Code.GDmoreObjects2.length ;i < len;++i) {
    gdjs.scene2Code.GDmoreObjects2[i].setPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0),gdjs.evtTools.input.getCursorY(runtimeScene, "", 0));
}
}{for(var i = 0, len = gdjs.scene2Code.GDmoreObjects2.length ;i < len;++i) {
    gdjs.scene2Code.GDmoreObjects2[i].getBehavior("Text").setText(((gdjs.scene2Code.GDspriteObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.scene2Code.GDspriteObjects2[0].getVariables()).get("name").getAsString());
}
}}

}


{



}


};gdjs.scene2Code.eventsList34 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.scene2Code.GDspriteObjects3, gdjs.scene2Code.GDspriteObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.scene2Code.GDspriteObjects4.length;i<l;++i) {
    if ( gdjs.scene2Code.GDspriteObjects4[i].getBehavior("Resizable").getHeight() < 4 ) {
        isConditionTrue_0 = true;
        gdjs.scene2Code.GDspriteObjects4[k] = gdjs.scene2Code.GDspriteObjects4[i];
        ++k;
    }
}
gdjs.scene2Code.GDspriteObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.scene2Code.GDspriteObjects4 */
{for(var i = 0, len = gdjs.scene2Code.GDspriteObjects4.length ;i < len;++i) {
    gdjs.scene2Code.GDspriteObjects4[i].getBehavior("Resizable").setHeight(4);
}
}}

}


{

/* Reuse gdjs.scene2Code.GDspriteObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.scene2Code.GDspriteObjects3.length;i<l;++i) {
    if ( gdjs.scene2Code.GDspriteObjects3[i].getBehavior("Resizable").getWidth() < 4 ) {
        isConditionTrue_0 = true;
        gdjs.scene2Code.GDspriteObjects3[k] = gdjs.scene2Code.GDspriteObjects3[i];
        ++k;
    }
}
gdjs.scene2Code.GDspriteObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.scene2Code.GDspriteObjects3 */
{for(var i = 0, len = gdjs.scene2Code.GDspriteObjects3.length ;i < len;++i) {
    gdjs.scene2Code.GDspriteObjects3[i].getBehavior("Resizable").setWidth(4);
}
}}

}


};gdjs.scene2Code.eventsList35 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.scene2Code.GDspriteObjects2, gdjs.scene2Code.GDspriteObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(24263436);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.scene2Code.GDspriteObjects3.length;i<l;++i) {
    if ( gdjs.scene2Code.GDspriteObjects3[i].getVariableNumber(gdjs.scene2Code.GDspriteObjects3[i].getVariables().getFromIndex(0)) == runtimeScene.getScene().getVariables().getFromIndex(13).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.scene2Code.GDspriteObjects3[k] = gdjs.scene2Code.GDspriteObjects3[i];
        ++k;
    }
}
gdjs.scene2Code.GDspriteObjects3.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("height"), gdjs.scene2Code.GDheightObjects3);
/* Reuse gdjs.scene2Code.GDspriteObjects3 */
gdjs.copyArray(runtimeScene.getObjects("width"), gdjs.scene2Code.GDwidthObjects3);
{for(var i = 0, len = gdjs.scene2Code.GDwidthObjects3.length ;i < len;++i) {
    gdjs.scene2Code.GDwidthObjects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString((( gdjs.scene2Code.GDspriteObjects3.length === 0 ) ? 0 :gdjs.scene2Code.GDspriteObjects3[0].getWidth())));
}
}{for(var i = 0, len = gdjs.scene2Code.GDheightObjects3.length ;i < len;++i) {
    gdjs.scene2Code.GDheightObjects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString((( gdjs.scene2Code.GDspriteObjects3.length === 0 ) ? 0 :gdjs.scene2Code.GDspriteObjects3[0].getHeight())));
}
}}

}


{

gdjs.copyArray(gdjs.scene2Code.GDspriteObjects2, gdjs.scene2Code.GDspriteObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.scene2Code.GDspriteObjects3.length;i<l;++i) {
    if ( gdjs.scene2Code.GDspriteObjects3[i].getVariableNumber(gdjs.scene2Code.GDspriteObjects3[i].getVariables().getFromIndex(0)) == runtimeScene.getScene().getVariables().getFromIndex(13).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.scene2Code.GDspriteObjects3[k] = gdjs.scene2Code.GDspriteObjects3[i];
        ++k;
    }
}
gdjs.scene2Code.GDspriteObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("behave"), gdjs.scene2Code.GDbehaveObjects3);
gdjs.copyArray(runtimeScene.getObjects("height"), gdjs.scene2Code.GDheightObjects3);
gdjs.copyArray(runtimeScene.getObjects("objectName2"), gdjs.scene2Code.GDobjectName2Objects3);
/* Reuse gdjs.scene2Code.GDspriteObjects3 */
gdjs.copyArray(runtimeScene.getObjects("width"), gdjs.scene2Code.GDwidthObjects3);
gdjs.copyArray(runtimeScene.getObjects("x"), gdjs.scene2Code.GDxObjects3);
gdjs.copyArray(runtimeScene.getObjects("y"), gdjs.scene2Code.GDyObjects3);
{for(var i = 0, len = gdjs.scene2Code.GDspriteObjects3.length ;i < len;++i) {
    gdjs.scene2Code.GDspriteObjects3[i].setX(gdjs.evtTools.common.toNumber((( gdjs.scene2Code.GDxObjects3.length === 0 ) ? "" :gdjs.scene2Code.GDxObjects3[0].getBehavior("Text").getText())));
}
}{for(var i = 0, len = gdjs.scene2Code.GDspriteObjects3.length ;i < len;++i) {
    gdjs.scene2Code.GDspriteObjects3[i].setY(gdjs.evtTools.common.toNumber((( gdjs.scene2Code.GDyObjects3.length === 0 ) ? "" :gdjs.scene2Code.GDyObjects3[0].getBehavior("Text").getText())));
}
}{for(var i = 0, len = gdjs.scene2Code.GDspriteObjects3.length ;i < len;++i) {
    gdjs.scene2Code.GDspriteObjects3[i].getBehavior("Resizable").setWidth(gdjs.evtTools.common.toNumber((( gdjs.scene2Code.GDwidthObjects3.length === 0 ) ? "" :gdjs.scene2Code.GDwidthObjects3[0].getBehavior("Text").getText())));
}
}{for(var i = 0, len = gdjs.scene2Code.GDspriteObjects3.length ;i < len;++i) {
    gdjs.scene2Code.GDspriteObjects3[i].getBehavior("Resizable").setHeight(gdjs.evtTools.common.toNumber((( gdjs.scene2Code.GDheightObjects3.length === 0 ) ? "" :gdjs.scene2Code.GDheightObjects3[0].getBehavior("Text").getText())));
}
}{runtimeScene.getGame().getVariables().getFromIndex(6).getChild(((gdjs.scene2Code.GDspriteObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.scene2Code.GDspriteObjects3[0].getVariables()).getFromIndex(1).getAsString()).getChild("behavior").setString((( gdjs.scene2Code.GDbehaveObjects3.length === 0 ) ? "" :gdjs.scene2Code.GDbehaveObjects3[0].getBehavior("Text").getText()));
}{for(var i = 0, len = gdjs.scene2Code.GDobjectName2Objects3.length ;i < len;++i) {
    gdjs.scene2Code.GDobjectName2Objects3[i].getBehavior("Text").setText(((gdjs.scene2Code.GDspriteObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.scene2Code.GDspriteObjects3[0].getVariables()).get("name").getAsString());
}
}
{ //Subevents
gdjs.scene2Code.eventsList34(runtimeScene);} //End of subevents
}

}


};gdjs.scene2Code.mapOfEmptyGDspriteObjects = Hashtable.newFrom({"sprite": []});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDobjectNameObjects1Objects = Hashtable.newFrom({"objectName": gdjs.scene2Code.GDobjectNameObjects1});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDaddObjects1Objects = Hashtable.newFrom({"add": gdjs.scene2Code.GDaddObjects1});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects1Objects = Hashtable.newFrom({"sprite": gdjs.scene2Code.GDspriteObjects1});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDobjectNameObjects1Objects = Hashtable.newFrom({"objectName": gdjs.scene2Code.GDobjectNameObjects1});
gdjs.scene2Code.eventsList36 = function(runtimeScene) {

};gdjs.scene2Code.eventsList37 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("sprite"), gdjs.scene2Code.GDspriteObjects2);

for (gdjs.scene2Code.forEachIndex3 = 0;gdjs.scene2Code.forEachIndex3 < gdjs.scene2Code.GDspriteObjects2.length;++gdjs.scene2Code.forEachIndex3) {
gdjs.copyArray(gdjs.scene2Code.GDobjectNameObjects1, gdjs.scene2Code.GDobjectNameObjects3);

gdjs.scene2Code.GDspriteObjects3.length = 0;


gdjs.scene2Code.forEachTemporary3 = gdjs.scene2Code.GDspriteObjects2[gdjs.scene2Code.forEachIndex3];
gdjs.scene2Code.GDspriteObjects3.push(gdjs.scene2Code.forEachTemporary3);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.scene2Code.GDspriteObjects3.length;i<l;++i) {
    if ( gdjs.scene2Code.GDspriteObjects3[i].getVariableString(gdjs.scene2Code.GDspriteObjects3[i].getVariables().get("name")) == (( gdjs.scene2Code.GDobjectNameObjects3.length === 0 ) ? "" :gdjs.scene2Code.GDobjectNameObjects3[0].getBehavior("Text").getText()) ) {
        isConditionTrue_0 = true;
        gdjs.scene2Code.GDspriteObjects3[k] = gdjs.scene2Code.GDspriteObjects3[i];
        ++k;
    }
}
gdjs.scene2Code.GDspriteObjects3.length = k;
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.scene2Code.GDspriteObjects3.length ;i < len;++i) {
    gdjs.scene2Code.GDspriteObjects3[i].deleteFromScene(runtimeScene);
}
}}
}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.camera.hideLayer(runtimeScene, "co");
}}

}


};gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDcreateObjects1Objects = Hashtable.newFrom({"create": gdjs.scene2Code.GDcreateObjects1});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDreObjects1Objects = Hashtable.newFrom({"re": gdjs.scene2Code.GDreObjects1});
gdjs.scene2Code.eventsList38 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.camera.hideLayer(runtimeScene, "co");
}}

}


};gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDcreateObjects1Objects = Hashtable.newFrom({"create": gdjs.scene2Code.GDcreateObjects1});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDreObjects1Objects = Hashtable.newFrom({"re": gdjs.scene2Code.GDreObjects1});
gdjs.scene2Code.eventsList39 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.camera.hideLayer(runtimeScene, "co");
}}

}


};gdjs.scene2Code.mapOfEmptyGDdragNdropObjects = Hashtable.newFrom({"dragNdrop": []});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects1Objects = Hashtable.newFrom({"sprite": gdjs.scene2Code.GDspriteObjects1});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects1Objects = Hashtable.newFrom({"sprite": gdjs.scene2Code.GDspriteObjects1});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDobjectNameObjects1Objects = Hashtable.newFrom({"objectName": gdjs.scene2Code.GDobjectNameObjects1});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDdragNdropObjects1Objects = Hashtable.newFrom({"dragNdrop": gdjs.scene2Code.GDdragNdropObjects1});
gdjs.scene2Code.userFunc0xec5f58 = function GDJSInlineCode(runtimeScene) {
"use strict";
const ar = []
for (let childName in runtimeScene.getVariables().get("objects").getAllChildren()){
    ar.push(childName)
}
runtimeScene.getVariables().get("list").fromJSON(JSON.stringify(ar))
runtimeScene.getGame().getVariables().get("objectList").fromJSON(JSON.stringify(ar))
console.log(ar)
};
gdjs.scene2Code.eventsList40 = function(runtimeScene) {

{


gdjs.scene2Code.userFunc0xec5f58(runtimeScene);

}


};gdjs.scene2Code.mapOfEmptyGDobjectNameObjects = Hashtable.newFrom({"objectName": []});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDobjectNameObjects2Objects = Hashtable.newFrom({"objectName": gdjs.scene2Code.GDobjectNameObjects2});
gdjs.scene2Code.eventsList41 = function(runtimeScene) {

};gdjs.scene2Code.eventsList42 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{


const repeatCount2 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(2));
for (let repeatIndex2 = 0;repeatIndex2 < repeatCount2;++repeatIndex2) {
gdjs.copyArray(gdjs.scene2Code.GDobjectNameObjects1, gdjs.scene2Code.GDobjectNameObjects2);


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDobjectNameObjects2Objects, 1080, gdjs.scene2Code.localVariables[0].getFromIndex(0).getAsNumber(), "object_select");
}{for(var i = 0, len = gdjs.scene2Code.GDobjectNameObjects2.length ;i < len;++i) {
    gdjs.scene2Code.GDobjectNameObjects2[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(2).getChild(gdjs.scene2Code.localVariables[0].getFromIndex(1).getAsNumber()).getAsString());
}
}{gdjs.scene2Code.localVariables[0].getFromIndex(1).add(1);
}{gdjs.scene2Code.localVariables[0].getFromIndex(0).add(32);
}}
}

}


};gdjs.scene2Code.eventsList43 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "a");
if (isConditionTrue_0) {
{gdjs.fileSystem.makeDirectory(gdjs.fileSystem.getDesktopPath(runtimeScene) + gdjs.fileSystem.getPathDelimiter() + "hack", gdjs.VariablesContainer.badVariable);
}
{ //Subevents
gdjs.scene2Code.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "c");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(10), false, false);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(10).setBoolean(true);
}{runtimeScene.getScene().getVariables().getFromIndex(5).setNumber(0);
}{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(8)), runtimeScene.getGame().getVariables().getFromIndex(8));
}
{ //Subevents
gdjs.scene2Code.eventsList2(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
{
}

}


{



}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("countr", variable);
}
gdjs.scene2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(10), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.scene2Code.mapOfEmptyGDspriteObjects) > 0;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("state"), gdjs.scene2Code.GDstateObjects1);
{for(var i = 0, len = gdjs.scene2Code.GDstateObjects1.length ;i < len;++i) {
    gdjs.scene2Code.GDstateObjects1[i].getBehavior("Text").setText("collecting object position....");
}
}{gdjs.evtTools.variable.variableClearChildren(runtimeScene.getGame().getVariables().getFromIndex(1));
}
{ //Subevents
gdjs.scene2Code.eventsList5(runtimeScene);} //End of subevents
}
gdjs.scene2Code.localVariables.pop();

}


{



}


{


gdjs.scene2Code.eventsList9(runtimeScene);
}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(3)) == "u";
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(6), false, false);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(6).setBoolean(true);
}{runtimeScene.getScene().getVariables().getFromIndex(5).add(1);
}{runtimeScene.getScene().getVariables().getFromIndex(3).setString("p");
}{runtimeScene.getScene().getVariables().getFromIndex(6).setBoolean(false);
}}

}


{


gdjs.scene2Code.eventsList24(runtimeScene);
}


{


gdjs.scene2Code.eventsList26(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("debug"), gdjs.scene2Code.GDdebugObjects1);
gdjs.copyArray(runtimeScene.getObjects("sprite"), gdjs.scene2Code.GDspriteObjects1);
{for(var i = 0, len = gdjs.scene2Code.GDdebugObjects1.length ;i < len;++i) {
    gdjs.scene2Code.GDdebugObjects1[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(3).getAsString() + gdjs.evtTools.string.newLine() + runtimeScene.getScene().getVariables().getFromIndex(5).getAsString() + gdjs.evtTools.string.newLine() + ((gdjs.scene2Code.GDspriteObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.scene2Code.GDspriteObjects1[0].getVariables()).getFromIndex(0).getAsString() + " instance of sprites: " + gdjs.evtTools.common.toString(gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects1Objects)));
}
}}

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("climb", variable);
}
gdjs.scene2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(3)) == "h";
if (isConditionTrue_0) {
{gdjs.scene2Code.localVariables[0].getFromIndex(0).setNumber(0);
}
{ //Subevents
gdjs.scene2Code.eventsList29(runtimeScene);} //End of subevents
}
gdjs.scene2Code.localVariables.pop();

}


{

gdjs.scene2Code.GDsaveObjects1.length = 0;


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("climb", variable);
}
gdjs.scene2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.scene2Code.GDsaveObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LControl");
if (isConditionTrue_2) {
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("save"), gdjs.scene2Code.GDsaveObjects2);
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtTools.input.cursorOnObject(gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDsaveObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_2) {
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_2) {
isConditionTrue_2 = false;
{isConditionTrue_2 = runtimeScene.getOnceTriggers().triggerOnce(24244404);
}
}
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.scene2Code.GDsaveObjects2.length; j < jLen ; ++j) {
        if ( gdjs.scene2Code.GDsaveObjects1_1final.indexOf(gdjs.scene2Code.GDsaveObjects2[j]) === -1 )
            gdjs.scene2Code.GDsaveObjects1_1final.push(gdjs.scene2Code.GDsaveObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.scene2Code.GDsaveObjects1_1final, gdjs.scene2Code.GDsaveObjects1);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.storage.writeStringInJSONFile("MGDproject", "object", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(0)));
}{gdjs.evtTools.storage.writeStringInJSONFile("MGDproject", "resources", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(8)));
}{gdjs.evtTools.storage.writeStringInJSONFile("MGDproject", "script", runtimeScene.getGame().getVariables().getFromIndex(0).getAsString());
}{gdjs.evtTools.storage.writeStringInJSONFile("MGDproject", "data", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getGame().getVariables().getFromIndex(6)));
}{gdjs.evtTools.variable.variableClearChildren(runtimeScene.getScene().getVariables().getFromIndex(1));
}
{ //Subevents
gdjs.scene2Code.eventsList31(runtimeScene);} //End of subevents
}
gdjs.scene2Code.localVariables.pop();

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setBoolean(false);
variables._declare("stop", variable);
}
gdjs.scene2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "LControl"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(gdjs.scene2Code.localVariables[0].getFromIndex(0), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(24252724);
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "ide");
}}
gdjs.scene2Code.localVariables.pop();

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustResumed(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.scene2Code.eventsList32(runtimeScene);} //End of subevents
}

}


{



}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setString("0");
variables._declare("objN", variable);
}
gdjs.scene2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.scene2Code.eventsList33(runtimeScene);} //End of subevents
}
gdjs.scene2Code.localVariables.pop();

}


{

gdjs.copyArray(runtimeScene.getObjects("sprite"), gdjs.scene2Code.GDspriteObjects1);

for (gdjs.scene2Code.forEachIndex2 = 0;gdjs.scene2Code.forEachIndex2 < gdjs.scene2Code.GDspriteObjects1.length;++gdjs.scene2Code.forEachIndex2) {
gdjs.scene2Code.GDspriteObjects2.length = 0;


gdjs.scene2Code.forEachTemporary2 = gdjs.scene2Code.GDspriteObjects1[gdjs.scene2Code.forEachIndex2];
gdjs.scene2Code.GDspriteObjects2.push(gdjs.scene2Code.forEachTemporary2);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.scene2Code.eventsList35(runtimeScene);} //Subevents end.
}
}

}


{



}


{



}


{


let isConditionTrue_0 = false;
{
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("obj_scp"), gdjs.scene2Code.GDobj_9595scpObjects1);
{for(var i = 0, len = gdjs.scene2Code.GDobj_9595scpObjects1.length ;i < len;++i) {
    gdjs.scene2Code.GDobj_9595scpObjects1[i].getBehavior("Resizable").setHeight((gdjs.evtsExt__InputValidation__CountNewLines.func(runtimeScene, (gdjs.scene2Code.GDobj_9595scpObjects1[i].getBehavior("Text").getText()), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) * 23) + 23);
}
}{runtimeScene.getScene().getVariables().getFromIndex(11).setNumber(gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.scene2Code.mapOfEmptyGDspriteObjects) - 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("objectName"), gdjs.scene2Code.GDobjectNameObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDobjectNameObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Right");
}
if (isConditionTrue_0) {
/* Reuse gdjs.scene2Code.GDobjectNameObjects1 */
{runtimeScene.getGame().getVariables().getFromIndex(3).setString(runtimeScene.getScene().getVariables().getFromIndex(8).getChild("images").getChild((( gdjs.scene2Code.GDobjectNameObjects1.length === 0 ) ? "" :gdjs.scene2Code.GDobjectNameObjects1[0].getBehavior("Text").getText())).getAsString());
}{runtimeScene.getGame().getVariables().getFromIndex(5).setString((( gdjs.scene2Code.GDobjectNameObjects1.length === 0 ) ? "" :gdjs.scene2Code.GDobjectNameObjects1[0].getBehavior("Text").getText()));
}{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "collEditor");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("add"), gdjs.scene2Code.GDaddObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDaddObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "co");
}{runtimeScene.getScene().getVariables().getFromIndex(7).setString(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(4)));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("sprite"), gdjs.scene2Code.GDspriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(24280412);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.scene2Code.GDspriteObjects1 */
{for(var i = 0, len = gdjs.scene2Code.GDspriteObjects1.length ;i < len;++i) {
    gdjs.scene2Code.GDspriteObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("objectName"), gdjs.scene2Code.GDobjectNameObjects1);

{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setString("\"");
variables._declare("json1", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("");
variables._declare("name", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("\":{\"animated\":false,\"animation\":[],\"image\":0,\"name\":\"sprite\",\"script\":\"0\"}}");
variables._declare("json2", variable);
}
gdjs.scene2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDobjectNameObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(15), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(24281636);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.scene2Code.GDobjectNameObjects1 */
{gdjs.evtTools.variable.variableRemoveChild(runtimeScene.getScene().getVariables().getFromIndex(0), (( gdjs.scene2Code.GDobjectNameObjects1.length === 0 ) ? "" :gdjs.scene2Code.GDobjectNameObjects1[0].getBehavior("Text").getText()));
}{gdjs.evtTools.variable.variableRemoveChild(runtimeScene.getScene().getVariables().getFromIndex(8).getChild("images"), (( gdjs.scene2Code.GDobjectNameObjects1.length === 0 ) ? "" :gdjs.scene2Code.GDobjectNameObjects1[0].getBehavior("Text").getText()));
}
{ //Subevents
gdjs.scene2Code.eventsList37(runtimeScene);} //End of subevents
}
gdjs.scene2Code.localVariables.pop();

}


{

gdjs.copyArray(runtimeScene.getObjects("create"), gdjs.scene2Code.GDcreateObjects1);

{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setString("\"");
variables._declare("json1", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("");
variables._declare("name", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("\":{\"animated\":false,\"animation\":[],\"image\":0,\"name\":\"sprite\",\"script\":\"0\"}}");
variables._declare("json2", variable);
}
gdjs.scene2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "co");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDcreateObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(15), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(0)) > 0;
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("obj_name_giver"), gdjs.scene2Code.GDobj_9595name_9595giverObjects1);
gdjs.copyArray(runtimeScene.getObjects("re"), gdjs.scene2Code.GDreObjects1);
{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.string.subStr(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(0)), 0, gdjs.evtTools.string.strLen(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(0))) - 1) + "," + gdjs.scene2Code.localVariables[0].getFromIndex(0).getAsString() + (( gdjs.scene2Code.GDobj_9595name_9595giverObjects1.length === 0 ) ? "" :gdjs.scene2Code.GDobj_9595name_9595giverObjects1[0].getBehavior("Text").getText()) + gdjs.scene2Code.localVariables[0].getFromIndex(2).getAsString(), runtimeScene.getScene().getVariables().getFromIndex(0));
}{gdjs.evtsExt__UploadDownloadImageFile__UploadImageFile.func(runtimeScene, gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDreObjects1Objects, false, runtimeScene.getScene().getVariables().getFromIndex(8).getChild("images").getChild((( gdjs.scene2Code.GDobj_9595name_9595giverObjects1.length === 0 ) ? "" :gdjs.scene2Code.GDobj_9595name_9595giverObjects1[0].getBehavior("Text").getText())), gdjs.VariablesContainer.badVariable, gdjs.VariablesContainer.badVariable, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{runtimeScene.getGame().getVariables().getFromIndex(6).getChild((( gdjs.scene2Code.GDobj_9595name_9595giverObjects1.length === 0 ) ? "" :gdjs.scene2Code.GDobj_9595name_9595giverObjects1[0].getBehavior("Text").getText())).getChild("width").setNumber(32);
}{runtimeScene.getGame().getVariables().getFromIndex(6).getChild((( gdjs.scene2Code.GDobj_9595name_9595giverObjects1.length === 0 ) ? "" :gdjs.scene2Code.GDobj_9595name_9595giverObjects1[0].getBehavior("Text").getText())).getChild("height").setNumber(32);
}
{ //Subevents
gdjs.scene2Code.eventsList38(runtimeScene);} //End of subevents
}
gdjs.scene2Code.localVariables.pop();

}


{

gdjs.copyArray(runtimeScene.getObjects("create"), gdjs.scene2Code.GDcreateObjects1);

{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setString("\"");
variables._declare("json1", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("");
variables._declare("name", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("\":{\"animated\":false,\"animation\":[],\"image\":0,\"name\":\"sprite\",\"script\":\"0\"}}");
variables._declare("json2", variable);
}
gdjs.scene2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "co");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDcreateObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(15), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(0)) == 0;
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("obj_name_giver"), gdjs.scene2Code.GDobj_9595name_9595giverObjects1);
gdjs.copyArray(runtimeScene.getObjects("re"), gdjs.scene2Code.GDreObjects1);
{gdjs.evtTools.network.jsonToVariableStructure("{" + gdjs.scene2Code.localVariables[0].getFromIndex(0).getAsString() + (( gdjs.scene2Code.GDobj_9595name_9595giverObjects1.length === 0 ) ? "" :gdjs.scene2Code.GDobj_9595name_9595giverObjects1[0].getBehavior("Text").getText()) + gdjs.scene2Code.localVariables[0].getFromIndex(2).getAsString(), runtimeScene.getScene().getVariables().getFromIndex(0));
}{gdjs.evtsExt__UploadDownloadImageFile__UploadImageFile.func(runtimeScene, gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDreObjects1Objects, false, runtimeScene.getScene().getVariables().getFromIndex(8).getChild("images").getChild((( gdjs.scene2Code.GDobj_9595name_9595giverObjects1.length === 0 ) ? "" :gdjs.scene2Code.GDobj_9595name_9595giverObjects1[0].getBehavior("Text").getText())), gdjs.VariablesContainer.badVariable, gdjs.VariablesContainer.badVariable, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{runtimeScene.getGame().getVariables().getFromIndex(6).getChild((( gdjs.scene2Code.GDobj_9595name_9595giverObjects1.length === 0 ) ? "" :gdjs.scene2Code.GDobj_9595name_9595giverObjects1[0].getBehavior("Text").getText())).getChild("width").setNumber(32);
}{runtimeScene.getGame().getVariables().getFromIndex(6).getChild((( gdjs.scene2Code.GDobj_9595name_9595giverObjects1.length === 0 ) ? "" :gdjs.scene2Code.GDobj_9595name_9595giverObjects1[0].getBehavior("Text").getText())).getChild("height").setNumber(32);
}
{ //Subevents
gdjs.scene2Code.eventsList39(runtimeScene);} //End of subevents
}
gdjs.scene2Code.localVariables.pop();

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setString("0");
variables._declare("cn", variable);
}
gdjs.scene2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{
}
gdjs.scene2Code.localVariables.pop();

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("dragNdrop"), gdjs.scene2Code.GDdragNdropObjects1);
{for(var i = 0, len = gdjs.scene2Code.GDdragNdropObjects1.length ;i < len;++i) {
    gdjs.scene2Code.GDdragNdropObjects1[i].setPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0),gdjs.evtTools.input.getCursorY(runtimeScene, "", 0));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.scene2Code.mapOfEmptyGDdragNdropObjects) > 0;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("dragNdrop"), gdjs.scene2Code.GDdragNdropObjects1);
gdjs.scene2Code.GDspriteObjects1.length = 0;

{for(var i = 0, len = gdjs.scene2Code.GDdragNdropObjects1.length ;i < len;++i) {
    gdjs.scene2Code.GDdragNdropObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects1Objects, gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), "");
}{for(var i = 0, len = gdjs.scene2Code.GDspriteObjects1.length ;i < len;++i) {
    gdjs.scene2Code.GDspriteObjects1[i].returnVariable(gdjs.scene2Code.GDspriteObjects1[i].getVariables().getFromIndex(1)).setString(runtimeScene.getScene().getVariables().getFromIndex(16).getAsString());
}
}{gdjs.evtsExt__resize_image_from_url__LoadURLIntoSprite.func(runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(8).getChild("images").getChild(((gdjs.scene2Code.GDspriteObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.scene2Code.GDspriteObjects1[0].getVariables()).get("name").getAsString()).getAsString(), gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects1Objects, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("objectName"), gdjs.scene2Code.GDobjectNameObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDobjectNameObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(24296964);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.scene2Code.GDobjectNameObjects1 */
gdjs.scene2Code.GDdragNdropObjects1.length = 0;

{runtimeScene.getScene().getVariables().getFromIndex(16).setString((( gdjs.scene2Code.GDobjectNameObjects1.length === 0 ) ? "" :gdjs.scene2Code.GDobjectNameObjects1[0].getBehavior("Text").getText()));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDdragNdropObjects1Objects, gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), "");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(0)) != gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(2));
if (isConditionTrue_0) {

{ //Subevents
gdjs.scene2Code.eventsList40(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + (gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene) * 180), "", 0);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - (gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene) * 180), "", 0);
}}

}


{



}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(50);
variables._declare("count", variable);
}
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("climb", variable);
}
gdjs.scene2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(2)) != gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.scene2Code.mapOfEmptyGDobjectNameObjects);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("objectName"), gdjs.scene2Code.GDobjectNameObjects1);
{for(var i = 0, len = gdjs.scene2Code.GDobjectNameObjects1.length ;i < len;++i) {
    gdjs.scene2Code.GDobjectNameObjects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.scene2Code.eventsList42(runtimeScene);} //End of subevents
}
gdjs.scene2Code.localVariables.pop();

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.scene2Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.scene2Code.GDspriteObjects1.length = 0;
gdjs.scene2Code.GDspriteObjects2.length = 0;
gdjs.scene2Code.GDspriteObjects3.length = 0;
gdjs.scene2Code.GDspriteObjects4.length = 0;
gdjs.scene2Code.GDspriteObjects5.length = 0;
gdjs.scene2Code.GDspriteObjects6.length = 0;
gdjs.scene2Code.GDspriteObjects7.length = 0;
gdjs.scene2Code.GDspriteObjects8.length = 0;
gdjs.scene2Code.GDspriteObjects9.length = 0;
gdjs.scene2Code.GDspriteObjects10.length = 0;
gdjs.scene2Code.GDdebugObjects1.length = 0;
gdjs.scene2Code.GDdebugObjects2.length = 0;
gdjs.scene2Code.GDdebugObjects3.length = 0;
gdjs.scene2Code.GDdebugObjects4.length = 0;
gdjs.scene2Code.GDdebugObjects5.length = 0;
gdjs.scene2Code.GDdebugObjects6.length = 0;
gdjs.scene2Code.GDdebugObjects7.length = 0;
gdjs.scene2Code.GDdebugObjects8.length = 0;
gdjs.scene2Code.GDdebugObjects9.length = 0;
gdjs.scene2Code.GDdebugObjects10.length = 0;
gdjs.scene2Code.GDdialougObjects1.length = 0;
gdjs.scene2Code.GDdialougObjects2.length = 0;
gdjs.scene2Code.GDdialougObjects3.length = 0;
gdjs.scene2Code.GDdialougObjects4.length = 0;
gdjs.scene2Code.GDdialougObjects5.length = 0;
gdjs.scene2Code.GDdialougObjects6.length = 0;
gdjs.scene2Code.GDdialougObjects7.length = 0;
gdjs.scene2Code.GDdialougObjects8.length = 0;
gdjs.scene2Code.GDdialougObjects9.length = 0;
gdjs.scene2Code.GDdialougObjects10.length = 0;
gdjs.scene2Code.GDobject_9595var_9595inputObjects1.length = 0;
gdjs.scene2Code.GDobject_9595var_9595inputObjects2.length = 0;
gdjs.scene2Code.GDobject_9595var_9595inputObjects3.length = 0;
gdjs.scene2Code.GDobject_9595var_9595inputObjects4.length = 0;
gdjs.scene2Code.GDobject_9595var_9595inputObjects5.length = 0;
gdjs.scene2Code.GDobject_9595var_9595inputObjects6.length = 0;
gdjs.scene2Code.GDobject_9595var_9595inputObjects7.length = 0;
gdjs.scene2Code.GDobject_9595var_9595inputObjects8.length = 0;
gdjs.scene2Code.GDobject_9595var_9595inputObjects9.length = 0;
gdjs.scene2Code.GDobject_9595var_9595inputObjects10.length = 0;
gdjs.scene2Code.GDobjectNamesObjects1.length = 0;
gdjs.scene2Code.GDobjectNamesObjects2.length = 0;
gdjs.scene2Code.GDobjectNamesObjects3.length = 0;
gdjs.scene2Code.GDobjectNamesObjects4.length = 0;
gdjs.scene2Code.GDobjectNamesObjects5.length = 0;
gdjs.scene2Code.GDobjectNamesObjects6.length = 0;
gdjs.scene2Code.GDobjectNamesObjects7.length = 0;
gdjs.scene2Code.GDobjectNamesObjects8.length = 0;
gdjs.scene2Code.GDobjectNamesObjects9.length = 0;
gdjs.scene2Code.GDobjectNamesObjects10.length = 0;
gdjs.scene2Code.GDobjectNameObjects1.length = 0;
gdjs.scene2Code.GDobjectNameObjects2.length = 0;
gdjs.scene2Code.GDobjectNameObjects3.length = 0;
gdjs.scene2Code.GDobjectNameObjects4.length = 0;
gdjs.scene2Code.GDobjectNameObjects5.length = 0;
gdjs.scene2Code.GDobjectNameObjects6.length = 0;
gdjs.scene2Code.GDobjectNameObjects7.length = 0;
gdjs.scene2Code.GDobjectNameObjects8.length = 0;
gdjs.scene2Code.GDobjectNameObjects9.length = 0;
gdjs.scene2Code.GDobjectNameObjects10.length = 0;
gdjs.scene2Code.GDdragNdropObjects1.length = 0;
gdjs.scene2Code.GDdragNdropObjects2.length = 0;
gdjs.scene2Code.GDdragNdropObjects3.length = 0;
gdjs.scene2Code.GDdragNdropObjects4.length = 0;
gdjs.scene2Code.GDdragNdropObjects5.length = 0;
gdjs.scene2Code.GDdragNdropObjects6.length = 0;
gdjs.scene2Code.GDdragNdropObjects7.length = 0;
gdjs.scene2Code.GDdragNdropObjects8.length = 0;
gdjs.scene2Code.GDdragNdropObjects9.length = 0;
gdjs.scene2Code.GDdragNdropObjects10.length = 0;
gdjs.scene2Code.GDobj_9595scpObjects1.length = 0;
gdjs.scene2Code.GDobj_9595scpObjects2.length = 0;
gdjs.scene2Code.GDobj_9595scpObjects3.length = 0;
gdjs.scene2Code.GDobj_9595scpObjects4.length = 0;
gdjs.scene2Code.GDobj_9595scpObjects5.length = 0;
gdjs.scene2Code.GDobj_9595scpObjects6.length = 0;
gdjs.scene2Code.GDobj_9595scpObjects7.length = 0;
gdjs.scene2Code.GDobj_9595scpObjects8.length = 0;
gdjs.scene2Code.GDobj_9595scpObjects9.length = 0;
gdjs.scene2Code.GDobj_9595scpObjects10.length = 0;
gdjs.scene2Code.GDobjectName2Objects1.length = 0;
gdjs.scene2Code.GDobjectName2Objects2.length = 0;
gdjs.scene2Code.GDobjectName2Objects3.length = 0;
gdjs.scene2Code.GDobjectName2Objects4.length = 0;
gdjs.scene2Code.GDobjectName2Objects5.length = 0;
gdjs.scene2Code.GDobjectName2Objects6.length = 0;
gdjs.scene2Code.GDobjectName2Objects7.length = 0;
gdjs.scene2Code.GDobjectName2Objects8.length = 0;
gdjs.scene2Code.GDobjectName2Objects9.length = 0;
gdjs.scene2Code.GDobjectName2Objects10.length = 0;
gdjs.scene2Code.GDfake_9595cuObjects1.length = 0;
gdjs.scene2Code.GDfake_9595cuObjects2.length = 0;
gdjs.scene2Code.GDfake_9595cuObjects3.length = 0;
gdjs.scene2Code.GDfake_9595cuObjects4.length = 0;
gdjs.scene2Code.GDfake_9595cuObjects5.length = 0;
gdjs.scene2Code.GDfake_9595cuObjects6.length = 0;
gdjs.scene2Code.GDfake_9595cuObjects7.length = 0;
gdjs.scene2Code.GDfake_9595cuObjects8.length = 0;
gdjs.scene2Code.GDfake_9595cuObjects9.length = 0;
gdjs.scene2Code.GDfake_9595cuObjects10.length = 0;
gdjs.scene2Code.GDijObjects1.length = 0;
gdjs.scene2Code.GDijObjects2.length = 0;
gdjs.scene2Code.GDijObjects3.length = 0;
gdjs.scene2Code.GDijObjects4.length = 0;
gdjs.scene2Code.GDijObjects5.length = 0;
gdjs.scene2Code.GDijObjects6.length = 0;
gdjs.scene2Code.GDijObjects7.length = 0;
gdjs.scene2Code.GDijObjects8.length = 0;
gdjs.scene2Code.GDijObjects9.length = 0;
gdjs.scene2Code.GDijObjects10.length = 0;
gdjs.scene2Code.GDscrObjects1.length = 0;
gdjs.scene2Code.GDscrObjects2.length = 0;
gdjs.scene2Code.GDscrObjects3.length = 0;
gdjs.scene2Code.GDscrObjects4.length = 0;
gdjs.scene2Code.GDscrObjects5.length = 0;
gdjs.scene2Code.GDscrObjects6.length = 0;
gdjs.scene2Code.GDscrObjects7.length = 0;
gdjs.scene2Code.GDscrObjects8.length = 0;
gdjs.scene2Code.GDscrObjects9.length = 0;
gdjs.scene2Code.GDscrObjects10.length = 0;
gdjs.scene2Code.GDwidthObjects1.length = 0;
gdjs.scene2Code.GDwidthObjects2.length = 0;
gdjs.scene2Code.GDwidthObjects3.length = 0;
gdjs.scene2Code.GDwidthObjects4.length = 0;
gdjs.scene2Code.GDwidthObjects5.length = 0;
gdjs.scene2Code.GDwidthObjects6.length = 0;
gdjs.scene2Code.GDwidthObjects7.length = 0;
gdjs.scene2Code.GDwidthObjects8.length = 0;
gdjs.scene2Code.GDwidthObjects9.length = 0;
gdjs.scene2Code.GDwidthObjects10.length = 0;
gdjs.scene2Code.GDheightObjects1.length = 0;
gdjs.scene2Code.GDheightObjects2.length = 0;
gdjs.scene2Code.GDheightObjects3.length = 0;
gdjs.scene2Code.GDheightObjects4.length = 0;
gdjs.scene2Code.GDheightObjects5.length = 0;
gdjs.scene2Code.GDheightObjects6.length = 0;
gdjs.scene2Code.GDheightObjects7.length = 0;
gdjs.scene2Code.GDheightObjects8.length = 0;
gdjs.scene2Code.GDheightObjects9.length = 0;
gdjs.scene2Code.GDheightObjects10.length = 0;
gdjs.scene2Code.GDxObjects1.length = 0;
gdjs.scene2Code.GDxObjects2.length = 0;
gdjs.scene2Code.GDxObjects3.length = 0;
gdjs.scene2Code.GDxObjects4.length = 0;
gdjs.scene2Code.GDxObjects5.length = 0;
gdjs.scene2Code.GDxObjects6.length = 0;
gdjs.scene2Code.GDxObjects7.length = 0;
gdjs.scene2Code.GDxObjects8.length = 0;
gdjs.scene2Code.GDxObjects9.length = 0;
gdjs.scene2Code.GDxObjects10.length = 0;
gdjs.scene2Code.GDyObjects1.length = 0;
gdjs.scene2Code.GDyObjects2.length = 0;
gdjs.scene2Code.GDyObjects3.length = 0;
gdjs.scene2Code.GDyObjects4.length = 0;
gdjs.scene2Code.GDyObjects5.length = 0;
gdjs.scene2Code.GDyObjects6.length = 0;
gdjs.scene2Code.GDyObjects7.length = 0;
gdjs.scene2Code.GDyObjects8.length = 0;
gdjs.scene2Code.GDyObjects9.length = 0;
gdjs.scene2Code.GDyObjects10.length = 0;
gdjs.scene2Code.GDNewTextObjects1.length = 0;
gdjs.scene2Code.GDNewTextObjects2.length = 0;
gdjs.scene2Code.GDNewTextObjects3.length = 0;
gdjs.scene2Code.GDNewTextObjects4.length = 0;
gdjs.scene2Code.GDNewTextObjects5.length = 0;
gdjs.scene2Code.GDNewTextObjects6.length = 0;
gdjs.scene2Code.GDNewTextObjects7.length = 0;
gdjs.scene2Code.GDNewTextObjects8.length = 0;
gdjs.scene2Code.GDNewTextObjects9.length = 0;
gdjs.scene2Code.GDNewTextObjects10.length = 0;
gdjs.scene2Code.GDstateObjects1.length = 0;
gdjs.scene2Code.GDstateObjects2.length = 0;
gdjs.scene2Code.GDstateObjects3.length = 0;
gdjs.scene2Code.GDstateObjects4.length = 0;
gdjs.scene2Code.GDstateObjects5.length = 0;
gdjs.scene2Code.GDstateObjects6.length = 0;
gdjs.scene2Code.GDstateObjects7.length = 0;
gdjs.scene2Code.GDstateObjects8.length = 0;
gdjs.scene2Code.GDstateObjects9.length = 0;
gdjs.scene2Code.GDstateObjects10.length = 0;
gdjs.scene2Code.GDboxObjects1.length = 0;
gdjs.scene2Code.GDboxObjects2.length = 0;
gdjs.scene2Code.GDboxObjects3.length = 0;
gdjs.scene2Code.GDboxObjects4.length = 0;
gdjs.scene2Code.GDboxObjects5.length = 0;
gdjs.scene2Code.GDboxObjects6.length = 0;
gdjs.scene2Code.GDboxObjects7.length = 0;
gdjs.scene2Code.GDboxObjects8.length = 0;
gdjs.scene2Code.GDboxObjects9.length = 0;
gdjs.scene2Code.GDboxObjects10.length = 0;
gdjs.scene2Code.GDaddObjects1.length = 0;
gdjs.scene2Code.GDaddObjects2.length = 0;
gdjs.scene2Code.GDaddObjects3.length = 0;
gdjs.scene2Code.GDaddObjects4.length = 0;
gdjs.scene2Code.GDaddObjects5.length = 0;
gdjs.scene2Code.GDaddObjects6.length = 0;
gdjs.scene2Code.GDaddObjects7.length = 0;
gdjs.scene2Code.GDaddObjects8.length = 0;
gdjs.scene2Code.GDaddObjects9.length = 0;
gdjs.scene2Code.GDaddObjects10.length = 0;
gdjs.scene2Code.GDobj_9595name_9595giverObjects1.length = 0;
gdjs.scene2Code.GDobj_9595name_9595giverObjects2.length = 0;
gdjs.scene2Code.GDobj_9595name_9595giverObjects3.length = 0;
gdjs.scene2Code.GDobj_9595name_9595giverObjects4.length = 0;
gdjs.scene2Code.GDobj_9595name_9595giverObjects5.length = 0;
gdjs.scene2Code.GDobj_9595name_9595giverObjects6.length = 0;
gdjs.scene2Code.GDobj_9595name_9595giverObjects7.length = 0;
gdjs.scene2Code.GDobj_9595name_9595giverObjects8.length = 0;
gdjs.scene2Code.GDobj_9595name_9595giverObjects9.length = 0;
gdjs.scene2Code.GDobj_9595name_9595giverObjects10.length = 0;
gdjs.scene2Code.GDcreateObjects1.length = 0;
gdjs.scene2Code.GDcreateObjects2.length = 0;
gdjs.scene2Code.GDcreateObjects3.length = 0;
gdjs.scene2Code.GDcreateObjects4.length = 0;
gdjs.scene2Code.GDcreateObjects5.length = 0;
gdjs.scene2Code.GDcreateObjects6.length = 0;
gdjs.scene2Code.GDcreateObjects7.length = 0;
gdjs.scene2Code.GDcreateObjects8.length = 0;
gdjs.scene2Code.GDcreateObjects9.length = 0;
gdjs.scene2Code.GDcreateObjects10.length = 0;
gdjs.scene2Code.GDreObjects1.length = 0;
gdjs.scene2Code.GDreObjects2.length = 0;
gdjs.scene2Code.GDreObjects3.length = 0;
gdjs.scene2Code.GDreObjects4.length = 0;
gdjs.scene2Code.GDreObjects5.length = 0;
gdjs.scene2Code.GDreObjects6.length = 0;
gdjs.scene2Code.GDreObjects7.length = 0;
gdjs.scene2Code.GDreObjects8.length = 0;
gdjs.scene2Code.GDreObjects9.length = 0;
gdjs.scene2Code.GDreObjects10.length = 0;
gdjs.scene2Code.GDscriptIDEObjects1.length = 0;
gdjs.scene2Code.GDscriptIDEObjects2.length = 0;
gdjs.scene2Code.GDscriptIDEObjects3.length = 0;
gdjs.scene2Code.GDscriptIDEObjects4.length = 0;
gdjs.scene2Code.GDscriptIDEObjects5.length = 0;
gdjs.scene2Code.GDscriptIDEObjects6.length = 0;
gdjs.scene2Code.GDscriptIDEObjects7.length = 0;
gdjs.scene2Code.GDscriptIDEObjects8.length = 0;
gdjs.scene2Code.GDscriptIDEObjects9.length = 0;
gdjs.scene2Code.GDscriptIDEObjects10.length = 0;
gdjs.scene2Code.GDexportObjects1.length = 0;
gdjs.scene2Code.GDexportObjects2.length = 0;
gdjs.scene2Code.GDexportObjects3.length = 0;
gdjs.scene2Code.GDexportObjects4.length = 0;
gdjs.scene2Code.GDexportObjects5.length = 0;
gdjs.scene2Code.GDexportObjects6.length = 0;
gdjs.scene2Code.GDexportObjects7.length = 0;
gdjs.scene2Code.GDexportObjects8.length = 0;
gdjs.scene2Code.GDexportObjects9.length = 0;
gdjs.scene2Code.GDexportObjects10.length = 0;
gdjs.scene2Code.GDbuttonObjects1.length = 0;
gdjs.scene2Code.GDbuttonObjects2.length = 0;
gdjs.scene2Code.GDbuttonObjects3.length = 0;
gdjs.scene2Code.GDbuttonObjects4.length = 0;
gdjs.scene2Code.GDbuttonObjects5.length = 0;
gdjs.scene2Code.GDbuttonObjects6.length = 0;
gdjs.scene2Code.GDbuttonObjects7.length = 0;
gdjs.scene2Code.GDbuttonObjects8.length = 0;
gdjs.scene2Code.GDbuttonObjects9.length = 0;
gdjs.scene2Code.GDbuttonObjects10.length = 0;
gdjs.scene2Code.GDhtmlObjects1.length = 0;
gdjs.scene2Code.GDhtmlObjects2.length = 0;
gdjs.scene2Code.GDhtmlObjects3.length = 0;
gdjs.scene2Code.GDhtmlObjects4.length = 0;
gdjs.scene2Code.GDhtmlObjects5.length = 0;
gdjs.scene2Code.GDhtmlObjects6.length = 0;
gdjs.scene2Code.GDhtmlObjects7.length = 0;
gdjs.scene2Code.GDhtmlObjects8.length = 0;
gdjs.scene2Code.GDhtmlObjects9.length = 0;
gdjs.scene2Code.GDhtmlObjects10.length = 0;
gdjs.scene2Code.GDmainMenuObjects1.length = 0;
gdjs.scene2Code.GDmainMenuObjects2.length = 0;
gdjs.scene2Code.GDmainMenuObjects3.length = 0;
gdjs.scene2Code.GDmainMenuObjects4.length = 0;
gdjs.scene2Code.GDmainMenuObjects5.length = 0;
gdjs.scene2Code.GDmainMenuObjects6.length = 0;
gdjs.scene2Code.GDmainMenuObjects7.length = 0;
gdjs.scene2Code.GDmainMenuObjects8.length = 0;
gdjs.scene2Code.GDmainMenuObjects9.length = 0;
gdjs.scene2Code.GDmainMenuObjects10.length = 0;
gdjs.scene2Code.GDsaveObjects1.length = 0;
gdjs.scene2Code.GDsaveObjects2.length = 0;
gdjs.scene2Code.GDsaveObjects3.length = 0;
gdjs.scene2Code.GDsaveObjects4.length = 0;
gdjs.scene2Code.GDsaveObjects5.length = 0;
gdjs.scene2Code.GDsaveObjects6.length = 0;
gdjs.scene2Code.GDsaveObjects7.length = 0;
gdjs.scene2Code.GDsaveObjects8.length = 0;
gdjs.scene2Code.GDsaveObjects9.length = 0;
gdjs.scene2Code.GDsaveObjects10.length = 0;
gdjs.scene2Code.GDbehaveObjects1.length = 0;
gdjs.scene2Code.GDbehaveObjects2.length = 0;
gdjs.scene2Code.GDbehaveObjects3.length = 0;
gdjs.scene2Code.GDbehaveObjects4.length = 0;
gdjs.scene2Code.GDbehaveObjects5.length = 0;
gdjs.scene2Code.GDbehaveObjects6.length = 0;
gdjs.scene2Code.GDbehaveObjects7.length = 0;
gdjs.scene2Code.GDbehaveObjects8.length = 0;
gdjs.scene2Code.GDbehaveObjects9.length = 0;
gdjs.scene2Code.GDbehaveObjects10.length = 0;
gdjs.scene2Code.GDmoreObjects1.length = 0;
gdjs.scene2Code.GDmoreObjects2.length = 0;
gdjs.scene2Code.GDmoreObjects3.length = 0;
gdjs.scene2Code.GDmoreObjects4.length = 0;
gdjs.scene2Code.GDmoreObjects5.length = 0;
gdjs.scene2Code.GDmoreObjects6.length = 0;
gdjs.scene2Code.GDmoreObjects7.length = 0;
gdjs.scene2Code.GDmoreObjects8.length = 0;
gdjs.scene2Code.GDmoreObjects9.length = 0;
gdjs.scene2Code.GDmoreObjects10.length = 0;
gdjs.scene2Code.GDNewSpriteObjects1.length = 0;
gdjs.scene2Code.GDNewSpriteObjects2.length = 0;
gdjs.scene2Code.GDNewSpriteObjects3.length = 0;
gdjs.scene2Code.GDNewSpriteObjects4.length = 0;
gdjs.scene2Code.GDNewSpriteObjects5.length = 0;
gdjs.scene2Code.GDNewSpriteObjects6.length = 0;
gdjs.scene2Code.GDNewSpriteObjects7.length = 0;
gdjs.scene2Code.GDNewSpriteObjects8.length = 0;
gdjs.scene2Code.GDNewSpriteObjects9.length = 0;
gdjs.scene2Code.GDNewSpriteObjects10.length = 0;

gdjs.scene2Code.eventsList43(runtimeScene);
gdjs.scene2Code.GDspriteObjects1.length = 0;
gdjs.scene2Code.GDspriteObjects2.length = 0;
gdjs.scene2Code.GDspriteObjects3.length = 0;
gdjs.scene2Code.GDspriteObjects4.length = 0;
gdjs.scene2Code.GDspriteObjects5.length = 0;
gdjs.scene2Code.GDspriteObjects6.length = 0;
gdjs.scene2Code.GDspriteObjects7.length = 0;
gdjs.scene2Code.GDspriteObjects8.length = 0;
gdjs.scene2Code.GDspriteObjects9.length = 0;
gdjs.scene2Code.GDspriteObjects10.length = 0;
gdjs.scene2Code.GDdebugObjects1.length = 0;
gdjs.scene2Code.GDdebugObjects2.length = 0;
gdjs.scene2Code.GDdebugObjects3.length = 0;
gdjs.scene2Code.GDdebugObjects4.length = 0;
gdjs.scene2Code.GDdebugObjects5.length = 0;
gdjs.scene2Code.GDdebugObjects6.length = 0;
gdjs.scene2Code.GDdebugObjects7.length = 0;
gdjs.scene2Code.GDdebugObjects8.length = 0;
gdjs.scene2Code.GDdebugObjects9.length = 0;
gdjs.scene2Code.GDdebugObjects10.length = 0;
gdjs.scene2Code.GDdialougObjects1.length = 0;
gdjs.scene2Code.GDdialougObjects2.length = 0;
gdjs.scene2Code.GDdialougObjects3.length = 0;
gdjs.scene2Code.GDdialougObjects4.length = 0;
gdjs.scene2Code.GDdialougObjects5.length = 0;
gdjs.scene2Code.GDdialougObjects6.length = 0;
gdjs.scene2Code.GDdialougObjects7.length = 0;
gdjs.scene2Code.GDdialougObjects8.length = 0;
gdjs.scene2Code.GDdialougObjects9.length = 0;
gdjs.scene2Code.GDdialougObjects10.length = 0;
gdjs.scene2Code.GDobject_9595var_9595inputObjects1.length = 0;
gdjs.scene2Code.GDobject_9595var_9595inputObjects2.length = 0;
gdjs.scene2Code.GDobject_9595var_9595inputObjects3.length = 0;
gdjs.scene2Code.GDobject_9595var_9595inputObjects4.length = 0;
gdjs.scene2Code.GDobject_9595var_9595inputObjects5.length = 0;
gdjs.scene2Code.GDobject_9595var_9595inputObjects6.length = 0;
gdjs.scene2Code.GDobject_9595var_9595inputObjects7.length = 0;
gdjs.scene2Code.GDobject_9595var_9595inputObjects8.length = 0;
gdjs.scene2Code.GDobject_9595var_9595inputObjects9.length = 0;
gdjs.scene2Code.GDobject_9595var_9595inputObjects10.length = 0;
gdjs.scene2Code.GDobjectNamesObjects1.length = 0;
gdjs.scene2Code.GDobjectNamesObjects2.length = 0;
gdjs.scene2Code.GDobjectNamesObjects3.length = 0;
gdjs.scene2Code.GDobjectNamesObjects4.length = 0;
gdjs.scene2Code.GDobjectNamesObjects5.length = 0;
gdjs.scene2Code.GDobjectNamesObjects6.length = 0;
gdjs.scene2Code.GDobjectNamesObjects7.length = 0;
gdjs.scene2Code.GDobjectNamesObjects8.length = 0;
gdjs.scene2Code.GDobjectNamesObjects9.length = 0;
gdjs.scene2Code.GDobjectNamesObjects10.length = 0;
gdjs.scene2Code.GDobjectNameObjects1.length = 0;
gdjs.scene2Code.GDobjectNameObjects2.length = 0;
gdjs.scene2Code.GDobjectNameObjects3.length = 0;
gdjs.scene2Code.GDobjectNameObjects4.length = 0;
gdjs.scene2Code.GDobjectNameObjects5.length = 0;
gdjs.scene2Code.GDobjectNameObjects6.length = 0;
gdjs.scene2Code.GDobjectNameObjects7.length = 0;
gdjs.scene2Code.GDobjectNameObjects8.length = 0;
gdjs.scene2Code.GDobjectNameObjects9.length = 0;
gdjs.scene2Code.GDobjectNameObjects10.length = 0;
gdjs.scene2Code.GDdragNdropObjects1.length = 0;
gdjs.scene2Code.GDdragNdropObjects2.length = 0;
gdjs.scene2Code.GDdragNdropObjects3.length = 0;
gdjs.scene2Code.GDdragNdropObjects4.length = 0;
gdjs.scene2Code.GDdragNdropObjects5.length = 0;
gdjs.scene2Code.GDdragNdropObjects6.length = 0;
gdjs.scene2Code.GDdragNdropObjects7.length = 0;
gdjs.scene2Code.GDdragNdropObjects8.length = 0;
gdjs.scene2Code.GDdragNdropObjects9.length = 0;
gdjs.scene2Code.GDdragNdropObjects10.length = 0;
gdjs.scene2Code.GDobj_9595scpObjects1.length = 0;
gdjs.scene2Code.GDobj_9595scpObjects2.length = 0;
gdjs.scene2Code.GDobj_9595scpObjects3.length = 0;
gdjs.scene2Code.GDobj_9595scpObjects4.length = 0;
gdjs.scene2Code.GDobj_9595scpObjects5.length = 0;
gdjs.scene2Code.GDobj_9595scpObjects6.length = 0;
gdjs.scene2Code.GDobj_9595scpObjects7.length = 0;
gdjs.scene2Code.GDobj_9595scpObjects8.length = 0;
gdjs.scene2Code.GDobj_9595scpObjects9.length = 0;
gdjs.scene2Code.GDobj_9595scpObjects10.length = 0;
gdjs.scene2Code.GDobjectName2Objects1.length = 0;
gdjs.scene2Code.GDobjectName2Objects2.length = 0;
gdjs.scene2Code.GDobjectName2Objects3.length = 0;
gdjs.scene2Code.GDobjectName2Objects4.length = 0;
gdjs.scene2Code.GDobjectName2Objects5.length = 0;
gdjs.scene2Code.GDobjectName2Objects6.length = 0;
gdjs.scene2Code.GDobjectName2Objects7.length = 0;
gdjs.scene2Code.GDobjectName2Objects8.length = 0;
gdjs.scene2Code.GDobjectName2Objects9.length = 0;
gdjs.scene2Code.GDobjectName2Objects10.length = 0;
gdjs.scene2Code.GDfake_9595cuObjects1.length = 0;
gdjs.scene2Code.GDfake_9595cuObjects2.length = 0;
gdjs.scene2Code.GDfake_9595cuObjects3.length = 0;
gdjs.scene2Code.GDfake_9595cuObjects4.length = 0;
gdjs.scene2Code.GDfake_9595cuObjects5.length = 0;
gdjs.scene2Code.GDfake_9595cuObjects6.length = 0;
gdjs.scene2Code.GDfake_9595cuObjects7.length = 0;
gdjs.scene2Code.GDfake_9595cuObjects8.length = 0;
gdjs.scene2Code.GDfake_9595cuObjects9.length = 0;
gdjs.scene2Code.GDfake_9595cuObjects10.length = 0;
gdjs.scene2Code.GDijObjects1.length = 0;
gdjs.scene2Code.GDijObjects2.length = 0;
gdjs.scene2Code.GDijObjects3.length = 0;
gdjs.scene2Code.GDijObjects4.length = 0;
gdjs.scene2Code.GDijObjects5.length = 0;
gdjs.scene2Code.GDijObjects6.length = 0;
gdjs.scene2Code.GDijObjects7.length = 0;
gdjs.scene2Code.GDijObjects8.length = 0;
gdjs.scene2Code.GDijObjects9.length = 0;
gdjs.scene2Code.GDijObjects10.length = 0;
gdjs.scene2Code.GDscrObjects1.length = 0;
gdjs.scene2Code.GDscrObjects2.length = 0;
gdjs.scene2Code.GDscrObjects3.length = 0;
gdjs.scene2Code.GDscrObjects4.length = 0;
gdjs.scene2Code.GDscrObjects5.length = 0;
gdjs.scene2Code.GDscrObjects6.length = 0;
gdjs.scene2Code.GDscrObjects7.length = 0;
gdjs.scene2Code.GDscrObjects8.length = 0;
gdjs.scene2Code.GDscrObjects9.length = 0;
gdjs.scene2Code.GDscrObjects10.length = 0;
gdjs.scene2Code.GDwidthObjects1.length = 0;
gdjs.scene2Code.GDwidthObjects2.length = 0;
gdjs.scene2Code.GDwidthObjects3.length = 0;
gdjs.scene2Code.GDwidthObjects4.length = 0;
gdjs.scene2Code.GDwidthObjects5.length = 0;
gdjs.scene2Code.GDwidthObjects6.length = 0;
gdjs.scene2Code.GDwidthObjects7.length = 0;
gdjs.scene2Code.GDwidthObjects8.length = 0;
gdjs.scene2Code.GDwidthObjects9.length = 0;
gdjs.scene2Code.GDwidthObjects10.length = 0;
gdjs.scene2Code.GDheightObjects1.length = 0;
gdjs.scene2Code.GDheightObjects2.length = 0;
gdjs.scene2Code.GDheightObjects3.length = 0;
gdjs.scene2Code.GDheightObjects4.length = 0;
gdjs.scene2Code.GDheightObjects5.length = 0;
gdjs.scene2Code.GDheightObjects6.length = 0;
gdjs.scene2Code.GDheightObjects7.length = 0;
gdjs.scene2Code.GDheightObjects8.length = 0;
gdjs.scene2Code.GDheightObjects9.length = 0;
gdjs.scene2Code.GDheightObjects10.length = 0;
gdjs.scene2Code.GDxObjects1.length = 0;
gdjs.scene2Code.GDxObjects2.length = 0;
gdjs.scene2Code.GDxObjects3.length = 0;
gdjs.scene2Code.GDxObjects4.length = 0;
gdjs.scene2Code.GDxObjects5.length = 0;
gdjs.scene2Code.GDxObjects6.length = 0;
gdjs.scene2Code.GDxObjects7.length = 0;
gdjs.scene2Code.GDxObjects8.length = 0;
gdjs.scene2Code.GDxObjects9.length = 0;
gdjs.scene2Code.GDxObjects10.length = 0;
gdjs.scene2Code.GDyObjects1.length = 0;
gdjs.scene2Code.GDyObjects2.length = 0;
gdjs.scene2Code.GDyObjects3.length = 0;
gdjs.scene2Code.GDyObjects4.length = 0;
gdjs.scene2Code.GDyObjects5.length = 0;
gdjs.scene2Code.GDyObjects6.length = 0;
gdjs.scene2Code.GDyObjects7.length = 0;
gdjs.scene2Code.GDyObjects8.length = 0;
gdjs.scene2Code.GDyObjects9.length = 0;
gdjs.scene2Code.GDyObjects10.length = 0;
gdjs.scene2Code.GDNewTextObjects1.length = 0;
gdjs.scene2Code.GDNewTextObjects2.length = 0;
gdjs.scene2Code.GDNewTextObjects3.length = 0;
gdjs.scene2Code.GDNewTextObjects4.length = 0;
gdjs.scene2Code.GDNewTextObjects5.length = 0;
gdjs.scene2Code.GDNewTextObjects6.length = 0;
gdjs.scene2Code.GDNewTextObjects7.length = 0;
gdjs.scene2Code.GDNewTextObjects8.length = 0;
gdjs.scene2Code.GDNewTextObjects9.length = 0;
gdjs.scene2Code.GDNewTextObjects10.length = 0;
gdjs.scene2Code.GDstateObjects1.length = 0;
gdjs.scene2Code.GDstateObjects2.length = 0;
gdjs.scene2Code.GDstateObjects3.length = 0;
gdjs.scene2Code.GDstateObjects4.length = 0;
gdjs.scene2Code.GDstateObjects5.length = 0;
gdjs.scene2Code.GDstateObjects6.length = 0;
gdjs.scene2Code.GDstateObjects7.length = 0;
gdjs.scene2Code.GDstateObjects8.length = 0;
gdjs.scene2Code.GDstateObjects9.length = 0;
gdjs.scene2Code.GDstateObjects10.length = 0;
gdjs.scene2Code.GDboxObjects1.length = 0;
gdjs.scene2Code.GDboxObjects2.length = 0;
gdjs.scene2Code.GDboxObjects3.length = 0;
gdjs.scene2Code.GDboxObjects4.length = 0;
gdjs.scene2Code.GDboxObjects5.length = 0;
gdjs.scene2Code.GDboxObjects6.length = 0;
gdjs.scene2Code.GDboxObjects7.length = 0;
gdjs.scene2Code.GDboxObjects8.length = 0;
gdjs.scene2Code.GDboxObjects9.length = 0;
gdjs.scene2Code.GDboxObjects10.length = 0;
gdjs.scene2Code.GDaddObjects1.length = 0;
gdjs.scene2Code.GDaddObjects2.length = 0;
gdjs.scene2Code.GDaddObjects3.length = 0;
gdjs.scene2Code.GDaddObjects4.length = 0;
gdjs.scene2Code.GDaddObjects5.length = 0;
gdjs.scene2Code.GDaddObjects6.length = 0;
gdjs.scene2Code.GDaddObjects7.length = 0;
gdjs.scene2Code.GDaddObjects8.length = 0;
gdjs.scene2Code.GDaddObjects9.length = 0;
gdjs.scene2Code.GDaddObjects10.length = 0;
gdjs.scene2Code.GDobj_9595name_9595giverObjects1.length = 0;
gdjs.scene2Code.GDobj_9595name_9595giverObjects2.length = 0;
gdjs.scene2Code.GDobj_9595name_9595giverObjects3.length = 0;
gdjs.scene2Code.GDobj_9595name_9595giverObjects4.length = 0;
gdjs.scene2Code.GDobj_9595name_9595giverObjects5.length = 0;
gdjs.scene2Code.GDobj_9595name_9595giverObjects6.length = 0;
gdjs.scene2Code.GDobj_9595name_9595giverObjects7.length = 0;
gdjs.scene2Code.GDobj_9595name_9595giverObjects8.length = 0;
gdjs.scene2Code.GDobj_9595name_9595giverObjects9.length = 0;
gdjs.scene2Code.GDobj_9595name_9595giverObjects10.length = 0;
gdjs.scene2Code.GDcreateObjects1.length = 0;
gdjs.scene2Code.GDcreateObjects2.length = 0;
gdjs.scene2Code.GDcreateObjects3.length = 0;
gdjs.scene2Code.GDcreateObjects4.length = 0;
gdjs.scene2Code.GDcreateObjects5.length = 0;
gdjs.scene2Code.GDcreateObjects6.length = 0;
gdjs.scene2Code.GDcreateObjects7.length = 0;
gdjs.scene2Code.GDcreateObjects8.length = 0;
gdjs.scene2Code.GDcreateObjects9.length = 0;
gdjs.scene2Code.GDcreateObjects10.length = 0;
gdjs.scene2Code.GDreObjects1.length = 0;
gdjs.scene2Code.GDreObjects2.length = 0;
gdjs.scene2Code.GDreObjects3.length = 0;
gdjs.scene2Code.GDreObjects4.length = 0;
gdjs.scene2Code.GDreObjects5.length = 0;
gdjs.scene2Code.GDreObjects6.length = 0;
gdjs.scene2Code.GDreObjects7.length = 0;
gdjs.scene2Code.GDreObjects8.length = 0;
gdjs.scene2Code.GDreObjects9.length = 0;
gdjs.scene2Code.GDreObjects10.length = 0;
gdjs.scene2Code.GDscriptIDEObjects1.length = 0;
gdjs.scene2Code.GDscriptIDEObjects2.length = 0;
gdjs.scene2Code.GDscriptIDEObjects3.length = 0;
gdjs.scene2Code.GDscriptIDEObjects4.length = 0;
gdjs.scene2Code.GDscriptIDEObjects5.length = 0;
gdjs.scene2Code.GDscriptIDEObjects6.length = 0;
gdjs.scene2Code.GDscriptIDEObjects7.length = 0;
gdjs.scene2Code.GDscriptIDEObjects8.length = 0;
gdjs.scene2Code.GDscriptIDEObjects9.length = 0;
gdjs.scene2Code.GDscriptIDEObjects10.length = 0;
gdjs.scene2Code.GDexportObjects1.length = 0;
gdjs.scene2Code.GDexportObjects2.length = 0;
gdjs.scene2Code.GDexportObjects3.length = 0;
gdjs.scene2Code.GDexportObjects4.length = 0;
gdjs.scene2Code.GDexportObjects5.length = 0;
gdjs.scene2Code.GDexportObjects6.length = 0;
gdjs.scene2Code.GDexportObjects7.length = 0;
gdjs.scene2Code.GDexportObjects8.length = 0;
gdjs.scene2Code.GDexportObjects9.length = 0;
gdjs.scene2Code.GDexportObjects10.length = 0;
gdjs.scene2Code.GDbuttonObjects1.length = 0;
gdjs.scene2Code.GDbuttonObjects2.length = 0;
gdjs.scene2Code.GDbuttonObjects3.length = 0;
gdjs.scene2Code.GDbuttonObjects4.length = 0;
gdjs.scene2Code.GDbuttonObjects5.length = 0;
gdjs.scene2Code.GDbuttonObjects6.length = 0;
gdjs.scene2Code.GDbuttonObjects7.length = 0;
gdjs.scene2Code.GDbuttonObjects8.length = 0;
gdjs.scene2Code.GDbuttonObjects9.length = 0;
gdjs.scene2Code.GDbuttonObjects10.length = 0;
gdjs.scene2Code.GDhtmlObjects1.length = 0;
gdjs.scene2Code.GDhtmlObjects2.length = 0;
gdjs.scene2Code.GDhtmlObjects3.length = 0;
gdjs.scene2Code.GDhtmlObjects4.length = 0;
gdjs.scene2Code.GDhtmlObjects5.length = 0;
gdjs.scene2Code.GDhtmlObjects6.length = 0;
gdjs.scene2Code.GDhtmlObjects7.length = 0;
gdjs.scene2Code.GDhtmlObjects8.length = 0;
gdjs.scene2Code.GDhtmlObjects9.length = 0;
gdjs.scene2Code.GDhtmlObjects10.length = 0;
gdjs.scene2Code.GDmainMenuObjects1.length = 0;
gdjs.scene2Code.GDmainMenuObjects2.length = 0;
gdjs.scene2Code.GDmainMenuObjects3.length = 0;
gdjs.scene2Code.GDmainMenuObjects4.length = 0;
gdjs.scene2Code.GDmainMenuObjects5.length = 0;
gdjs.scene2Code.GDmainMenuObjects6.length = 0;
gdjs.scene2Code.GDmainMenuObjects7.length = 0;
gdjs.scene2Code.GDmainMenuObjects8.length = 0;
gdjs.scene2Code.GDmainMenuObjects9.length = 0;
gdjs.scene2Code.GDmainMenuObjects10.length = 0;
gdjs.scene2Code.GDsaveObjects1.length = 0;
gdjs.scene2Code.GDsaveObjects2.length = 0;
gdjs.scene2Code.GDsaveObjects3.length = 0;
gdjs.scene2Code.GDsaveObjects4.length = 0;
gdjs.scene2Code.GDsaveObjects5.length = 0;
gdjs.scene2Code.GDsaveObjects6.length = 0;
gdjs.scene2Code.GDsaveObjects7.length = 0;
gdjs.scene2Code.GDsaveObjects8.length = 0;
gdjs.scene2Code.GDsaveObjects9.length = 0;
gdjs.scene2Code.GDsaveObjects10.length = 0;
gdjs.scene2Code.GDbehaveObjects1.length = 0;
gdjs.scene2Code.GDbehaveObjects2.length = 0;
gdjs.scene2Code.GDbehaveObjects3.length = 0;
gdjs.scene2Code.GDbehaveObjects4.length = 0;
gdjs.scene2Code.GDbehaveObjects5.length = 0;
gdjs.scene2Code.GDbehaveObjects6.length = 0;
gdjs.scene2Code.GDbehaveObjects7.length = 0;
gdjs.scene2Code.GDbehaveObjects8.length = 0;
gdjs.scene2Code.GDbehaveObjects9.length = 0;
gdjs.scene2Code.GDbehaveObjects10.length = 0;
gdjs.scene2Code.GDmoreObjects1.length = 0;
gdjs.scene2Code.GDmoreObjects2.length = 0;
gdjs.scene2Code.GDmoreObjects3.length = 0;
gdjs.scene2Code.GDmoreObjects4.length = 0;
gdjs.scene2Code.GDmoreObjects5.length = 0;
gdjs.scene2Code.GDmoreObjects6.length = 0;
gdjs.scene2Code.GDmoreObjects7.length = 0;
gdjs.scene2Code.GDmoreObjects8.length = 0;
gdjs.scene2Code.GDmoreObjects9.length = 0;
gdjs.scene2Code.GDmoreObjects10.length = 0;
gdjs.scene2Code.GDNewSpriteObjects1.length = 0;
gdjs.scene2Code.GDNewSpriteObjects2.length = 0;
gdjs.scene2Code.GDNewSpriteObjects3.length = 0;
gdjs.scene2Code.GDNewSpriteObjects4.length = 0;
gdjs.scene2Code.GDNewSpriteObjects5.length = 0;
gdjs.scene2Code.GDNewSpriteObjects6.length = 0;
gdjs.scene2Code.GDNewSpriteObjects7.length = 0;
gdjs.scene2Code.GDNewSpriteObjects8.length = 0;
gdjs.scene2Code.GDNewSpriteObjects9.length = 0;
gdjs.scene2Code.GDNewSpriteObjects10.length = 0;


return;

}

gdjs['scene2Code'] = gdjs.scene2Code;
