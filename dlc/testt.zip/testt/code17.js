gdjs.resourceCode = {};
gdjs.resourceCode.localVariables = [];
gdjs.resourceCode.GDNewTextObjects1= [];
gdjs.resourceCode.GDNewTextObjects2= [];
gdjs.resourceCode.GDimageObjects1= [];
gdjs.resourceCode.GDimageObjects2= [];
gdjs.resourceCode.GDaudoObjects1= [];
gdjs.resourceCode.GDaudoObjects2= [];
gdjs.resourceCode.GDimObjects1= [];
gdjs.resourceCode.GDimObjects2= [];
gdjs.resourceCode.GDauObjects1= [];
gdjs.resourceCode.GDauObjects2= [];
gdjs.resourceCode.GDimageAdObjects1= [];
gdjs.resourceCode.GDimageAdObjects2= [];
gdjs.resourceCode.GDaudioAdObjects1= [];
gdjs.resourceCode.GDaudioAdObjects2= [];


gdjs.resourceCode.userFunc0xf40a88 = function GDJSInlineCode(runtimeScene) {
"use strict";
const ar = []
for (let childName in runtimeScene.getGame().getVariables().get("re2").getChildNamed('images').getAllChildren()){
    ar.push(childName)
}
runtimeScene.getVariables().get("image2").fromJSON(JSON.stringify(ar))

const r = []
for (let childName in runtimeScene.getGame().getVariables().get("re2").getChildNamed('audio').getAllChildren()){
    r.push(childName)
}
runtimeScene.getVariables().get("audio").fromJSON(JSON.stringify(r))
console.log(r)
};
gdjs.resourceCode.eventsList0 = function(runtimeScene) {

{


gdjs.resourceCode.userFunc0xf40a88(runtimeScene);

}


};gdjs.resourceCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


};gdjs.resourceCode.mapOfGDgdjs_9546resourceCode_9546GDauObjects2Objects = Hashtable.newFrom({"au": gdjs.resourceCode.GDauObjects2});
gdjs.resourceCode.eventsList2 = function(runtimeScene) {

};gdjs.resourceCode.eventsList3 = function(runtimeScene) {

{



}


{


const repeatCount2 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(1));
for (let repeatIndex2 = 0;repeatIndex2 < repeatCount2;++repeatIndex2) {
gdjs.resourceCode.GDauObjects2.length = 0;


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.resourceCode.mapOfGDgdjs_9546resourceCode_9546GDauObjects2Objects, 0, 80 + (gdjs.resourceCode.localVariables[0].getFromIndex(0).getAsNumber() * 32), "");
}{for(var i = 0, len = gdjs.resourceCode.GDauObjects2.length ;i < len;++i) {
    gdjs.resourceCode.GDauObjects2[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.resourceCode.localVariables[0].getFromIndex(1).getAsNumber()).getAsString());
}
}{gdjs.resourceCode.localVariables[0].getFromIndex(0).add(1);
}{gdjs.resourceCode.localVariables[0].getFromIndex(1).add(1);
}}
}

}


};gdjs.resourceCode.mapOfGDgdjs_9546resourceCode_9546GDimObjects2Objects = Hashtable.newFrom({"im": gdjs.resourceCode.GDimObjects2});
gdjs.resourceCode.eventsList4 = function(runtimeScene) {

};gdjs.resourceCode.eventsList5 = function(runtimeScene) {

{



}


{


const repeatCount2 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(0));
for (let repeatIndex2 = 0;repeatIndex2 < repeatCount2;++repeatIndex2) {
gdjs.resourceCode.GDimObjects2.length = 0;


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.resourceCode.mapOfGDgdjs_9546resourceCode_9546GDimObjects2Objects, 0, 80 + (gdjs.resourceCode.localVariables[0].getFromIndex(0).getAsNumber() * 32), "");
}{for(var i = 0, len = gdjs.resourceCode.GDimObjects2.length ;i < len;++i) {
    gdjs.resourceCode.GDimObjects2[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(0).getChild(gdjs.resourceCode.localVariables[0].getFromIndex(1).getAsNumber()).getAsString());
}
}{gdjs.resourceCode.localVariables[0].getFromIndex(0).add(1);
}{gdjs.resourceCode.localVariables[0].getFromIndex(1).add(1);
}}
}

}


};gdjs.resourceCode.eventsList6 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(27018228);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.resourceCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.resourceCode.eventsList1(runtimeScene);} //End of subevents
}

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(1);
variables._declare("count", variable);
}
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("count1", variable);
}
gdjs.resourceCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(27019396);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(1)) > 0;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.resourceCode.eventsList3(runtimeScene);} //End of subevents
}
gdjs.resourceCode.localVariables.pop();

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(1);
variables._declare("count", variable);
}
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("count1", variable);
}
gdjs.resourceCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(27022356);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(0)) > 0;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.resourceCode.eventsList5(runtimeScene);} //End of subevents
}
gdjs.resourceCode.localVariables.pop();

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}}

}


};

gdjs.resourceCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.resourceCode.GDNewTextObjects1.length = 0;
gdjs.resourceCode.GDNewTextObjects2.length = 0;
gdjs.resourceCode.GDimageObjects1.length = 0;
gdjs.resourceCode.GDimageObjects2.length = 0;
gdjs.resourceCode.GDaudoObjects1.length = 0;
gdjs.resourceCode.GDaudoObjects2.length = 0;
gdjs.resourceCode.GDimObjects1.length = 0;
gdjs.resourceCode.GDimObjects2.length = 0;
gdjs.resourceCode.GDauObjects1.length = 0;
gdjs.resourceCode.GDauObjects2.length = 0;
gdjs.resourceCode.GDimageAdObjects1.length = 0;
gdjs.resourceCode.GDimageAdObjects2.length = 0;
gdjs.resourceCode.GDaudioAdObjects1.length = 0;
gdjs.resourceCode.GDaudioAdObjects2.length = 0;

gdjs.resourceCode.eventsList6(runtimeScene);
gdjs.resourceCode.GDNewTextObjects1.length = 0;
gdjs.resourceCode.GDNewTextObjects2.length = 0;
gdjs.resourceCode.GDimageObjects1.length = 0;
gdjs.resourceCode.GDimageObjects2.length = 0;
gdjs.resourceCode.GDaudoObjects1.length = 0;
gdjs.resourceCode.GDaudoObjects2.length = 0;
gdjs.resourceCode.GDimObjects1.length = 0;
gdjs.resourceCode.GDimObjects2.length = 0;
gdjs.resourceCode.GDauObjects1.length = 0;
gdjs.resourceCode.GDauObjects2.length = 0;
gdjs.resourceCode.GDimageAdObjects1.length = 0;
gdjs.resourceCode.GDimageAdObjects2.length = 0;
gdjs.resourceCode.GDaudioAdObjects1.length = 0;
gdjs.resourceCode.GDaudioAdObjects2.length = 0;


return;

}

gdjs['resourceCode'] = gdjs.resourceCode;
