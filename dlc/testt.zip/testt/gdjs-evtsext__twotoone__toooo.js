
gdjs.evtsExt__twoTOone__toooo = gdjs.evtsExt__twoTOone__toooo || {};

/**
 * Object generated from toooo
 */
gdjs.evtsExt__twoTOone__toooo.toooo = class toooo extends gdjs.CustomRuntimeObject2D {
  constructor(parentInstanceContainer, objectData) {
    super(parentInstanceContainer, objectData);
    this._parentInstanceContainer = parentInstanceContainer;

    this._onceTriggers = new gdjs.OnceTriggers();
    this._objectData = {};
    
    

    // It calls the onCreated super implementation at the end.
    this.onCreated();
  }

  // Hot-reload:
  updateFromObjectData(oldObjectData, newObjectData) {
    super.updateFromObjectData(oldObjectData, newObjectData);

    this.onHotReloading(this._parentInstanceContainer);
    return true;
  }

  // Properties:
  

  

  
}

// Methods:
gdjs.evtsExt__twoTOone__toooo.toooo.prototype.doStepPostEventsContext = {};
gdjs.evtsExt__twoTOone__toooo.toooo.prototype.doStepPostEventsContext.GDObjectObjects1= [];
gdjs.evtsExt__twoTOone__toooo.toooo.prototype.doStepPostEventsContext.GDObjectObjects2= [];
gdjs.evtsExt__twoTOone__toooo.toooo.prototype.doStepPostEventsContext.GDNewSpriteObjects1= [];
gdjs.evtsExt__twoTOone__toooo.toooo.prototype.doStepPostEventsContext.GDNewSpriteObjects2= [];


gdjs.evtsExt__twoTOone__toooo.toooo.prototype.doStepPostEventsContext.userFunc0xf2d478 = function GDJSInlineCode(runtimeScene, eventsFunctionContext) {
"use strict";
runtimeScene.getVariablesForExtension("twoTOone").get("objectData").fromJSON(JSON.stringify(runtimeScene.getGame().getVariables().get('objectData')))
};
gdjs.evtsExt__twoTOone__toooo.toooo.prototype.doStepPostEventsContext.eventsList0 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
{
}

}


{


gdjs.evtsExt__twoTOone__toooo.toooo.prototype.doStepPostEventsContext.userFunc0xf2d478(runtimeScene, typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined);

}


};

gdjs.evtsExt__twoTOone__toooo.toooo.prototype.doStepPostEvents = function(parentEventsFunctionContext) {

var that = this;
var runtimeScene = this._instanceContainer;
var thisObjectList = [this];
var Object = Hashtable.newFrom({Object: thisObjectList});
var thisGDNewSpriteObjectsList = [...runtimeScene.getObjects("NewSprite")];
var GDNewSpriteObjects = Hashtable.newFrom({"NewSprite": thisGDNewSpriteObjectsList});
var eventsFunctionContext = {
  _objectsMap: {
"Object": Object
, "NewSprite": GDNewSpriteObjects
},
  _objectArraysMap: {
"Object": thisObjectList
, "NewSprite": thisGDNewSpriteObjectsList
},
  _behaviorNamesMap: {
},
  globalVariablesForExtension: runtimeScene.getGame().getVariablesForExtension("twoTOone"),
  sceneVariablesForExtension: runtimeScene.getScene().getVariablesForExtension("twoTOone"),
  localVariables: [],
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName] || behaviorName;
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        eventsFunctionContext._objectArraysMap[objectName].push(object);
      }
      return object;    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
    return "";
  },
  getOnceTriggers: function() { return that._onceTriggers; }
};

gdjs.evtsExt__twoTOone__toooo.toooo.prototype.doStepPostEventsContext.GDObjectObjects1.length = 0;
gdjs.evtsExt__twoTOone__toooo.toooo.prototype.doStepPostEventsContext.GDObjectObjects2.length = 0;
gdjs.evtsExt__twoTOone__toooo.toooo.prototype.doStepPostEventsContext.GDNewSpriteObjects1.length = 0;
gdjs.evtsExt__twoTOone__toooo.toooo.prototype.doStepPostEventsContext.GDNewSpriteObjects2.length = 0;

gdjs.evtsExt__twoTOone__toooo.toooo.prototype.doStepPostEventsContext.eventsList0(runtimeScene, eventsFunctionContext);
gdjs.evtsExt__twoTOone__toooo.toooo.prototype.doStepPostEventsContext.GDObjectObjects1.length = 0;
gdjs.evtsExt__twoTOone__toooo.toooo.prototype.doStepPostEventsContext.GDObjectObjects2.length = 0;
gdjs.evtsExt__twoTOone__toooo.toooo.prototype.doStepPostEventsContext.GDNewSpriteObjects1.length = 0;
gdjs.evtsExt__twoTOone__toooo.toooo.prototype.doStepPostEventsContext.GDNewSpriteObjects2.length = 0;


return;
}

gdjs.evtsExt__twoTOone__toooo.toooo.prototype.doStepPreEvents = function() {
  this._onceTriggers.startNewFrame();
};


gdjs.registerObject("twoTOone::toooo", gdjs.evtsExt__twoTOone__toooo.toooo);
