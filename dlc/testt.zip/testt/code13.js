gdjs.Untitled_32scene2Code = {};
gdjs.Untitled_32scene2Code.localVariables = [];
gdjs.Untitled_32scene2Code.GDmanObjects1= [];
gdjs.Untitled_32scene2Code.GDmanObjects2= [];
gdjs.Untitled_32scene2Code.GDmanObjects3= [];
gdjs.Untitled_32scene2Code.GDmanObjects4= [];
gdjs.Untitled_32scene2Code.GDmanObjects5= [];
gdjs.Untitled_32scene2Code.GDletterObjects1= [];
gdjs.Untitled_32scene2Code.GDletterObjects2= [];
gdjs.Untitled_32scene2Code.GDletterObjects3= [];
gdjs.Untitled_32scene2Code.GDletterObjects4= [];
gdjs.Untitled_32scene2Code.GDletterObjects5= [];
gdjs.Untitled_32scene2Code.GDdrawObjects1= [];
gdjs.Untitled_32scene2Code.GDdrawObjects2= [];
gdjs.Untitled_32scene2Code.GDdrawObjects3= [];
gdjs.Untitled_32scene2Code.GDdrawObjects4= [];
gdjs.Untitled_32scene2Code.GDdrawObjects5= [];


gdjs.Untitled_32scene2Code.mapOfGDgdjs_9546Untitled_959532scene2Code_9546GDletterObjects3Objects = Hashtable.newFrom({"letter": gdjs.Untitled_32scene2Code.GDletterObjects3});
gdjs.Untitled_32scene2Code.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strAt(runtimeScene.getScene().getVariables().getFromIndex(1).getAsString(), gdjs.Untitled_32scene2Code.localVariables[0].getFromIndex(0).getAsNumber() - 1) == "\n");
}
if (isConditionTrue_0) {
{gdjs.Untitled_32scene2Code.localVariables[0].getFromIndex(2).add(20);
}{gdjs.Untitled_32scene2Code.localVariables[0].getFromIndex(3).setNumber(0);
}}

}


};gdjs.Untitled_32scene2Code.eventsList1 = function(runtimeScene) {

{


const repeatCount3 = gdjs.evtTools.string.strLen(runtimeScene.getScene().getVariables().getFromIndex(1).getAsString());
for (let repeatIndex3 = 0;repeatIndex3 < repeatCount3;++repeatIndex3) {
gdjs.copyArray(gdjs.Untitled_32scene2Code.GDletterObjects1, gdjs.Untitled_32scene2Code.GDletterObjects3);


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32scene2Code.mapOfGDgdjs_9546Untitled_959532scene2Code_9546GDletterObjects3Objects, gdjs.Untitled_32scene2Code.localVariables[0].getFromIndex(3).getAsNumber(), gdjs.Untitled_32scene2Code.localVariables[0].getFromIndex(2).getAsNumber(), "");
}{for(var i = 0, len = gdjs.Untitled_32scene2Code.GDletterObjects3.length ;i < len;++i) {
    gdjs.Untitled_32scene2Code.GDletterObjects3[i].getBehavior("Text").setText(gdjs.evtTools.string.strAt(runtimeScene.getScene().getVariables().getFromIndex(1).getAsString(), gdjs.Untitled_32scene2Code.localVariables[0].getFromIndex(0).getAsNumber()));
}
}{for(var i = 0, len = gdjs.Untitled_32scene2Code.GDletterObjects3.length ;i < len;++i) {
    gdjs.Untitled_32scene2Code.GDletterObjects3[i].returnVariable(gdjs.Untitled_32scene2Code.GDletterObjects3[i].getVariables().getFromIndex(0)).setNumber(gdjs.Untitled_32scene2Code.localVariables[0].getFromIndex(0).getAsNumber());
}
}{for(var i = 0, len = gdjs.Untitled_32scene2Code.GDletterObjects3.length ;i < len;++i) {
    gdjs.Untitled_32scene2Code.GDletterObjects3[i].setCharacterSize(20);
}
}{gdjs.Untitled_32scene2Code.localVariables[0].getFromIndex(3).add(12);
}{gdjs.Untitled_32scene2Code.localVariables[0].getFromIndex(0).add(1);
}
{ //Subevents: 
gdjs.Untitled_32scene2Code.eventsList0(runtimeScene);} //Subevents end.
}
}

}


{


let isConditionTrue_0 = false;
{
{runtimeScene.getScene().getVariables().getFromIndex(2).setString(runtimeScene.getScene().getVariables().getFromIndex(1).getAsString());
}}

}


};gdjs.Untitled_32scene2Code.mapOfGDgdjs_9546Untitled_959532scene2Code_9546GDletterObjects1Objects = Hashtable.newFrom({"letter": gdjs.Untitled_32scene2Code.GDletterObjects1});
gdjs.Untitled_32scene2Code.eventsList2 = function(runtimeScene) {

{



}


{



}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("count", variable);
}
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("X", variable);
}
{
const variable = new gdjs.Variable();
variable.setNumber(32);
variables._declare("enter", variable);
}
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("climb", variable);
}
gdjs.Untitled_32scene2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(2)) != runtimeScene.getScene().getVariables().getFromIndex(1).getAsString();
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(24500020);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("letter"), gdjs.Untitled_32scene2Code.GDletterObjects1);
{for(var i = 0, len = gdjs.Untitled_32scene2Code.GDletterObjects1.length ;i < len;++i) {
    gdjs.Untitled_32scene2Code.GDletterObjects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.Untitled_32scene2Code.eventsList1(runtimeScene);} //End of subevents
}
gdjs.Untitled_32scene2Code.localVariables.pop();

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("posX", variable);
}
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("posY", variable);
}
gdjs.Untitled_32scene2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Delete");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(24504988);
}
}
if (isConditionTrue_0) {
{gdjs.Untitled_32scene2Code.localVariables[0].getFromIndex(0).setNumber(runtimeScene.getScene().getVariables().getFromIndex(4).getAsNumber());
}{runtimeScene.getScene().getVariables().getFromIndex(1).setString(gdjs.evtTools.string.subStr(runtimeScene.getScene().getVariables().getFromIndex(1).getAsString(), 0, gdjs.Untitled_32scene2Code.localVariables[0].getFromIndex(0).getAsNumber() - 1) + gdjs.evtTools.string.subStr(runtimeScene.getScene().getVariables().getFromIndex(1).getAsString(), gdjs.Untitled_32scene2Code.localVariables[0].getFromIndex(0).getAsNumber(), gdjs.evtTools.string.strLen(runtimeScene.getScene().getVariables().getFromIndex(1).getAsString())));
}{runtimeScene.getScene().getVariables().getFromIndex(3).sub(20);
}}
gdjs.Untitled_32scene2Code.localVariables.pop();

}


{

gdjs.copyArray(runtimeScene.getObjects("letter"), gdjs.Untitled_32scene2Code.GDletterObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Untitled_32scene2Code.mapOfGDgdjs_9546Untitled_959532scene2Code_9546GDletterObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(24507412);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32scene2Code.GDletterObjects1 */
{runtimeScene.getScene().getVariables().getFromIndex(4).setNumber(((gdjs.Untitled_32scene2Code.GDletterObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32scene2Code.GDletterObjects1[0].getVariables()).getFromIndex(0).getAsNumber());
}{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber((( gdjs.Untitled_32scene2Code.GDletterObjects1.length === 0 ) ? 0 :gdjs.Untitled_32scene2Code.GDletterObjects1[0].getX()));
}{runtimeScene.getScene().getVariables().getFromIndex(5).setNumber((( gdjs.Untitled_32scene2Code.GDletterObjects1.length === 0 ) ? 0 :gdjs.Untitled_32scene2Code.GDletterObjects1[0].getY()));
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("draw"), gdjs.Untitled_32scene2Code.GDdrawObjects1);
{for(var i = 0, len = gdjs.Untitled_32scene2Code.GDdrawObjects1.length ;i < len;++i) {
    gdjs.Untitled_32scene2Code.GDdrawObjects1[i].drawLineV2(runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(5).getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(5).getAsNumber() + 20, 2);
}
}}

}


};

gdjs.Untitled_32scene2Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Untitled_32scene2Code.GDmanObjects1.length = 0;
gdjs.Untitled_32scene2Code.GDmanObjects2.length = 0;
gdjs.Untitled_32scene2Code.GDmanObjects3.length = 0;
gdjs.Untitled_32scene2Code.GDmanObjects4.length = 0;
gdjs.Untitled_32scene2Code.GDmanObjects5.length = 0;
gdjs.Untitled_32scene2Code.GDletterObjects1.length = 0;
gdjs.Untitled_32scene2Code.GDletterObjects2.length = 0;
gdjs.Untitled_32scene2Code.GDletterObjects3.length = 0;
gdjs.Untitled_32scene2Code.GDletterObjects4.length = 0;
gdjs.Untitled_32scene2Code.GDletterObjects5.length = 0;
gdjs.Untitled_32scene2Code.GDdrawObjects1.length = 0;
gdjs.Untitled_32scene2Code.GDdrawObjects2.length = 0;
gdjs.Untitled_32scene2Code.GDdrawObjects3.length = 0;
gdjs.Untitled_32scene2Code.GDdrawObjects4.length = 0;
gdjs.Untitled_32scene2Code.GDdrawObjects5.length = 0;

gdjs.Untitled_32scene2Code.eventsList2(runtimeScene);
gdjs.Untitled_32scene2Code.GDmanObjects1.length = 0;
gdjs.Untitled_32scene2Code.GDmanObjects2.length = 0;
gdjs.Untitled_32scene2Code.GDmanObjects3.length = 0;
gdjs.Untitled_32scene2Code.GDmanObjects4.length = 0;
gdjs.Untitled_32scene2Code.GDmanObjects5.length = 0;
gdjs.Untitled_32scene2Code.GDletterObjects1.length = 0;
gdjs.Untitled_32scene2Code.GDletterObjects2.length = 0;
gdjs.Untitled_32scene2Code.GDletterObjects3.length = 0;
gdjs.Untitled_32scene2Code.GDletterObjects4.length = 0;
gdjs.Untitled_32scene2Code.GDletterObjects5.length = 0;
gdjs.Untitled_32scene2Code.GDdrawObjects1.length = 0;
gdjs.Untitled_32scene2Code.GDdrawObjects2.length = 0;
gdjs.Untitled_32scene2Code.GDdrawObjects3.length = 0;
gdjs.Untitled_32scene2Code.GDdrawObjects4.length = 0;
gdjs.Untitled_32scene2Code.GDdrawObjects5.length = 0;


return;

}

gdjs['Untitled_32scene2Code'] = gdjs.Untitled_32scene2Code;
