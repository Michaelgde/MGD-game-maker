gdjs.ideCode = {};
gdjs.ideCode.localVariables = [];
gdjs.ideCode.GDcodeObjects1= [];
gdjs.ideCode.GDcodeObjects2= [];
gdjs.ideCode.GDNewBitmapTextObjects1= [];
gdjs.ideCode.GDNewBitmapTextObjects2= [];
gdjs.ideCode.GDobjObjects1= [];
gdjs.ideCode.GDobjObjects2= [];
gdjs.ideCode.GDapplyObjects1= [];
gdjs.ideCode.GDapplyObjects2= [];


gdjs.ideCode.mapOfGDgdjs_9546ideCode_9546GDapplyObjects1Objects = Hashtable.newFrom({"apply": gdjs.ideCode.GDapplyObjects1});
gdjs.ideCode.eventsList0 = function(runtimeScene) {

{

/* Reuse gdjs.ideCode.GDcodeObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen((( gdjs.ideCode.GDcodeObjects1.length === 0 ) ? "" :gdjs.ideCode.GDcodeObjects1[0].getBehavior("Text").getText())) == gdjs.evtTools.string.strLen(runtimeScene.getGame().getVariables().getFromIndex(0).getAsString()));
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}}

}


};gdjs.ideCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("apply"), gdjs.ideCode.GDapplyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.ideCode.mapOfGDgdjs_9546ideCode_9546GDapplyObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("code"), gdjs.ideCode.GDcodeObjects1);
{runtimeScene.getGame().getVariables().getFromIndex(5).setString((( gdjs.ideCode.GDcodeObjects1.length === 0 ) ? "" :gdjs.ideCode.GDcodeObjects1[0].getBehavior("Text").getText()));
}{runtimeScene.getGame().getVariables().getFromIndex(0).setString((( gdjs.ideCode.GDcodeObjects1.length === 0 ) ? "" :gdjs.ideCode.GDcodeObjects1[0].getBehavior("Text").getText()));
}
{ //Subevents
gdjs.ideCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("code"), gdjs.ideCode.GDcodeObjects1);
{for(var i = 0, len = gdjs.ideCode.GDcodeObjects1.length ;i < len;++i) {
    gdjs.ideCode.GDcodeObjects1[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(0).getAsString());
}
}}

}


};

gdjs.ideCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.ideCode.GDcodeObjects1.length = 0;
gdjs.ideCode.GDcodeObjects2.length = 0;
gdjs.ideCode.GDNewBitmapTextObjects1.length = 0;
gdjs.ideCode.GDNewBitmapTextObjects2.length = 0;
gdjs.ideCode.GDobjObjects1.length = 0;
gdjs.ideCode.GDobjObjects2.length = 0;
gdjs.ideCode.GDapplyObjects1.length = 0;
gdjs.ideCode.GDapplyObjects2.length = 0;

gdjs.ideCode.eventsList1(runtimeScene);
gdjs.ideCode.GDcodeObjects1.length = 0;
gdjs.ideCode.GDcodeObjects2.length = 0;
gdjs.ideCode.GDNewBitmapTextObjects1.length = 0;
gdjs.ideCode.GDNewBitmapTextObjects2.length = 0;
gdjs.ideCode.GDobjObjects1.length = 0;
gdjs.ideCode.GDobjObjects2.length = 0;
gdjs.ideCode.GDapplyObjects1.length = 0;
gdjs.ideCode.GDapplyObjects2.length = 0;


return;

}

gdjs['ideCode'] = gdjs.ideCode;
