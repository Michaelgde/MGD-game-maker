gdjs.engineCode = {};
gdjs.engineCode.localVariables = [];
gdjs.engineCode.forEachIndex2 = 0;

gdjs.engineCode.forEachIndex3 = 0;

gdjs.engineCode.forEachObjects2 = [];

gdjs.engineCode.forEachObjects3 = [];

gdjs.engineCode.forEachTemporary2 = null;

gdjs.engineCode.forEachTemporary3 = null;

gdjs.engineCode.forEachTotalCount2 = 0;

gdjs.engineCode.forEachTotalCount3 = 0;

gdjs.engineCode.GDcondition_9595blockObjects1= [];
gdjs.engineCode.GDcondition_9595blockObjects2= [];
gdjs.engineCode.GDcondition_9595blockObjects3= [];
gdjs.engineCode.GDcondition_9595blockObjects4= [];
gdjs.engineCode.GDcondition_9595blockObjects5= [];
gdjs.engineCode.GDaction_9595blockObjects1= [];
gdjs.engineCode.GDaction_9595blockObjects2= [];
gdjs.engineCode.GDaction_9595blockObjects3= [];
gdjs.engineCode.GDaction_9595blockObjects4= [];
gdjs.engineCode.GDaction_9595blockObjects5= [];
gdjs.engineCode.GDwriterObjects1= [];
gdjs.engineCode.GDwriterObjects2= [];
gdjs.engineCode.GDwriterObjects3= [];
gdjs.engineCode.GDwriterObjects4= [];
gdjs.engineCode.GDwriterObjects5= [];
gdjs.engineCode.GDdialougObjects1= [];
gdjs.engineCode.GDdialougObjects2= [];
gdjs.engineCode.GDdialougObjects3= [];
gdjs.engineCode.GDdialougObjects4= [];
gdjs.engineCode.GDdialougObjects5= [];
gdjs.engineCode.GDvirtualObjects1= [];
gdjs.engineCode.GDvirtualObjects2= [];
gdjs.engineCode.GDvirtualObjects3= [];
gdjs.engineCode.GDvirtualObjects4= [];
gdjs.engineCode.GDvirtualObjects5= [];
gdjs.engineCode.GDsaObjects1= [];
gdjs.engineCode.GDsaObjects2= [];
gdjs.engineCode.GDsaObjects3= [];
gdjs.engineCode.GDsaObjects4= [];
gdjs.engineCode.GDsaObjects5= [];
gdjs.engineCode.GDscObjects1= [];
gdjs.engineCode.GDscObjects2= [];
gdjs.engineCode.GDscObjects3= [];
gdjs.engineCode.GDscObjects4= [];
gdjs.engineCode.GDscObjects5= [];
gdjs.engineCode.GDwriter2Objects1= [];
gdjs.engineCode.GDwriter2Objects2= [];
gdjs.engineCode.GDwriter2Objects3= [];
gdjs.engineCode.GDwriter2Objects4= [];
gdjs.engineCode.GDwriter2Objects5= [];
gdjs.engineCode.GDcode_9595viewObjects1= [];
gdjs.engineCode.GDcode_9595viewObjects2= [];
gdjs.engineCode.GDcode_9595viewObjects3= [];
gdjs.engineCode.GDcode_9595viewObjects4= [];
gdjs.engineCode.GDcode_9595viewObjects5= [];
gdjs.engineCode.GDdrawerObjects1= [];
gdjs.engineCode.GDdrawerObjects2= [];
gdjs.engineCode.GDdrawerObjects3= [];
gdjs.engineCode.GDdrawerObjects4= [];
gdjs.engineCode.GDdrawerObjects5= [];
gdjs.engineCode.GDaddObjects1= [];
gdjs.engineCode.GDaddObjects2= [];
gdjs.engineCode.GDaddObjects3= [];
gdjs.engineCode.GDaddObjects4= [];
gdjs.engineCode.GDaddObjects5= [];
gdjs.engineCode.GDapplyObjects1= [];
gdjs.engineCode.GDapplyObjects2= [];
gdjs.engineCode.GDapplyObjects3= [];
gdjs.engineCode.GDapplyObjects4= [];
gdjs.engineCode.GDapplyObjects5= [];
gdjs.engineCode.GDparamInputObjects1= [];
gdjs.engineCode.GDparamInputObjects2= [];
gdjs.engineCode.GDparamInputObjects3= [];
gdjs.engineCode.GDparamInputObjects4= [];
gdjs.engineCode.GDparamInputObjects5= [];
gdjs.engineCode.GDcolObjects1= [];
gdjs.engineCode.GDcolObjects2= [];
gdjs.engineCode.GDcolObjects3= [];
gdjs.engineCode.GDcolObjects4= [];
gdjs.engineCode.GDcolObjects5= [];
gdjs.engineCode.GDcObjects1= [];
gdjs.engineCode.GDcObjects2= [];
gdjs.engineCode.GDcObjects3= [];
gdjs.engineCode.GDcObjects4= [];
gdjs.engineCode.GDcObjects5= [];
gdjs.engineCode.GDaObjects1= [];
gdjs.engineCode.GDaObjects2= [];
gdjs.engineCode.GDaObjects3= [];
gdjs.engineCode.GDaObjects4= [];
gdjs.engineCode.GDaObjects5= [];
gdjs.engineCode.GDcol2Objects1= [];
gdjs.engineCode.GDcol2Objects2= [];
gdjs.engineCode.GDcol2Objects3= [];
gdjs.engineCode.GDcol2Objects4= [];
gdjs.engineCode.GDcol2Objects5= [];
gdjs.engineCode.GDselectorObjects1= [];
gdjs.engineCode.GDselectorObjects2= [];
gdjs.engineCode.GDselectorObjects3= [];
gdjs.engineCode.GDselectorObjects4= [];
gdjs.engineCode.GDselectorObjects5= [];
gdjs.engineCode.GDmoverObjects1= [];
gdjs.engineCode.GDmoverObjects2= [];
gdjs.engineCode.GDmoverObjects3= [];
gdjs.engineCode.GDmoverObjects4= [];
gdjs.engineCode.GDmoverObjects5= [];


gdjs.engineCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.isMobile());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22315172);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("virtual"), gdjs.engineCode.GDvirtualObjects2);
{for(var i = 0, len = gdjs.engineCode.GDvirtualObjects2.length ;i < len;++i) {
    gdjs.engineCode.GDvirtualObjects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(1).setBoolean(false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.isMobile();
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22316044);
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(1).setBoolean(true);
}}

}


};gdjs.engineCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(1), true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("virtual"), gdjs.engineCode.GDvirtualObjects1);
{for(var i = 0, len = gdjs.engineCode.GDvirtualObjects1.length ;i < len;++i) {
    gdjs.engineCode.GDvirtualObjects1[i].setPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0),gdjs.evtTools.input.getCursorY(runtimeScene, "", 0));
}
}}

}


};gdjs.engineCode.eventsList2 = function(runtimeScene) {

{



}


};gdjs.engineCode.userFunc0x1437a38 = function GDJSInlineCode(runtimeScene) {
"use strict";
eval(runtimeScene.getVariables().get("code").getAsString())

};
gdjs.engineCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{


gdjs.engineCode.userFunc0x1437a38(runtimeScene);

}


};gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDcondition_95959595blockObjects3Objects = Hashtable.newFrom({"condition_block": gdjs.engineCode.GDcondition_9595blockObjects3});
gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDaction_95959595blockObjects4Objects = Hashtable.newFrom({"action_block": gdjs.engineCode.GDaction_9595blockObjects4});
gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDaction_95959595blockObjects4Objects = Hashtable.newFrom({"action_block": gdjs.engineCode.GDaction_9595blockObjects4});
gdjs.engineCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) >= (gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDaction_95959595blockObjects4Objects) * 32) - 32;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(4).setBoolean(false);
}}

}


};gdjs.engineCode.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("action_block"), gdjs.engineCode.GDaction_9595blockObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.raycastObject(gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDaction_95959595blockObjects4Objects, 0, runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() + 8, 0, 4000, gdjs.VariablesContainer.badVariable, runtimeScene.getScene().getVariables().getFromIndex(6), false);
if (isConditionTrue_0) {
/* Reuse gdjs.engineCode.GDaction_9595blockObjects4 */
{runtimeScene.getScene().getVariables().getFromIndex(2).concatenateString(((gdjs.engineCode.GDaction_9595blockObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.engineCode.GDaction_9595blockObjects4[0].getVariables()).getFromIndex(3).getAsString());
}{runtimeScene.getScene().getVariables().getFromIndex(3).add(32);
}
{ //Subevents
gdjs.engineCode.eventsList4(runtimeScene);} //End of subevents
}

}


};gdjs.engineCode.mapOfEmptyGDcondition_9595blockObjects = Hashtable.newFrom({"condition_block": []});
gdjs.engineCode.eventsList6 = function(runtimeScene) {

};gdjs.engineCode.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("condition_block"), gdjs.engineCode.GDcondition_9595blockObjects2);

for (gdjs.engineCode.forEachIndex3 = 0;gdjs.engineCode.forEachIndex3 < gdjs.engineCode.GDcondition_9595blockObjects2.length;++gdjs.engineCode.forEachIndex3) {
gdjs.engineCode.GDcondition_9595blockObjects3.length = 0;


gdjs.engineCode.forEachTemporary3 = gdjs.engineCode.GDcondition_9595blockObjects2[gdjs.engineCode.forEachIndex3];
gdjs.engineCode.GDcondition_9595blockObjects3.push(gdjs.engineCode.forEachTemporary3);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.raycastObject(gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDcondition_95959595blockObjects3Objects, 0, runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() + 8, 0, 4000, gdjs.VariablesContainer.badVariable, runtimeScene.getScene().getVariables().getFromIndex(6), false);
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(2).concatenateString(gdjs.evtTools.string.newLine() + ((gdjs.engineCode.GDcondition_9595blockObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.engineCode.GDcondition_9595blockObjects3[0].getVariables()).getFromIndex(1).getAsString());
}
{ //Subevents: 
gdjs.engineCode.eventsList5(runtimeScene);} //Subevents end.
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{


const repeatCount2 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.engineCode.mapOfEmptyGDcondition_9595blockObjects);
for (let repeatIndex2 = 0;repeatIndex2 < repeatCount2;++repeatIndex2) {

let isConditionTrue_0 = false;
if (true)
{
}
}

}


};gdjs.engineCode.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "c");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(2).setString("");
}{runtimeScene.getScene().getVariables().getFromIndex(4).setBoolean(true);
}{runtimeScene.getScene().getVariables().getFromIndex(5).setBoolean(false);
}{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(32);
}
{ //Subevents
gdjs.engineCode.eventsList2(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen(runtimeScene.getScene().getVariables().getFromIndex(2).getAsString()) > 3);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(4), false, false);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.engineCode.eventsList3(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("drawer"), gdjs.engineCode.GDdrawerObjects2);
{for(var i = 0, len = gdjs.engineCode.GDdrawerObjects2.length ;i < len;++i) {
    gdjs.engineCode.GDdrawerObjects2[i].drawLineV2(0, runtimeScene.getScene().getVariables().getFromIndex(6).getAsNumber(), 10, runtimeScene.getScene().getVariables().getFromIndex(6).getAsNumber(), 5);
}
}}

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("count", variable);
}
gdjs.engineCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(4), true, false);
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(32);
}
{ //Subevents
gdjs.engineCode.eventsList7(runtimeScene);} //End of subevents
}
gdjs.engineCode.localVariables.pop();

}


};gdjs.engineCode.mapOfEmptyGDcondition_9595blockObjects = Hashtable.newFrom({"condition_block": []});
gdjs.engineCode.mapOfEmptyGDwriterObjects = Hashtable.newFrom({"writer": []});
gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDwriterObjects2Objects = Hashtable.newFrom({"writer": gdjs.engineCode.GDwriterObjects2});
gdjs.engineCode.eventsList9 = function(runtimeScene) {

};gdjs.engineCode.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.engineCode.GDcondition_9595blockObjects2, gdjs.engineCode.GDcondition_9595blockObjects3);


const repeatCount4 = (gdjs.RuntimeObject.getVariableChildCount(((gdjs.engineCode.GDcondition_9595blockObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.engineCode.GDcondition_9595blockObjects3[0].getVariables()).getFromIndex(0)));
for (let repeatIndex4 = 0;repeatIndex4 < repeatCount4;++repeatIndex4) {
gdjs.copyArray(gdjs.engineCode.GDcondition_9595blockObjects3, gdjs.engineCode.GDcondition_9595blockObjects4);

gdjs.copyArray(gdjs.engineCode.GDwriterObjects2, gdjs.engineCode.GDwriterObjects4);


let isConditionTrue_0 = false;
if (true)
{
{for(var i = 0, len = gdjs.engineCode.GDwriterObjects4.length ;i < len;++i) {
    gdjs.engineCode.GDwriterObjects4[i].getBehavior("Text").setText(gdjs.engineCode.GDwriterObjects4[i].getBehavior("Text").getText() + (((gdjs.engineCode.GDcondition_9595blockObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.engineCode.GDcondition_9595blockObjects4[0].getVariables()).getFromIndex(0).getChild(gdjs.engineCode.localVariables[0].getFromIndex(0).getAsNumber() - 1).getAsString() + ((gdjs.engineCode.GDcondition_9595blockObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.engineCode.GDcondition_9595blockObjects4[0].getVariables()).getFromIndex(3).getChild(gdjs.engineCode.localVariables[0].getFromIndex(0).getAsNumber()).getAsString()));
}
}{for(var i = 0, len = gdjs.engineCode.GDcondition_9595blockObjects4.length ;i < len;++i) {
    gdjs.engineCode.GDcondition_9595blockObjects4[i].returnVariable(gdjs.engineCode.GDcondition_9595blockObjects4[i].getVariables().getFromIndex(1)).concatenate(gdjs.engineCode.GDcondition_9595blockObjects4[i].getVariables().getFromIndex(0).getChild(gdjs.engineCode.localVariables[0].getFromIndex(0).getAsNumber() - 1).getAsString() + gdjs.engineCode.GDcondition_9595blockObjects4[i].getVariables().getFromIndex(2).getChild(gdjs.engineCode.localVariables[0].getFromIndex(0).getAsNumber()).getAsString());
}
}{gdjs.engineCode.localVariables[0].getFromIndex(0).add(1);
}}
}

}


};gdjs.engineCode.eventsList11 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("condition_block"), gdjs.engineCode.GDcondition_9595blockObjects1);

for (gdjs.engineCode.forEachIndex2 = 0;gdjs.engineCode.forEachIndex2 < gdjs.engineCode.GDcondition_9595blockObjects1.length;++gdjs.engineCode.forEachIndex2) {
gdjs.copyArray(gdjs.engineCode.GDwriterObjects1, gdjs.engineCode.GDwriterObjects2);

gdjs.engineCode.GDcondition_9595blockObjects2.length = 0;


gdjs.engineCode.forEachTemporary2 = gdjs.engineCode.GDcondition_9595blockObjects1[gdjs.engineCode.forEachIndex2];
gdjs.engineCode.GDcondition_9595blockObjects2.push(gdjs.engineCode.forEachTemporary2);
let isConditionTrue_0 = false;
if (true) {
{gdjs.engineCode.localVariables[0].getFromIndex(0).setNumber(1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDwriterObjects2Objects, (( gdjs.engineCode.GDcondition_9595blockObjects2.length === 0 ) ? 0 :gdjs.engineCode.GDcondition_9595blockObjects2[0].getPointX("")), (( gdjs.engineCode.GDcondition_9595blockObjects2.length === 0 ) ? 0 :gdjs.engineCode.GDcondition_9595blockObjects2[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.engineCode.GDwriterObjects2.length ;i < len;++i) {
    gdjs.engineCode.GDwriterObjects2[i].getBehavior("Text").setText(((gdjs.engineCode.GDcondition_9595blockObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.engineCode.GDcondition_9595blockObjects2[0].getVariables()).getFromIndex(3).getChild(0).getAsString());
}
}{for(var i = 0, len = gdjs.engineCode.GDcondition_9595blockObjects2.length ;i < len;++i) {
    gdjs.engineCode.GDcondition_9595blockObjects2[i].returnVariable(gdjs.engineCode.GDcondition_9595blockObjects2[i].getVariables().getFromIndex(1)).setString(gdjs.engineCode.GDcondition_9595blockObjects2[i].getVariables().getFromIndex(2).getChild(0).getAsString());
}
}
{ //Subevents: 
gdjs.engineCode.eventsList10(runtimeScene);} //Subevents end.
}
}

}


};gdjs.engineCode.mapOfEmptyGDaction_9595blockObjects = Hashtable.newFrom({"action_block": []});
gdjs.engineCode.mapOfEmptyGDwriter2Objects = Hashtable.newFrom({"writer2": []});
gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDwriter2Objects2Objects = Hashtable.newFrom({"writer2": gdjs.engineCode.GDwriter2Objects2});
gdjs.engineCode.eventsList12 = function(runtimeScene) {

};gdjs.engineCode.eventsList13 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.engineCode.GDaction_9595blockObjects2, gdjs.engineCode.GDaction_9595blockObjects3);


const repeatCount4 = (gdjs.RuntimeObject.getVariableChildCount(((gdjs.engineCode.GDaction_9595blockObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.engineCode.GDaction_9595blockObjects3[0].getVariables()).getFromIndex(0)));
for (let repeatIndex4 = 0;repeatIndex4 < repeatCount4;++repeatIndex4) {
gdjs.copyArray(gdjs.engineCode.GDaction_9595blockObjects3, gdjs.engineCode.GDaction_9595blockObjects4);

gdjs.copyArray(gdjs.engineCode.GDwriter2Objects2, gdjs.engineCode.GDwriter2Objects4);


let isConditionTrue_0 = false;
if (true)
{
{gdjs.engineCode.localVariables[0].getFromIndex(1).getChild(gdjs.engineCode.localVariables[0].getFromIndex(0).getAsNumber()).add(((gdjs.engineCode.GDaction_9595blockObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.engineCode.GDaction_9595blockObjects4[0].getVariables()).getFromIndex(0).getChild(gdjs.engineCode.localVariables[0].getFromIndex(0).getAsNumber() - 1).getAsNumber() + ((gdjs.engineCode.GDaction_9595blockObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.engineCode.GDaction_9595blockObjects4[0].getVariables()).getFromIndex(1).getChild(gdjs.engineCode.localVariables[0].getFromIndex(0).getAsNumber()).getAsNumber());
}{for(var i = 0, len = gdjs.engineCode.GDwriter2Objects4.length ;i < len;++i) {
    gdjs.engineCode.GDwriter2Objects4[i].getBehavior("Text").setText(gdjs.engineCode.GDwriter2Objects4[i].getBehavior("Text").getText() + (((gdjs.engineCode.GDaction_9595blockObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.engineCode.GDaction_9595blockObjects4[0].getVariables()).getFromIndex(0).getChild(gdjs.engineCode.localVariables[0].getFromIndex(0).getAsNumber() - 1).getAsString() + ((gdjs.engineCode.GDaction_9595blockObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.engineCode.GDaction_9595blockObjects4[0].getVariables()).getFromIndex(2).getChild(gdjs.engineCode.localVariables[0].getFromIndex(0).getAsNumber()).getAsString()));
}
}{for(var i = 0, len = gdjs.engineCode.GDaction_9595blockObjects4.length ;i < len;++i) {
    gdjs.engineCode.GDaction_9595blockObjects4[i].returnVariable(gdjs.engineCode.GDaction_9595blockObjects4[i].getVariables().getFromIndex(3)).concatenate(gdjs.engineCode.GDaction_9595blockObjects4[i].getVariables().getFromIndex(0).getChild(gdjs.engineCode.localVariables[0].getFromIndex(0).getAsNumber() - 1).getAsString() + gdjs.engineCode.GDaction_9595blockObjects4[i].getVariables().getFromIndex(1).getChild(gdjs.engineCode.localVariables[0].getFromIndex(0).getAsNumber()).getAsString());
}
}{gdjs.engineCode.localVariables[0].getFromIndex(0).add(1);
}}
}

}


{

gdjs.copyArray(gdjs.engineCode.GDwriter2Objects2, gdjs.engineCode.GDwriter2Objects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.engineCode.GDwriter2Objects3.length;i<l;++i) {
    if ( gdjs.engineCode.GDwriter2Objects3[i].getVariableNumber(gdjs.engineCode.GDwriter2Objects3[i].getVariables().getFromIndex(0)) == gdjs.engineCode.localVariables[0].getFromIndex(0).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.engineCode.GDwriter2Objects3[k] = gdjs.engineCode.GDwriter2Objects3[i];
        ++k;
    }
}
gdjs.engineCode.GDwriter2Objects3.length = k;
if (isConditionTrue_0) {
}

}


};gdjs.engineCode.eventsList14 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("action_block"), gdjs.engineCode.GDaction_9595blockObjects1);

for (gdjs.engineCode.forEachIndex2 = 0;gdjs.engineCode.forEachIndex2 < gdjs.engineCode.GDaction_9595blockObjects1.length;++gdjs.engineCode.forEachIndex2) {
gdjs.copyArray(gdjs.engineCode.GDwriter2Objects1, gdjs.engineCode.GDwriter2Objects2);

gdjs.engineCode.GDaction_9595blockObjects2.length = 0;


gdjs.engineCode.forEachTemporary2 = gdjs.engineCode.GDaction_9595blockObjects1[gdjs.engineCode.forEachIndex2];
gdjs.engineCode.GDaction_9595blockObjects2.push(gdjs.engineCode.forEachTemporary2);
let isConditionTrue_0 = false;
if (true) {
{gdjs.engineCode.localVariables[0].getFromIndex(0).setNumber(1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDwriter2Objects2Objects, (( gdjs.engineCode.GDaction_9595blockObjects2.length === 0 ) ? 0 :gdjs.engineCode.GDaction_9595blockObjects2[0].getPointX("")), (( gdjs.engineCode.GDaction_9595blockObjects2.length === 0 ) ? 0 :gdjs.engineCode.GDaction_9595blockObjects2[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.engineCode.GDwriter2Objects2.length ;i < len;++i) {
    gdjs.engineCode.GDwriter2Objects2[i].returnVariable(gdjs.engineCode.GDwriter2Objects2[i].getVariables().getFromIndex(0)).setNumber(gdjs.engineCode.localVariables[0].getFromIndex(0).getAsNumber());
}
}{gdjs.engineCode.localVariables[0].getFromIndex(1).getChild(gdjs.engineCode.localVariables[0].getFromIndex(0).getAsNumber()).setNumber(((gdjs.engineCode.GDaction_9595blockObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.engineCode.GDaction_9595blockObjects2[0].getVariables()).getFromIndex(1).getChild(0).getAsNumber());
}{for(var i = 0, len = gdjs.engineCode.GDwriter2Objects2.length ;i < len;++i) {
    gdjs.engineCode.GDwriter2Objects2[i].getBehavior("Text").setText(((gdjs.engineCode.GDaction_9595blockObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.engineCode.GDaction_9595blockObjects2[0].getVariables()).getFromIndex(2).getChild(0).getAsString());
}
}{for(var i = 0, len = gdjs.engineCode.GDaction_9595blockObjects2.length ;i < len;++i) {
    gdjs.engineCode.GDaction_9595blockObjects2[i].returnVariable(gdjs.engineCode.GDaction_9595blockObjects2[i].getVariables().getFromIndex(3)).setString(gdjs.engineCode.GDaction_9595blockObjects2[i].getVariables().getFromIndex(1).getChild(0).getAsString());
}
}
{ //Subevents: 
gdjs.engineCode.eventsList13(runtimeScene);} //Subevents end.
}
}

}


};gdjs.engineCode.mapOfEmptyGDaction_9595blockObjects = Hashtable.newFrom({"action_block": []});
gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDcondition_95959595blockObjects1Objects = Hashtable.newFrom({"condition_block": gdjs.engineCode.GDcondition_9595blockObjects1});
gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDwriterObjects1Objects = Hashtable.newFrom({"writer": gdjs.engineCode.GDwriterObjects1});
gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDaction_95959595blockObjects1Objects = Hashtable.newFrom({"action_block": gdjs.engineCode.GDaction_9595blockObjects1});
gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDwriter2Objects1Objects = Hashtable.newFrom({"writer2": gdjs.engineCode.GDwriter2Objects1});
gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDcondition_95959595blockObjects1Objects = Hashtable.newFrom({"condition_block": gdjs.engineCode.GDcondition_9595blockObjects1});
gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDaction_95959595blockObjects1Objects = Hashtable.newFrom({"action_block": gdjs.engineCode.GDaction_9595blockObjects1});
gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDaObjects1Objects = Hashtable.newFrom({"a": gdjs.engineCode.GDaObjects1});
gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDcolObjects1Objects = Hashtable.newFrom({"col": gdjs.engineCode.GDcolObjects1});
gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDaction_95959595blockObjects1Objects = Hashtable.newFrom({"action_block": gdjs.engineCode.GDaction_9595blockObjects1});
gdjs.engineCode.eventsList15 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("writer2"), gdjs.engineCode.GDwriter2Objects1);
{for(var i = 0, len = gdjs.engineCode.GDwriter2Objects1.length ;i < len;++i) {
    gdjs.engineCode.GDwriter2Objects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.engineCode.eventsList16 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("action_block"), gdjs.engineCode.GDaction_9595blockObjects1);
gdjs.copyArray(runtimeScene.getObjects("col"), gdjs.engineCode.GDcolObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDcolObjects1Objects, gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDaction_95959595blockObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.engineCode.GDaObjects1 */
/* Reuse gdjs.engineCode.GDaction_9595blockObjects1 */
{gdjs.evtTools.network.jsonToObjectVariableStructure(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(8).getChild(((gdjs.engineCode.GDaObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.engineCode.GDaObjects1[0].getVariables()).getFromIndex(1).getAsString()).getChild(((gdjs.engineCode.GDaObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.engineCode.GDaObjects1[0].getVariables()).getFromIndex(0).getAsNumber()).getChild("param")), (gdjs.engineCode.GDaction_9595blockObjects1.length !== 0 ? gdjs.engineCode.GDaction_9595blockObjects1[0] : null), ((gdjs.engineCode.GDaction_9595blockObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.engineCode.GDaction_9595blockObjects1[0].getVariables()).getFromIndex(0));
}{gdjs.evtTools.network.jsonToObjectVariableStructure(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(8).getChild(((gdjs.engineCode.GDaObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.engineCode.GDaObjects1[0].getVariables()).getFromIndex(1).getAsString()).getChild(((gdjs.engineCode.GDaObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.engineCode.GDaObjects1[0].getVariables()).getFromIndex(0).getAsNumber()).getChild("code")), (gdjs.engineCode.GDaction_9595blockObjects1.length !== 0 ? gdjs.engineCode.GDaction_9595blockObjects1[0] : null), ((gdjs.engineCode.GDaction_9595blockObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.engineCode.GDaction_9595blockObjects1[0].getVariables()).getFromIndex(1));
}{gdjs.evtTools.network.jsonToObjectVariableStructure(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(8).getChild(((gdjs.engineCode.GDaObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.engineCode.GDaObjects1[0].getVariables()).getFromIndex(1).getAsString()).getChild(((gdjs.engineCode.GDaObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.engineCode.GDaObjects1[0].getVariables()).getFromIndex(0).getAsNumber()).getChild("codeE")), (gdjs.engineCode.GDaction_9595blockObjects1.length !== 0 ? gdjs.engineCode.GDaction_9595blockObjects1[0] : null), ((gdjs.engineCode.GDaction_9595blockObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.engineCode.GDaction_9595blockObjects1[0].getVariables()).getFromIndex(2));
}
{ //Subevents
gdjs.engineCode.eventsList15(runtimeScene);} //End of subevents
}

}


};gdjs.engineCode.eventsList17 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("a"), gdjs.engineCode.GDaObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDaObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.engineCode.eventsList16(runtimeScene);} //End of subevents
}

}


};gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDcObjects1Objects = Hashtable.newFrom({"c": gdjs.engineCode.GDcObjects1});
gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDcolObjects1Objects = Hashtable.newFrom({"col": gdjs.engineCode.GDcolObjects1});
gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDcondition_95959595blockObjects1Objects = Hashtable.newFrom({"condition_block": gdjs.engineCode.GDcondition_9595blockObjects1});
gdjs.engineCode.eventsList18 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("writer"), gdjs.engineCode.GDwriterObjects1);
{for(var i = 0, len = gdjs.engineCode.GDwriterObjects1.length ;i < len;++i) {
    gdjs.engineCode.GDwriterObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.engineCode.eventsList19 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("col"), gdjs.engineCode.GDcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("condition_block"), gdjs.engineCode.GDcondition_9595blockObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDcolObjects1Objects, gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDcondition_95959595blockObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.engineCode.GDcObjects1 */
/* Reuse gdjs.engineCode.GDcondition_9595blockObjects1 */
{gdjs.evtTools.network.jsonToObjectVariableStructure(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(9).getChild(((gdjs.engineCode.GDcObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.engineCode.GDcObjects1[0].getVariables()).getFromIndex(1).getAsString()).getChild(((gdjs.engineCode.GDcObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.engineCode.GDcObjects1[0].getVariables()).getFromIndex(0).getAsNumber()).getChild("param")), (gdjs.engineCode.GDcondition_9595blockObjects1.length !== 0 ? gdjs.engineCode.GDcondition_9595blockObjects1[0] : null), ((gdjs.engineCode.GDcondition_9595blockObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.engineCode.GDcondition_9595blockObjects1[0].getVariables()).getFromIndex(0));
}{gdjs.evtTools.network.jsonToObjectVariableStructure(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(9).getChild(((gdjs.engineCode.GDcObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.engineCode.GDcObjects1[0].getVariables()).getFromIndex(1).getAsString()).getChild(((gdjs.engineCode.GDcObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.engineCode.GDcObjects1[0].getVariables()).getFromIndex(0).getAsNumber()).getChild("code")), (gdjs.engineCode.GDcondition_9595blockObjects1.length !== 0 ? gdjs.engineCode.GDcondition_9595blockObjects1[0] : null), ((gdjs.engineCode.GDcondition_9595blockObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.engineCode.GDcondition_9595blockObjects1[0].getVariables()).getFromIndex(2));
}{gdjs.evtTools.network.jsonToObjectVariableStructure(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(9).getChild(((gdjs.engineCode.GDcObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.engineCode.GDcObjects1[0].getVariables()).getFromIndex(1).getAsString()).getChild(((gdjs.engineCode.GDcObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.engineCode.GDcObjects1[0].getVariables()).getFromIndex(0).getAsNumber()).getChild("codeE")), (gdjs.engineCode.GDcondition_9595blockObjects1.length !== 0 ? gdjs.engineCode.GDcondition_9595blockObjects1[0] : null), ((gdjs.engineCode.GDcondition_9595blockObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.engineCode.GDcondition_9595blockObjects1[0].getVariables()).getFromIndex(3));
}
{ //Subevents
gdjs.engineCode.eventsList18(runtimeScene);} //End of subevents
}

}


};gdjs.engineCode.eventsList20 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("c"), gdjs.engineCode.GDcObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDcObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.engineCode.eventsList19(runtimeScene);} //End of subevents
}

}


};gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDcObjects2Objects = Hashtable.newFrom({"c": gdjs.engineCode.GDcObjects2});
gdjs.engineCode.eventsList21 = function(runtimeScene) {

};gdjs.engineCode.eventsList22 = function(runtimeScene) {

{


const repeatCount4 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(9).getChild("variables").getChild(gdjs.engineCode.localVariables[1].getFromIndex(1).getAsNumber() - 1).getChild("param"));
for (let repeatIndex4 = 0;repeatIndex4 < repeatCount4;++repeatIndex4) {
gdjs.copyArray(gdjs.engineCode.GDcObjects2, gdjs.engineCode.GDcObjects4);


let isConditionTrue_0 = false;
if (true)
{
{for(var i = 0, len = gdjs.engineCode.GDcObjects4.length ;i < len;++i) {
    gdjs.engineCode.GDcObjects4[i].getBehavior("Text").setText(gdjs.engineCode.GDcObjects4[i].getBehavior("Text").getText() + (runtimeScene.getScene().getVariables().getFromIndex(9).getChild("variables").getChild(gdjs.engineCode.localVariables[1].getFromIndex(1).getAsNumber() - 1).getChild("param").getChild(gdjs.engineCode.localVariables[1].getFromIndex(0).getAsNumber()).getAsString() + runtimeScene.getScene().getVariables().getFromIndex(9).getChild("variables").getChild(gdjs.engineCode.localVariables[1].getFromIndex(1).getAsNumber() - 1).getChild("codeE").getChild(gdjs.engineCode.localVariables[1].getFromIndex(0).getAsNumber() + 1).getAsString()));
}
}{gdjs.engineCode.localVariables[1].getFromIndex(0).add(1);
}}
}

}


};gdjs.engineCode.eventsList23 = function(runtimeScene) {

{


const repeatCount2 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(9).getChild("variables"));
for (let repeatIndex2 = 0;repeatIndex2 < repeatCount2;++repeatIndex2) {
gdjs.copyArray(gdjs.engineCode.GDcObjects1, gdjs.engineCode.GDcObjects2);


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDcObjects2Objects, 0, gdjs.engineCode.localVariables[0].getFromIndex(0).getAsNumber() * 32, "conditions");
}{for(var i = 0, len = gdjs.engineCode.GDcObjects2.length ;i < len;++i) {
    gdjs.engineCode.GDcObjects2[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(9).getChild("variables").getChild(gdjs.engineCode.localVariables[1].getFromIndex(1).getAsNumber()).getChild("codeE").getChild(0).getAsString());
}
}{for(var i = 0, len = gdjs.engineCode.GDcObjects2.length ;i < len;++i) {
    gdjs.engineCode.GDcObjects2[i].returnVariable(gdjs.engineCode.GDcObjects2[i].getVariables().getFromIndex(0)).setNumber(gdjs.engineCode.localVariables[1].getFromIndex(1).getAsNumber());
}
}{gdjs.engineCode.localVariables[1].getFromIndex(1).add(1);
}{for(var i = 0, len = gdjs.engineCode.GDcObjects2.length ;i < len;++i) {
    gdjs.engineCode.GDcObjects2[i].returnVariable(gdjs.engineCode.GDcObjects2[i].getVariables().getFromIndex(1)).setString("variables");
}
}{gdjs.engineCode.localVariables[0].getFromIndex(0).add(1);
}{gdjs.engineCode.localVariables[1].getFromIndex(0).setNumber(0);
}
{ //Subevents: 
gdjs.engineCode.eventsList22(runtimeScene);} //Subevents end.
}
}

}


};gdjs.engineCode.eventsList24 = function(runtimeScene) {

{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("count", variable);
}
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("index", variable);
}
gdjs.engineCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.engineCode.eventsList23(runtimeScene);} //End of subevents
}
gdjs.engineCode.localVariables.pop();

}


};gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDaObjects2Objects = Hashtable.newFrom({"a": gdjs.engineCode.GDaObjects2});
gdjs.engineCode.eventsList25 = function(runtimeScene) {

};gdjs.engineCode.eventsList26 = function(runtimeScene) {

{


const repeatCount4 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(8).getChild("variables").getChild(gdjs.engineCode.localVariables[1].getFromIndex(1).getAsNumber() - 1).getChild("param"));
for (let repeatIndex4 = 0;repeatIndex4 < repeatCount4;++repeatIndex4) {
gdjs.copyArray(gdjs.engineCode.GDaObjects2, gdjs.engineCode.GDaObjects4);


let isConditionTrue_0 = false;
if (true)
{
{for(var i = 0, len = gdjs.engineCode.GDaObjects4.length ;i < len;++i) {
    gdjs.engineCode.GDaObjects4[i].getBehavior("Text").setText(gdjs.engineCode.GDaObjects4[i].getBehavior("Text").getText() + (runtimeScene.getScene().getVariables().getFromIndex(8).getChild("variables").getChild(gdjs.engineCode.localVariables[1].getFromIndex(1).getAsNumber() - 1).getChild("param").getChild(gdjs.engineCode.localVariables[1].getFromIndex(0).getAsNumber()).getAsString() + runtimeScene.getScene().getVariables().getFromIndex(8).getChild("variables").getChild(gdjs.engineCode.localVariables[1].getFromIndex(1).getAsNumber() - 1).getChild("codeE").getChild(gdjs.engineCode.localVariables[1].getFromIndex(0).getAsNumber() + 1).getAsString()));
}
}{gdjs.engineCode.localVariables[1].getFromIndex(0).add(1);
}}
}

}


};gdjs.engineCode.eventsList27 = function(runtimeScene) {

{


const repeatCount2 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(8).getChild("variables"));
for (let repeatIndex2 = 0;repeatIndex2 < repeatCount2;++repeatIndex2) {
gdjs.copyArray(gdjs.engineCode.GDaObjects1, gdjs.engineCode.GDaObjects2);


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDaObjects2Objects, 0, gdjs.engineCode.localVariables[0].getFromIndex(0).getAsNumber() * 32, "action");
}{for(var i = 0, len = gdjs.engineCode.GDaObjects2.length ;i < len;++i) {
    gdjs.engineCode.GDaObjects2[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(8).getChild("variables").getChild(gdjs.engineCode.localVariables[1].getFromIndex(1).getAsNumber()).getChild("codeE").getChild(0).getAsString());
}
}{for(var i = 0, len = gdjs.engineCode.GDaObjects2.length ;i < len;++i) {
    gdjs.engineCode.GDaObjects2[i].returnVariable(gdjs.engineCode.GDaObjects2[i].getVariables().getFromIndex(0)).setNumber(gdjs.engineCode.localVariables[1].getFromIndex(1).getAsNumber());
}
}{gdjs.engineCode.localVariables[1].getFromIndex(1).add(1);
}{for(var i = 0, len = gdjs.engineCode.GDaObjects2.length ;i < len;++i) {
    gdjs.engineCode.GDaObjects2[i].returnVariable(gdjs.engineCode.GDaObjects2[i].getVariables().getFromIndex(1)).setString("variables");
}
}{gdjs.engineCode.localVariables[0].getFromIndex(0).add(1);
}{gdjs.engineCode.localVariables[1].getFromIndex(0).setNumber(0);
}
{ //Subevents: 
gdjs.engineCode.eventsList26(runtimeScene);} //Subevents end.
}
}

}


};gdjs.engineCode.eventsList28 = function(runtimeScene) {

{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("count", variable);
}
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("index", variable);
}
gdjs.engineCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.engineCode.eventsList27(runtimeScene);} //End of subevents
}
gdjs.engineCode.localVariables.pop();

}


};gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDparamInputObjects2Objects = Hashtable.newFrom({"paramInput": gdjs.engineCode.GDparamInputObjects2});
gdjs.engineCode.eventsList29 = function(runtimeScene) {

};gdjs.engineCode.eventsList30 = function(runtimeScene) {

{


const repeatCount2 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(0));
for (let repeatIndex2 = 0;repeatIndex2 < repeatCount2;++repeatIndex2) {
gdjs.copyArray(gdjs.engineCode.GDparamInputObjects1, gdjs.engineCode.GDparamInputObjects2);


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDparamInputObjects2Objects, 384, 96 + (gdjs.engineCode.localVariables[1].getFromIndex(1).getAsNumber() * 32), "param");
}{for(var i = 0, len = gdjs.engineCode.GDparamInputObjects2.length ;i < len;++i) {
    gdjs.engineCode.GDparamInputObjects2[i].returnVariable(gdjs.engineCode.GDparamInputObjects2[i].getVariables().getFromIndex(0)).setNumber(gdjs.engineCode.localVariables[1].getFromIndex(1).getAsNumber());
}
}{for(var i = 0, len = gdjs.engineCode.GDparamInputObjects2.length ;i < len;++i) {
    gdjs.engineCode.GDparamInputObjects2[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(0).getChild(gdjs.engineCode.localVariables[1].getFromIndex(1).getAsNumber()).getAsString());
}
}{gdjs.engineCode.localVariables[1].getFromIndex(1).add(1);
}}
}

}


};gdjs.engineCode.eventsList31 = function(runtimeScene) {

{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("count", variable);
}
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("index", variable);
}
gdjs.engineCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.engineCode.eventsList30(runtimeScene);} //End of subevents
}
gdjs.engineCode.localVariables.pop();

}


};gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDapplyObjects1Objects = Hashtable.newFrom({"apply": gdjs.engineCode.GDapplyObjects1});
gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDcol2Objects3Objects = Hashtable.newFrom({"col2": gdjs.engineCode.GDcol2Objects3});
gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDaction_95959595blockObjects3Objects = Hashtable.newFrom({"action_block": gdjs.engineCode.GDaction_9595blockObjects3});
gdjs.engineCode.eventsList32 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("writer2"), gdjs.engineCode.GDwriter2Objects3);
{for(var i = 0, len = gdjs.engineCode.GDwriter2Objects3.length ;i < len;++i) {
    gdjs.engineCode.GDwriter2Objects3[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDcol2Objects3Objects = Hashtable.newFrom({"col2": gdjs.engineCode.GDcol2Objects3});
gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDcondition_95959595blockObjects3Objects = Hashtable.newFrom({"condition_block": gdjs.engineCode.GDcondition_9595blockObjects3});
gdjs.engineCode.eventsList33 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("writer"), gdjs.engineCode.GDwriterObjects3);
{for(var i = 0, len = gdjs.engineCode.GDwriterObjects3.length ;i < len;++i) {
    gdjs.engineCode.GDwriterObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.engineCode.eventsList34 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("action_block"), gdjs.engineCode.GDaction_9595blockObjects3);
gdjs.copyArray(runtimeScene.getObjects("col2"), gdjs.engineCode.GDcol2Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(gdjs.engineCode.localVariables[0].getFromIndex(0)) >= gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(0));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDcol2Objects3Objects, gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDaction_95959595blockObjects3Objects, false, runtimeScene, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.engineCode.GDaction_9595blockObjects3 */
{gdjs.evtTools.network.jsonToObjectVariableStructure(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(0)), (gdjs.engineCode.GDaction_9595blockObjects3.length !== 0 ? gdjs.engineCode.GDaction_9595blockObjects3[0] : null), ((gdjs.engineCode.GDaction_9595blockObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.engineCode.GDaction_9595blockObjects3[0].getVariables()).getFromIndex(0));
}
{ //Subevents
gdjs.engineCode.eventsList32(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("col2"), gdjs.engineCode.GDcol2Objects3);
gdjs.copyArray(runtimeScene.getObjects("condition_block"), gdjs.engineCode.GDcondition_9595blockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(gdjs.engineCode.localVariables[0].getFromIndex(0)) >= gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(0));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDcol2Objects3Objects, gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDcondition_95959595blockObjects3Objects, false, runtimeScene, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.engineCode.GDcondition_9595blockObjects3 */
{gdjs.evtTools.network.jsonToObjectVariableStructure(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(0)), (gdjs.engineCode.GDcondition_9595blockObjects3.length !== 0 ? gdjs.engineCode.GDcondition_9595blockObjects3[0] : null), ((gdjs.engineCode.GDcondition_9595blockObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.engineCode.GDcondition_9595blockObjects3[0].getVariables()).getFromIndex(0));
}
{ //Subevents
gdjs.engineCode.eventsList33(runtimeScene);} //End of subevents
}

}


};gdjs.engineCode.eventsList35 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("paramInput"), gdjs.engineCode.GDparamInputObjects1);

for (gdjs.engineCode.forEachIndex2 = 0;gdjs.engineCode.forEachIndex2 < gdjs.engineCode.GDparamInputObjects1.length;++gdjs.engineCode.forEachIndex2) {
gdjs.engineCode.GDparamInputObjects2.length = 0;


gdjs.engineCode.forEachTemporary2 = gdjs.engineCode.GDparamInputObjects1[gdjs.engineCode.forEachIndex2];
gdjs.engineCode.GDparamInputObjects2.push(gdjs.engineCode.forEachTemporary2);
let isConditionTrue_0 = false;
if (true) {
{runtimeScene.getScene().getVariables().getFromIndex(0).getChild(((gdjs.engineCode.GDparamInputObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.engineCode.GDparamInputObjects2[0].getVariables()).getFromIndex(0).getAsNumber()).setString((( gdjs.engineCode.GDparamInputObjects2.length === 0 ) ? "" :gdjs.engineCode.GDparamInputObjects2[0].getBehavior("Text").getText()));
}{gdjs.engineCode.localVariables[0].getFromIndex(0).add(1);
}
{ //Subevents: 
gdjs.engineCode.eventsList34(runtimeScene);} //Subevents end.
}
}

}


};gdjs.engineCode.eventsList36 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("apply"), gdjs.engineCode.GDapplyObjects1);

{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("count", variable);
}
gdjs.engineCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDapplyObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.engineCode.eventsList35(runtimeScene);} //End of subevents
}
gdjs.engineCode.localVariables.pop();

}


};gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDcondition_95959595blockObjects2Objects = Hashtable.newFrom({"condition_block": gdjs.engineCode.GDcondition_9595blockObjects2});
gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDaction_95959595blockObjects1Objects = Hashtable.newFrom({"action_block": gdjs.engineCode.GDaction_9595blockObjects1});
gdjs.engineCode.eventsList37 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("condition_block"), gdjs.engineCode.GDcondition_9595blockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDcondition_95959595blockObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(13), false, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.engineCode.GDcondition_9595blockObjects2 */
gdjs.copyArray(runtimeScene.getObjects("selector"), gdjs.engineCode.GDselectorObjects2);
{for(var i = 0, len = gdjs.engineCode.GDselectorObjects2.length ;i < len;++i) {
    gdjs.engineCode.GDselectorObjects2[i].setPosition((( gdjs.engineCode.GDcondition_9595blockObjects2.length === 0 ) ? 0 :gdjs.engineCode.GDcondition_9595blockObjects2[0].getPointX("")),(( gdjs.engineCode.GDcondition_9595blockObjects2.length === 0 ) ? 0 :gdjs.engineCode.GDcondition_9595blockObjects2[0].getPointY("")));
}
}{for(var i = 0, len = gdjs.engineCode.GDselectorObjects2.length ;i < len;++i) {
    gdjs.engineCode.GDselectorObjects2[i].setZOrder((( gdjs.engineCode.GDcondition_9595blockObjects2.length === 0 ) ? 0 :gdjs.engineCode.GDcondition_9595blockObjects2[0].getZOrder()) + 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("action_block"), gdjs.engineCode.GDaction_9595blockObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDaction_95959595blockObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(13), false, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.engineCode.GDaction_9595blockObjects1 */
gdjs.copyArray(runtimeScene.getObjects("selector"), gdjs.engineCode.GDselectorObjects1);
{for(var i = 0, len = gdjs.engineCode.GDselectorObjects1.length ;i < len;++i) {
    gdjs.engineCode.GDselectorObjects1[i].setPosition((( gdjs.engineCode.GDaction_9595blockObjects1.length === 0 ) ? 0 :gdjs.engineCode.GDaction_9595blockObjects1[0].getPointX("")) - 640,(( gdjs.engineCode.GDaction_9595blockObjects1.length === 0 ) ? 0 :gdjs.engineCode.GDaction_9595blockObjects1[0].getPointY("")));
}
}{for(var i = 0, len = gdjs.engineCode.GDselectorObjects1.length ;i < len;++i) {
    gdjs.engineCode.GDselectorObjects1[i].setZOrder((( gdjs.engineCode.GDaction_9595blockObjects1.length === 0 ) ? 0 :gdjs.engineCode.GDaction_9595blockObjects1[0].getZOrder()) + 1);
}
}}

}


};gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDselectorObjects1Objects = Hashtable.newFrom({"selector": gdjs.engineCode.GDselectorObjects1});
gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDcondition_95959595blockObjects1Objects = Hashtable.newFrom({"condition_block": gdjs.engineCode.GDcondition_9595blockObjects1});
gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDselectorObjects1Objects = Hashtable.newFrom({"selector": gdjs.engineCode.GDselectorObjects1});
gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDaction_95959595blockObjects1Objects = Hashtable.newFrom({"action_block": gdjs.engineCode.GDaction_9595blockObjects1});
gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDcondition_95959595blockObjects1Objects = Hashtable.newFrom({"condition_block": gdjs.engineCode.GDcondition_9595blockObjects1});
gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDcondition_95959595blockObjects3Objects = Hashtable.newFrom({"condition_block": gdjs.engineCode.GDcondition_9595blockObjects3});
gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDmoverObjects3Objects = Hashtable.newFrom({"mover": gdjs.engineCode.GDmoverObjects3});
gdjs.engineCode.eventsList38 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


};gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDaction_95959595blockObjects3Objects = Hashtable.newFrom({"action_block": gdjs.engineCode.GDaction_9595blockObjects3});
gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDmoverObjects3Objects = Hashtable.newFrom({"mover": gdjs.engineCode.GDmoverObjects3});
gdjs.engineCode.eventsList39 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


};gdjs.engineCode.eventsList40 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("mover"), gdjs.engineCode.GDmoverObjects1);
{for(var i = 0, len = gdjs.engineCode.GDmoverObjects1.length ;i < len;++i) {
    gdjs.engineCode.GDmoverObjects1[i].setX(-(1500));
}
}}

}


};gdjs.engineCode.eventsList41 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.engineCode.GDcondition_9595blockObjects1, gdjs.engineCode.GDcondition_9595blockObjects2);


for (gdjs.engineCode.forEachIndex3 = 0;gdjs.engineCode.forEachIndex3 < gdjs.engineCode.GDcondition_9595blockObjects2.length;++gdjs.engineCode.forEachIndex3) {
gdjs.copyArray(runtimeScene.getObjects("mover"), gdjs.engineCode.GDmoverObjects3);
gdjs.engineCode.GDcondition_9595blockObjects3.length = 0;


gdjs.engineCode.forEachTemporary3 = gdjs.engineCode.GDcondition_9595blockObjects2[gdjs.engineCode.forEachIndex3];
gdjs.engineCode.GDcondition_9595blockObjects3.push(gdjs.engineCode.forEachTemporary3);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDcondition_95959595blockObjects3Objects, gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDmoverObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.engineCode.GDcondition_9595blockObjects3.length ;i < len;++i) {
    gdjs.engineCode.GDcondition_9595blockObjects3[i].setY(gdjs.engineCode.GDcondition_9595blockObjects3[i].getY() - (32));
}
}
{ //Subevents: 
gdjs.engineCode.eventsList38(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("action_block"), gdjs.engineCode.GDaction_9595blockObjects2);

for (gdjs.engineCode.forEachIndex3 = 0;gdjs.engineCode.forEachIndex3 < gdjs.engineCode.GDaction_9595blockObjects2.length;++gdjs.engineCode.forEachIndex3) {
gdjs.copyArray(runtimeScene.getObjects("mover"), gdjs.engineCode.GDmoverObjects3);
gdjs.engineCode.GDaction_9595blockObjects3.length = 0;


gdjs.engineCode.forEachTemporary3 = gdjs.engineCode.GDaction_9595blockObjects2[gdjs.engineCode.forEachIndex3];
gdjs.engineCode.GDaction_9595blockObjects3.push(gdjs.engineCode.forEachTemporary3);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDaction_95959595blockObjects3Objects, gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDmoverObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.engineCode.GDaction_9595blockObjects3.length ;i < len;++i) {
    gdjs.engineCode.GDaction_9595blockObjects3[i].setY(gdjs.engineCode.GDaction_9595blockObjects3[i].getY() - (32));
}
}
{ //Subevents: 
gdjs.engineCode.eventsList39(runtimeScene);} //Subevents end.
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22396652);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(13).setBoolean(false);
}
{ //Subevents
gdjs.engineCode.eventsList40(runtimeScene);} //End of subevents
}

}


};gdjs.engineCode.eventsList42 = function(runtimeScene) {

{


gdjs.engineCode.eventsList0(runtimeScene);
}


{


gdjs.engineCode.eventsList1(runtimeScene);
}


{


gdjs.engineCode.eventsList8(runtimeScene);
}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(1);
variables._declare("count", variable);
}
gdjs.engineCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.engineCode.mapOfEmptyGDcondition_9595blockObjects) != gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.engineCode.mapOfEmptyGDwriterObjects);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22327948);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("writer"), gdjs.engineCode.GDwriterObjects1);
{for(var i = 0, len = gdjs.engineCode.GDwriterObjects1.length ;i < len;++i) {
    gdjs.engineCode.GDwriterObjects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.engineCode.eventsList11(runtimeScene);} //End of subevents
}
gdjs.engineCode.localVariables.pop();

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(1);
variables._declare("count", variable);
}
{
const variable = new gdjs.Variable();
variables._declare("txt", variable);
}
gdjs.engineCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.engineCode.mapOfEmptyGDaction_9595blockObjects) != gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.engineCode.mapOfEmptyGDwriter2Objects);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22333532);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("writer2"), gdjs.engineCode.GDwriter2Objects1);
{for(var i = 0, len = gdjs.engineCode.GDwriter2Objects1.length ;i < len;++i) {
    gdjs.engineCode.GDwriter2Objects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.engineCode.eventsList14(runtimeScene);} //End of subevents
}
gdjs.engineCode.localVariables.pop();

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("add"), gdjs.engineCode.GDaddObjects1);
gdjs.copyArray(runtimeScene.getObjects("code_view"), gdjs.engineCode.GDcode_9595viewObjects1);
{for(var i = 0, len = gdjs.engineCode.GDcode_9595viewObjects1.length ;i < len;++i) {
    gdjs.engineCode.GDcode_9595viewObjects1[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(3).getAsString() + runtimeScene.getScene().getVariables().getFromIndex(2).getAsString());
}
}{for(var i = 0, len = gdjs.engineCode.GDaddObjects1.length ;i < len;++i) {
    gdjs.engineCode.GDaddObjects1[i].setY(32 + gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.engineCode.mapOfEmptyGDaction_9595blockObjects) * 32);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("condition_block"), gdjs.engineCode.GDcondition_9595blockObjects1);
gdjs.copyArray(runtimeScene.getObjects("writer"), gdjs.engineCode.GDwriterObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDcondition_95959595blockObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDwriterObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conditions"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "action"));
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("col"), gdjs.engineCode.GDcolObjects1);
/* Reuse gdjs.engineCode.GDcondition_9595blockObjects1 */
{gdjs.evtTools.camera.showLayer(runtimeScene, "conditions");
}{for(var i = 0, len = gdjs.engineCode.GDcolObjects1.length ;i < len;++i) {
    gdjs.engineCode.GDcolObjects1[i].setPosition((( gdjs.engineCode.GDcondition_9595blockObjects1.length === 0 ) ? 0 :gdjs.engineCode.GDcondition_9595blockObjects1[0].getPointX("")) + 8,(( gdjs.engineCode.GDcondition_9595blockObjects1.length === 0 ) ? 0 :gdjs.engineCode.GDcondition_9595blockObjects1[0].getPointY("")) + 8);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("action_block"), gdjs.engineCode.GDaction_9595blockObjects1);
gdjs.copyArray(runtimeScene.getObjects("writer2"), gdjs.engineCode.GDwriter2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDaction_95959595blockObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDwriter2Objects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conditions"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "action"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "param"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.engineCode.GDaction_9595blockObjects1 */
gdjs.copyArray(runtimeScene.getObjects("col"), gdjs.engineCode.GDcolObjects1);
{gdjs.evtTools.camera.showLayer(runtimeScene, "action");
}{for(var i = 0, len = gdjs.engineCode.GDcolObjects1.length ;i < len;++i) {
    gdjs.engineCode.GDcolObjects1[i].setPosition((( gdjs.engineCode.GDaction_9595blockObjects1.length === 0 ) ? 0 :gdjs.engineCode.GDaction_9595blockObjects1[0].getPointX("")) + 8,(( gdjs.engineCode.GDaction_9595blockObjects1.length === 0 ) ? 0 :gdjs.engineCode.GDaction_9595blockObjects1[0].getPointY("")) + 8);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("condition_block"), gdjs.engineCode.GDcondition_9595blockObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDcondition_95959595blockObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Right");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conditions"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "action"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "param"));
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("col2"), gdjs.engineCode.GDcol2Objects1);
/* Reuse gdjs.engineCode.GDcondition_9595blockObjects1 */
{for(var i = 0, len = gdjs.engineCode.GDcol2Objects1.length ;i < len;++i) {
    gdjs.engineCode.GDcol2Objects1[i].setPosition((( gdjs.engineCode.GDcondition_9595blockObjects1.length === 0 ) ? 0 :gdjs.engineCode.GDcondition_9595blockObjects1[0].getPointX("")) + 8,(( gdjs.engineCode.GDcondition_9595blockObjects1.length === 0 ) ? 0 :gdjs.engineCode.GDcondition_9595blockObjects1[0].getPointY("")) + 8);
}
}{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.network.objectVariableStructureToJSON((gdjs.engineCode.GDcondition_9595blockObjects1.length !== 0 ? gdjs.engineCode.GDcondition_9595blockObjects1[0] : null), ((gdjs.engineCode.GDcondition_9595blockObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.engineCode.GDcondition_9595blockObjects1[0].getVariables()).getFromIndex(0)), runtimeScene.getScene().getVariables().getFromIndex(0));
}{gdjs.evtTools.camera.showLayer(runtimeScene, "param");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("action_block"), gdjs.engineCode.GDaction_9595blockObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDaction_95959595blockObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Right");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conditions"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "action"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "param"));
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.engineCode.GDaction_9595blockObjects1 */
gdjs.copyArray(runtimeScene.getObjects("col2"), gdjs.engineCode.GDcol2Objects1);
{for(var i = 0, len = gdjs.engineCode.GDcol2Objects1.length ;i < len;++i) {
    gdjs.engineCode.GDcol2Objects1[i].setPosition((( gdjs.engineCode.GDaction_9595blockObjects1.length === 0 ) ? 0 :gdjs.engineCode.GDaction_9595blockObjects1[0].getPointX("")) + 8,(( gdjs.engineCode.GDaction_9595blockObjects1.length === 0 ) ? 0 :gdjs.engineCode.GDaction_9595blockObjects1[0].getPointY("")) + 8);
}
}{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.network.objectVariableStructureToJSON((gdjs.engineCode.GDaction_9595blockObjects1.length !== 0 ? gdjs.engineCode.GDaction_9595blockObjects1[0] : null), ((gdjs.engineCode.GDaction_9595blockObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.engineCode.GDaction_9595blockObjects1[0].getVariables()).getFromIndex(0)), runtimeScene.getScene().getVariables().getFromIndex(0));
}{gdjs.evtTools.camera.showLayer(runtimeScene, "param");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
if (isConditionTrue_0) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "conditions");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "action");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "param");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "action");
if (isConditionTrue_0) {

{ //Subevents
gdjs.engineCode.eventsList17(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conditions");
if (isConditionTrue_0) {

{ //Subevents
gdjs.engineCode.eventsList20(runtimeScene);} //End of subevents
}

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(1);
variables._declare("counter", variable);
}
gdjs.engineCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conditions");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22365620);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("c"), gdjs.engineCode.GDcObjects1);
{for(var i = 0, len = gdjs.engineCode.GDcObjects1.length ;i < len;++i) {
    gdjs.engineCode.GDcObjects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.engineCode.eventsList24(runtimeScene);} //End of subevents
}
gdjs.engineCode.localVariables.pop();

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(1);
variables._declare("counter", variable);
}
gdjs.engineCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "action");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22370972);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("a"), gdjs.engineCode.GDaObjects1);
{for(var i = 0, len = gdjs.engineCode.GDaObjects1.length ;i < len;++i) {
    gdjs.engineCode.GDaObjects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.engineCode.eventsList28(runtimeScene);} //End of subevents
}
gdjs.engineCode.localVariables.pop();

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(1);
variables._declare("counter", variable);
}
gdjs.engineCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "param");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22376156);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("paramInput"), gdjs.engineCode.GDparamInputObjects1);
{for(var i = 0, len = gdjs.engineCode.GDparamInputObjects1.length ;i < len;++i) {
    gdjs.engineCode.GDparamInputObjects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.engineCode.eventsList31(runtimeScene);} //End of subevents
}
gdjs.engineCode.localVariables.pop();

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "param");
if (isConditionTrue_0) {

{ //Subevents
gdjs.engineCode.eventsList36(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {

{ //Subevents
gdjs.engineCode.eventsList37(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("action_block"), gdjs.engineCode.GDaction_9595blockObjects1);
gdjs.copyArray(runtimeScene.getObjects("condition_block"), gdjs.engineCode.GDcondition_9595blockObjects1);
gdjs.copyArray(runtimeScene.getObjects("selector"), gdjs.engineCode.GDselectorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDselectorObjects1Objects, gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDcondition_95959595blockObjects1Objects, false, runtimeScene, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDselectorObjects1Objects, gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDaction_95959595blockObjects1Objects, false, runtimeScene, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Delete");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(13), false, false);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.engineCode.GDaction_9595blockObjects1 */
/* Reuse gdjs.engineCode.GDcondition_9595blockObjects1 */
gdjs.copyArray(runtimeScene.getObjects("mover"), gdjs.engineCode.GDmoverObjects1);
/* Reuse gdjs.engineCode.GDselectorObjects1 */
gdjs.copyArray(runtimeScene.getObjects("writer"), gdjs.engineCode.GDwriterObjects1);
gdjs.copyArray(runtimeScene.getObjects("writer2"), gdjs.engineCode.GDwriter2Objects1);
{for(var i = 0, len = gdjs.engineCode.GDmoverObjects1.length ;i < len;++i) {
    gdjs.engineCode.GDmoverObjects1[i].setY((( gdjs.engineCode.GDselectorObjects1.length === 0 ) ? 0 :gdjs.engineCode.GDselectorObjects1[0].getY()) + 64);
}
}{runtimeScene.getScene().getVariables().getFromIndex(12).setNumber((( gdjs.engineCode.GDselectorObjects1.length === 0 ) ? 0 :gdjs.engineCode.GDselectorObjects1[0].getY()));
}{runtimeScene.getScene().getVariables().getFromIndex(7).setNumber((( gdjs.engineCode.GDcondition_9595blockObjects1.length === 0 ) ? 0 :gdjs.engineCode.GDcondition_9595blockObjects1[0].getPointY("")) / 32);
}{for(var i = 0, len = gdjs.engineCode.GDcondition_9595blockObjects1.length ;i < len;++i) {
    gdjs.engineCode.GDcondition_9595blockObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.engineCode.GDaction_9595blockObjects1.length ;i < len;++i) {
    gdjs.engineCode.GDaction_9595blockObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.engineCode.GDwriterObjects1.length ;i < len;++i) {
    gdjs.engineCode.GDwriterObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.engineCode.GDwriter2Objects1.length ;i < len;++i) {
    gdjs.engineCode.GDwriter2Objects1[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(13).setBoolean(true);
}{for(var i = 0, len = gdjs.engineCode.GDmoverObjects1.length ;i < len;++i) {
    gdjs.engineCode.GDmoverObjects1[i].getBehavior("Resizable").setHeight(96 + gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.engineCode.mapOfGDgdjs_9546engineCode_9546GDcondition_95959595blockObjects1Objects) * 32);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(13), true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("condition_block"), gdjs.engineCode.GDcondition_9595blockObjects1);
{for(var i = 0, len = gdjs.engineCode.GDcondition_9595blockObjects1.length ;i < len;++i) {
    gdjs.engineCode.GDcondition_9595blockObjects1[i].setX(0);
}
}
{ //Subevents
gdjs.engineCode.eventsList41(runtimeScene);} //End of subevents
}

}


{



}


{



}


{



}


{



}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.engineCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.engineCode.GDcondition_9595blockObjects1.length = 0;
gdjs.engineCode.GDcondition_9595blockObjects2.length = 0;
gdjs.engineCode.GDcondition_9595blockObjects3.length = 0;
gdjs.engineCode.GDcondition_9595blockObjects4.length = 0;
gdjs.engineCode.GDcondition_9595blockObjects5.length = 0;
gdjs.engineCode.GDaction_9595blockObjects1.length = 0;
gdjs.engineCode.GDaction_9595blockObjects2.length = 0;
gdjs.engineCode.GDaction_9595blockObjects3.length = 0;
gdjs.engineCode.GDaction_9595blockObjects4.length = 0;
gdjs.engineCode.GDaction_9595blockObjects5.length = 0;
gdjs.engineCode.GDwriterObjects1.length = 0;
gdjs.engineCode.GDwriterObjects2.length = 0;
gdjs.engineCode.GDwriterObjects3.length = 0;
gdjs.engineCode.GDwriterObjects4.length = 0;
gdjs.engineCode.GDwriterObjects5.length = 0;
gdjs.engineCode.GDdialougObjects1.length = 0;
gdjs.engineCode.GDdialougObjects2.length = 0;
gdjs.engineCode.GDdialougObjects3.length = 0;
gdjs.engineCode.GDdialougObjects4.length = 0;
gdjs.engineCode.GDdialougObjects5.length = 0;
gdjs.engineCode.GDvirtualObjects1.length = 0;
gdjs.engineCode.GDvirtualObjects2.length = 0;
gdjs.engineCode.GDvirtualObjects3.length = 0;
gdjs.engineCode.GDvirtualObjects4.length = 0;
gdjs.engineCode.GDvirtualObjects5.length = 0;
gdjs.engineCode.GDsaObjects1.length = 0;
gdjs.engineCode.GDsaObjects2.length = 0;
gdjs.engineCode.GDsaObjects3.length = 0;
gdjs.engineCode.GDsaObjects4.length = 0;
gdjs.engineCode.GDsaObjects5.length = 0;
gdjs.engineCode.GDscObjects1.length = 0;
gdjs.engineCode.GDscObjects2.length = 0;
gdjs.engineCode.GDscObjects3.length = 0;
gdjs.engineCode.GDscObjects4.length = 0;
gdjs.engineCode.GDscObjects5.length = 0;
gdjs.engineCode.GDwriter2Objects1.length = 0;
gdjs.engineCode.GDwriter2Objects2.length = 0;
gdjs.engineCode.GDwriter2Objects3.length = 0;
gdjs.engineCode.GDwriter2Objects4.length = 0;
gdjs.engineCode.GDwriter2Objects5.length = 0;
gdjs.engineCode.GDcode_9595viewObjects1.length = 0;
gdjs.engineCode.GDcode_9595viewObjects2.length = 0;
gdjs.engineCode.GDcode_9595viewObjects3.length = 0;
gdjs.engineCode.GDcode_9595viewObjects4.length = 0;
gdjs.engineCode.GDcode_9595viewObjects5.length = 0;
gdjs.engineCode.GDdrawerObjects1.length = 0;
gdjs.engineCode.GDdrawerObjects2.length = 0;
gdjs.engineCode.GDdrawerObjects3.length = 0;
gdjs.engineCode.GDdrawerObjects4.length = 0;
gdjs.engineCode.GDdrawerObjects5.length = 0;
gdjs.engineCode.GDaddObjects1.length = 0;
gdjs.engineCode.GDaddObjects2.length = 0;
gdjs.engineCode.GDaddObjects3.length = 0;
gdjs.engineCode.GDaddObjects4.length = 0;
gdjs.engineCode.GDaddObjects5.length = 0;
gdjs.engineCode.GDapplyObjects1.length = 0;
gdjs.engineCode.GDapplyObjects2.length = 0;
gdjs.engineCode.GDapplyObjects3.length = 0;
gdjs.engineCode.GDapplyObjects4.length = 0;
gdjs.engineCode.GDapplyObjects5.length = 0;
gdjs.engineCode.GDparamInputObjects1.length = 0;
gdjs.engineCode.GDparamInputObjects2.length = 0;
gdjs.engineCode.GDparamInputObjects3.length = 0;
gdjs.engineCode.GDparamInputObjects4.length = 0;
gdjs.engineCode.GDparamInputObjects5.length = 0;
gdjs.engineCode.GDcolObjects1.length = 0;
gdjs.engineCode.GDcolObjects2.length = 0;
gdjs.engineCode.GDcolObjects3.length = 0;
gdjs.engineCode.GDcolObjects4.length = 0;
gdjs.engineCode.GDcolObjects5.length = 0;
gdjs.engineCode.GDcObjects1.length = 0;
gdjs.engineCode.GDcObjects2.length = 0;
gdjs.engineCode.GDcObjects3.length = 0;
gdjs.engineCode.GDcObjects4.length = 0;
gdjs.engineCode.GDcObjects5.length = 0;
gdjs.engineCode.GDaObjects1.length = 0;
gdjs.engineCode.GDaObjects2.length = 0;
gdjs.engineCode.GDaObjects3.length = 0;
gdjs.engineCode.GDaObjects4.length = 0;
gdjs.engineCode.GDaObjects5.length = 0;
gdjs.engineCode.GDcol2Objects1.length = 0;
gdjs.engineCode.GDcol2Objects2.length = 0;
gdjs.engineCode.GDcol2Objects3.length = 0;
gdjs.engineCode.GDcol2Objects4.length = 0;
gdjs.engineCode.GDcol2Objects5.length = 0;
gdjs.engineCode.GDselectorObjects1.length = 0;
gdjs.engineCode.GDselectorObjects2.length = 0;
gdjs.engineCode.GDselectorObjects3.length = 0;
gdjs.engineCode.GDselectorObjects4.length = 0;
gdjs.engineCode.GDselectorObjects5.length = 0;
gdjs.engineCode.GDmoverObjects1.length = 0;
gdjs.engineCode.GDmoverObjects2.length = 0;
gdjs.engineCode.GDmoverObjects3.length = 0;
gdjs.engineCode.GDmoverObjects4.length = 0;
gdjs.engineCode.GDmoverObjects5.length = 0;

gdjs.engineCode.eventsList42(runtimeScene);
gdjs.engineCode.GDcondition_9595blockObjects1.length = 0;
gdjs.engineCode.GDcondition_9595blockObjects2.length = 0;
gdjs.engineCode.GDcondition_9595blockObjects3.length = 0;
gdjs.engineCode.GDcondition_9595blockObjects4.length = 0;
gdjs.engineCode.GDcondition_9595blockObjects5.length = 0;
gdjs.engineCode.GDaction_9595blockObjects1.length = 0;
gdjs.engineCode.GDaction_9595blockObjects2.length = 0;
gdjs.engineCode.GDaction_9595blockObjects3.length = 0;
gdjs.engineCode.GDaction_9595blockObjects4.length = 0;
gdjs.engineCode.GDaction_9595blockObjects5.length = 0;
gdjs.engineCode.GDwriterObjects1.length = 0;
gdjs.engineCode.GDwriterObjects2.length = 0;
gdjs.engineCode.GDwriterObjects3.length = 0;
gdjs.engineCode.GDwriterObjects4.length = 0;
gdjs.engineCode.GDwriterObjects5.length = 0;
gdjs.engineCode.GDdialougObjects1.length = 0;
gdjs.engineCode.GDdialougObjects2.length = 0;
gdjs.engineCode.GDdialougObjects3.length = 0;
gdjs.engineCode.GDdialougObjects4.length = 0;
gdjs.engineCode.GDdialougObjects5.length = 0;
gdjs.engineCode.GDvirtualObjects1.length = 0;
gdjs.engineCode.GDvirtualObjects2.length = 0;
gdjs.engineCode.GDvirtualObjects3.length = 0;
gdjs.engineCode.GDvirtualObjects4.length = 0;
gdjs.engineCode.GDvirtualObjects5.length = 0;
gdjs.engineCode.GDsaObjects1.length = 0;
gdjs.engineCode.GDsaObjects2.length = 0;
gdjs.engineCode.GDsaObjects3.length = 0;
gdjs.engineCode.GDsaObjects4.length = 0;
gdjs.engineCode.GDsaObjects5.length = 0;
gdjs.engineCode.GDscObjects1.length = 0;
gdjs.engineCode.GDscObjects2.length = 0;
gdjs.engineCode.GDscObjects3.length = 0;
gdjs.engineCode.GDscObjects4.length = 0;
gdjs.engineCode.GDscObjects5.length = 0;
gdjs.engineCode.GDwriter2Objects1.length = 0;
gdjs.engineCode.GDwriter2Objects2.length = 0;
gdjs.engineCode.GDwriter2Objects3.length = 0;
gdjs.engineCode.GDwriter2Objects4.length = 0;
gdjs.engineCode.GDwriter2Objects5.length = 0;
gdjs.engineCode.GDcode_9595viewObjects1.length = 0;
gdjs.engineCode.GDcode_9595viewObjects2.length = 0;
gdjs.engineCode.GDcode_9595viewObjects3.length = 0;
gdjs.engineCode.GDcode_9595viewObjects4.length = 0;
gdjs.engineCode.GDcode_9595viewObjects5.length = 0;
gdjs.engineCode.GDdrawerObjects1.length = 0;
gdjs.engineCode.GDdrawerObjects2.length = 0;
gdjs.engineCode.GDdrawerObjects3.length = 0;
gdjs.engineCode.GDdrawerObjects4.length = 0;
gdjs.engineCode.GDdrawerObjects5.length = 0;
gdjs.engineCode.GDaddObjects1.length = 0;
gdjs.engineCode.GDaddObjects2.length = 0;
gdjs.engineCode.GDaddObjects3.length = 0;
gdjs.engineCode.GDaddObjects4.length = 0;
gdjs.engineCode.GDaddObjects5.length = 0;
gdjs.engineCode.GDapplyObjects1.length = 0;
gdjs.engineCode.GDapplyObjects2.length = 0;
gdjs.engineCode.GDapplyObjects3.length = 0;
gdjs.engineCode.GDapplyObjects4.length = 0;
gdjs.engineCode.GDapplyObjects5.length = 0;
gdjs.engineCode.GDparamInputObjects1.length = 0;
gdjs.engineCode.GDparamInputObjects2.length = 0;
gdjs.engineCode.GDparamInputObjects3.length = 0;
gdjs.engineCode.GDparamInputObjects4.length = 0;
gdjs.engineCode.GDparamInputObjects5.length = 0;
gdjs.engineCode.GDcolObjects1.length = 0;
gdjs.engineCode.GDcolObjects2.length = 0;
gdjs.engineCode.GDcolObjects3.length = 0;
gdjs.engineCode.GDcolObjects4.length = 0;
gdjs.engineCode.GDcolObjects5.length = 0;
gdjs.engineCode.GDcObjects1.length = 0;
gdjs.engineCode.GDcObjects2.length = 0;
gdjs.engineCode.GDcObjects3.length = 0;
gdjs.engineCode.GDcObjects4.length = 0;
gdjs.engineCode.GDcObjects5.length = 0;
gdjs.engineCode.GDaObjects1.length = 0;
gdjs.engineCode.GDaObjects2.length = 0;
gdjs.engineCode.GDaObjects3.length = 0;
gdjs.engineCode.GDaObjects4.length = 0;
gdjs.engineCode.GDaObjects5.length = 0;
gdjs.engineCode.GDcol2Objects1.length = 0;
gdjs.engineCode.GDcol2Objects2.length = 0;
gdjs.engineCode.GDcol2Objects3.length = 0;
gdjs.engineCode.GDcol2Objects4.length = 0;
gdjs.engineCode.GDcol2Objects5.length = 0;
gdjs.engineCode.GDselectorObjects1.length = 0;
gdjs.engineCode.GDselectorObjects2.length = 0;
gdjs.engineCode.GDselectorObjects3.length = 0;
gdjs.engineCode.GDselectorObjects4.length = 0;
gdjs.engineCode.GDselectorObjects5.length = 0;
gdjs.engineCode.GDmoverObjects1.length = 0;
gdjs.engineCode.GDmoverObjects2.length = 0;
gdjs.engineCode.GDmoverObjects3.length = 0;
gdjs.engineCode.GDmoverObjects4.length = 0;
gdjs.engineCode.GDmoverObjects5.length = 0;


return;

}

gdjs['engineCode'] = gdjs.engineCode;
