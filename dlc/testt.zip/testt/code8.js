gdjs.sceneCode = {};
gdjs.sceneCode.localVariables = [];
gdjs.sceneCode.forEachIndex2 = 0;

gdjs.sceneCode.forEachIndex3 = 0;

gdjs.sceneCode.forEachObjects2 = [];

gdjs.sceneCode.forEachObjects3 = [];

gdjs.sceneCode.forEachTemporary2 = null;

gdjs.sceneCode.forEachTemporary3 = null;

gdjs.sceneCode.forEachTotalCount2 = 0;

gdjs.sceneCode.forEachTotalCount3 = 0;

gdjs.sceneCode.GDspriteObjects1= [];
gdjs.sceneCode.GDspriteObjects2= [];
gdjs.sceneCode.GDspriteObjects3= [];
gdjs.sceneCode.GDspriteObjects4= [];
gdjs.sceneCode.GDspriteObjects5= [];
gdjs.sceneCode.GDspriteObjects6= [];
gdjs.sceneCode.GDspriteObjects7= [];
gdjs.sceneCode.GDspriteObjects8= [];
gdjs.sceneCode.GDdebugObjects1= [];
gdjs.sceneCode.GDdebugObjects2= [];
gdjs.sceneCode.GDdebugObjects3= [];
gdjs.sceneCode.GDdebugObjects4= [];
gdjs.sceneCode.GDdebugObjects5= [];
gdjs.sceneCode.GDdebugObjects6= [];
gdjs.sceneCode.GDdebugObjects7= [];
gdjs.sceneCode.GDdebugObjects8= [];
gdjs.sceneCode.GDdialougObjects1= [];
gdjs.sceneCode.GDdialougObjects2= [];
gdjs.sceneCode.GDdialougObjects3= [];
gdjs.sceneCode.GDdialougObjects4= [];
gdjs.sceneCode.GDdialougObjects5= [];
gdjs.sceneCode.GDdialougObjects6= [];
gdjs.sceneCode.GDdialougObjects7= [];
gdjs.sceneCode.GDdialougObjects8= [];
gdjs.sceneCode.GDobject_9595var_9595inputObjects1= [];
gdjs.sceneCode.GDobject_9595var_9595inputObjects2= [];
gdjs.sceneCode.GDobject_9595var_9595inputObjects3= [];
gdjs.sceneCode.GDobject_9595var_9595inputObjects4= [];
gdjs.sceneCode.GDobject_9595var_9595inputObjects5= [];
gdjs.sceneCode.GDobject_9595var_9595inputObjects6= [];
gdjs.sceneCode.GDobject_9595var_9595inputObjects7= [];
gdjs.sceneCode.GDobject_9595var_9595inputObjects8= [];
gdjs.sceneCode.GDobjectNamesObjects1= [];
gdjs.sceneCode.GDobjectNamesObjects2= [];
gdjs.sceneCode.GDobjectNamesObjects3= [];
gdjs.sceneCode.GDobjectNamesObjects4= [];
gdjs.sceneCode.GDobjectNamesObjects5= [];
gdjs.sceneCode.GDobjectNamesObjects6= [];
gdjs.sceneCode.GDobjectNamesObjects7= [];
gdjs.sceneCode.GDobjectNamesObjects8= [];
gdjs.sceneCode.GDobjectNameObjects1= [];
gdjs.sceneCode.GDobjectNameObjects2= [];
gdjs.sceneCode.GDobjectNameObjects3= [];
gdjs.sceneCode.GDobjectNameObjects4= [];
gdjs.sceneCode.GDobjectNameObjects5= [];
gdjs.sceneCode.GDobjectNameObjects6= [];
gdjs.sceneCode.GDobjectNameObjects7= [];
gdjs.sceneCode.GDobjectNameObjects8= [];
gdjs.sceneCode.GDdragNdropObjects1= [];
gdjs.sceneCode.GDdragNdropObjects2= [];
gdjs.sceneCode.GDdragNdropObjects3= [];
gdjs.sceneCode.GDdragNdropObjects4= [];
gdjs.sceneCode.GDdragNdropObjects5= [];
gdjs.sceneCode.GDdragNdropObjects6= [];
gdjs.sceneCode.GDdragNdropObjects7= [];
gdjs.sceneCode.GDdragNdropObjects8= [];
gdjs.sceneCode.GDobj_9595scpObjects1= [];
gdjs.sceneCode.GDobj_9595scpObjects2= [];
gdjs.sceneCode.GDobj_9595scpObjects3= [];
gdjs.sceneCode.GDobj_9595scpObjects4= [];
gdjs.sceneCode.GDobj_9595scpObjects5= [];
gdjs.sceneCode.GDobj_9595scpObjects6= [];
gdjs.sceneCode.GDobj_9595scpObjects7= [];
gdjs.sceneCode.GDobj_9595scpObjects8= [];
gdjs.sceneCode.GDobjectName2Objects1= [];
gdjs.sceneCode.GDobjectName2Objects2= [];
gdjs.sceneCode.GDobjectName2Objects3= [];
gdjs.sceneCode.GDobjectName2Objects4= [];
gdjs.sceneCode.GDobjectName2Objects5= [];
gdjs.sceneCode.GDobjectName2Objects6= [];
gdjs.sceneCode.GDobjectName2Objects7= [];
gdjs.sceneCode.GDobjectName2Objects8= [];
gdjs.sceneCode.GDfake_9595cuObjects1= [];
gdjs.sceneCode.GDfake_9595cuObjects2= [];
gdjs.sceneCode.GDfake_9595cuObjects3= [];
gdjs.sceneCode.GDfake_9595cuObjects4= [];
gdjs.sceneCode.GDfake_9595cuObjects5= [];
gdjs.sceneCode.GDfake_9595cuObjects6= [];
gdjs.sceneCode.GDfake_9595cuObjects7= [];
gdjs.sceneCode.GDfake_9595cuObjects8= [];
gdjs.sceneCode.GDijObjects1= [];
gdjs.sceneCode.GDijObjects2= [];
gdjs.sceneCode.GDijObjects3= [];
gdjs.sceneCode.GDijObjects4= [];
gdjs.sceneCode.GDijObjects5= [];
gdjs.sceneCode.GDijObjects6= [];
gdjs.sceneCode.GDijObjects7= [];
gdjs.sceneCode.GDijObjects8= [];
gdjs.sceneCode.GDscrObjects1= [];
gdjs.sceneCode.GDscrObjects2= [];
gdjs.sceneCode.GDscrObjects3= [];
gdjs.sceneCode.GDscrObjects4= [];
gdjs.sceneCode.GDscrObjects5= [];
gdjs.sceneCode.GDscrObjects6= [];
gdjs.sceneCode.GDscrObjects7= [];
gdjs.sceneCode.GDscrObjects8= [];
gdjs.sceneCode.GDwidthObjects1= [];
gdjs.sceneCode.GDwidthObjects2= [];
gdjs.sceneCode.GDwidthObjects3= [];
gdjs.sceneCode.GDwidthObjects4= [];
gdjs.sceneCode.GDwidthObjects5= [];
gdjs.sceneCode.GDwidthObjects6= [];
gdjs.sceneCode.GDwidthObjects7= [];
gdjs.sceneCode.GDwidthObjects8= [];
gdjs.sceneCode.GDheightObjects1= [];
gdjs.sceneCode.GDheightObjects2= [];
gdjs.sceneCode.GDheightObjects3= [];
gdjs.sceneCode.GDheightObjects4= [];
gdjs.sceneCode.GDheightObjects5= [];
gdjs.sceneCode.GDheightObjects6= [];
gdjs.sceneCode.GDheightObjects7= [];
gdjs.sceneCode.GDheightObjects8= [];
gdjs.sceneCode.GDxObjects1= [];
gdjs.sceneCode.GDxObjects2= [];
gdjs.sceneCode.GDxObjects3= [];
gdjs.sceneCode.GDxObjects4= [];
gdjs.sceneCode.GDxObjects5= [];
gdjs.sceneCode.GDxObjects6= [];
gdjs.sceneCode.GDxObjects7= [];
gdjs.sceneCode.GDxObjects8= [];
gdjs.sceneCode.GDyObjects1= [];
gdjs.sceneCode.GDyObjects2= [];
gdjs.sceneCode.GDyObjects3= [];
gdjs.sceneCode.GDyObjects4= [];
gdjs.sceneCode.GDyObjects5= [];
gdjs.sceneCode.GDyObjects6= [];
gdjs.sceneCode.GDyObjects7= [];
gdjs.sceneCode.GDyObjects8= [];
gdjs.sceneCode.GDNewTextObjects1= [];
gdjs.sceneCode.GDNewTextObjects2= [];
gdjs.sceneCode.GDNewTextObjects3= [];
gdjs.sceneCode.GDNewTextObjects4= [];
gdjs.sceneCode.GDNewTextObjects5= [];
gdjs.sceneCode.GDNewTextObjects6= [];
gdjs.sceneCode.GDNewTextObjects7= [];
gdjs.sceneCode.GDNewTextObjects8= [];
gdjs.sceneCode.GDstateObjects1= [];
gdjs.sceneCode.GDstateObjects2= [];
gdjs.sceneCode.GDstateObjects3= [];
gdjs.sceneCode.GDstateObjects4= [];
gdjs.sceneCode.GDstateObjects5= [];
gdjs.sceneCode.GDstateObjects6= [];
gdjs.sceneCode.GDstateObjects7= [];
gdjs.sceneCode.GDstateObjects8= [];
gdjs.sceneCode.GDboxObjects1= [];
gdjs.sceneCode.GDboxObjects2= [];
gdjs.sceneCode.GDboxObjects3= [];
gdjs.sceneCode.GDboxObjects4= [];
gdjs.sceneCode.GDboxObjects5= [];
gdjs.sceneCode.GDboxObjects6= [];
gdjs.sceneCode.GDboxObjects7= [];
gdjs.sceneCode.GDboxObjects8= [];
gdjs.sceneCode.GDaddObjects1= [];
gdjs.sceneCode.GDaddObjects2= [];
gdjs.sceneCode.GDaddObjects3= [];
gdjs.sceneCode.GDaddObjects4= [];
gdjs.sceneCode.GDaddObjects5= [];
gdjs.sceneCode.GDaddObjects6= [];
gdjs.sceneCode.GDaddObjects7= [];
gdjs.sceneCode.GDaddObjects8= [];
gdjs.sceneCode.GDobj_9595name_9595giverObjects1= [];
gdjs.sceneCode.GDobj_9595name_9595giverObjects2= [];
gdjs.sceneCode.GDobj_9595name_9595giverObjects3= [];
gdjs.sceneCode.GDobj_9595name_9595giverObjects4= [];
gdjs.sceneCode.GDobj_9595name_9595giverObjects5= [];
gdjs.sceneCode.GDobj_9595name_9595giverObjects6= [];
gdjs.sceneCode.GDobj_9595name_9595giverObjects7= [];
gdjs.sceneCode.GDobj_9595name_9595giverObjects8= [];
gdjs.sceneCode.GDcreateObjects1= [];
gdjs.sceneCode.GDcreateObjects2= [];
gdjs.sceneCode.GDcreateObjects3= [];
gdjs.sceneCode.GDcreateObjects4= [];
gdjs.sceneCode.GDcreateObjects5= [];
gdjs.sceneCode.GDcreateObjects6= [];
gdjs.sceneCode.GDcreateObjects7= [];
gdjs.sceneCode.GDcreateObjects8= [];
gdjs.sceneCode.GDreObjects1= [];
gdjs.sceneCode.GDreObjects2= [];
gdjs.sceneCode.GDreObjects3= [];
gdjs.sceneCode.GDreObjects4= [];
gdjs.sceneCode.GDreObjects5= [];
gdjs.sceneCode.GDreObjects6= [];
gdjs.sceneCode.GDreObjects7= [];
gdjs.sceneCode.GDreObjects8= [];


gdjs.sceneCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


};gdjs.sceneCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{



}


};gdjs.sceneCode.mapOfEmptyGDspriteObjects = Hashtable.newFrom({"sprite": []});
gdjs.sceneCode.mapOfEmptyGDspriteObjects = Hashtable.newFrom({"sprite": []});
gdjs.sceneCode.userFunc0x11fadc0 = function GDJSInlineCode(runtimeScene, objects) {
"use strict";
if(runtimeScene.getVariables().get("loop").getAsString() === "p"){
    var c = runtimeScene.getVariables().get("c").getAsNumber()
    var e = runtimeScene.getVariables().get("line1231").getAsString()
    objects[c].getVariables().get("id").setNumber(c)
    
    //
    
    runtimeScene.getGame().getVariables().get("Script").setString(runtimeScene.getGame().getVariables().get("Script").getAsString()+e+"id = "+c+" ; "+"obj = runtimeScene.getObjects('sprite')["+c+"]"+e+ runtimeScene.getVariables().get("objects").getChildNamed(objects[c].getVariables().get("name").getAsString()).getChildNamed("script").getAsString())
    runtimeScene.getVariables().get("loop").setString("u")
    
    
     
}
//game made with MGdev 
//the javascript generated might not function as expected if it is outside this enviroment
//html5 file follows the arrangement as a gdevelop html5 file

};
gdjs.sceneCode.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("sprite"), gdjs.sceneCode.GDspriteObjects2);

var objects = [];
objects.push.apply(objects,gdjs.sceneCode.GDspriteObjects2);
gdjs.sceneCode.userFunc0x11fadc0(runtimeScene, objects);

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.sceneCode.mapOfEmptyGDspriteObjects = Hashtable.newFrom({"sprite": []});
gdjs.sceneCode.mapOfEmptyGDspriteObjects = Hashtable.newFrom({"sprite": []});
gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDspriteObjects2Objects = Hashtable.newFrom({"sprite": gdjs.sceneCode.GDspriteObjects2});
gdjs.sceneCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(gdjs.sceneCode.localVariables[0].getFromIndex(0)) == gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDspriteObjects2Objects);
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.sceneCode.GDstateObjects1, gdjs.sceneCode.GDstateObjects3);

{runtimeScene.getScene().getVariables().getFromIndex(10).setBoolean(false);
}{for(var i = 0, len = gdjs.sceneCode.GDstateObjects3.length ;i < len;++i) {
    gdjs.sceneCode.GDstateObjects3[i].getBehavior("Text").setText("just started ide");
}
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "PreviewScene", true);
}}

}


};gdjs.sceneCode.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("sprite"), gdjs.sceneCode.GDspriteObjects1);

for (gdjs.sceneCode.forEachIndex2 = 0;gdjs.sceneCode.forEachIndex2 < gdjs.sceneCode.GDspriteObjects1.length;++gdjs.sceneCode.forEachIndex2) {
gdjs.sceneCode.GDspriteObjects2.length = 0;


gdjs.sceneCode.forEachTemporary2 = gdjs.sceneCode.GDspriteObjects1[gdjs.sceneCode.forEachIndex2];
gdjs.sceneCode.GDspriteObjects2.push(gdjs.sceneCode.forEachTemporary2);
let isConditionTrue_0 = false;
if (true) {
{runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.sceneCode.localVariables[0].getFromIndex(0).getAsNumber()).getChild("name").setString(((gdjs.sceneCode.GDspriteObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.sceneCode.GDspriteObjects2[0].getVariables()).get("name").getAsString());
}{runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.sceneCode.localVariables[0].getFromIndex(0).getAsNumber()).getChild("type").setString((( gdjs.sceneCode.GDspriteObjects2.length === 0 ) ? "" :gdjs.sceneCode.GDspriteObjects2[0].getName()));
}{runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.sceneCode.localVariables[0].getFromIndex(0).getAsNumber()).getChild("x").setNumber((( gdjs.sceneCode.GDspriteObjects2.length === 0 ) ? 0 :gdjs.sceneCode.GDspriteObjects2[0].getPointX("")));
}{runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.sceneCode.localVariables[0].getFromIndex(0).getAsNumber()).getChild("y").setNumber((( gdjs.sceneCode.GDspriteObjects2.length === 0 ) ? 0 :gdjs.sceneCode.GDspriteObjects2[0].getPointY("")));
}{runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.sceneCode.localVariables[0].getFromIndex(0).getAsNumber()).getChild("width").setNumber((( gdjs.sceneCode.GDspriteObjects2.length === 0 ) ? 0 :gdjs.sceneCode.GDspriteObjects2[0].getWidth()));
}{runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.sceneCode.localVariables[0].getFromIndex(0).getAsNumber()).getChild("height").setNumber((( gdjs.sceneCode.GDspriteObjects2.length === 0 ) ? 0 :gdjs.sceneCode.GDspriteObjects2[0].getHeight()));
}{runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.sceneCode.localVariables[0].getFromIndex(0).getAsNumber()).getChild("image").setString(runtimeScene.getScene().getVariables().getFromIndex(8).getChild("images").getChild(((gdjs.sceneCode.GDspriteObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.sceneCode.GDspriteObjects2[0].getVariables()).get("name").getAsString()).getAsString());
}{gdjs.sceneCode.localVariables[0].getFromIndex(0).add(1);
}
{ //Subevents: 
gdjs.sceneCode.eventsList3(runtimeScene);} //Subevents end.
}
}

}


};gdjs.sceneCode.eventsList5 = function(runtimeScene) {

{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("count", variable);
}
gdjs.sceneCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.sceneCode.eventsList4(runtimeScene);} //End of subevents
}
gdjs.sceneCode.localVariables.pop();

}


};gdjs.sceneCode.mapOfEmptyGDspriteObjects = Hashtable.newFrom({"sprite": []});
gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDspriteObjects6Objects = Hashtable.newFrom({"sprite": gdjs.sceneCode.GDspriteObjects6});
gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDspriteObjects6Objects = Hashtable.newFrom({"sprite": gdjs.sceneCode.GDspriteObjects6});
gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDspriteObjects6Objects = Hashtable.newFrom({"sprite": gdjs.sceneCode.GDspriteObjects6});
gdjs.sceneCode.eventsList6 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(gdjs.sceneCode.localVariables[1].getFromIndex(0)) == gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDspriteObjects6Objects);
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(3).setString("h");
}}

}


};gdjs.sceneCode.eventsList7 = function(runtimeScene, asyncObjectsList) {

{


const repeatCount6 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(1));
for (let repeatIndex6 = 0;repeatIndex6 < repeatCount6;++repeatIndex6) {
gdjs.sceneCode.GDspriteObjects6.length = 0;


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDspriteObjects6Objects, runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.sceneCode.localVariables[1].getFromIndex(0).getAsNumber()).getChild("type").getAsString(), runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.sceneCode.localVariables[1].getFromIndex(0).getAsNumber()).getChild("x").getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.sceneCode.localVariables[1].getFromIndex(0).getAsNumber()).getChild("y").getAsNumber(), "");
}{for(var i = 0, len = gdjs.sceneCode.GDspriteObjects6.length ;i < len;++i) {
    gdjs.sceneCode.GDspriteObjects6[i].returnVariable(gdjs.sceneCode.GDspriteObjects6[i].getVariables().get("name")).setString(runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.sceneCode.localVariables[1].getFromIndex(0).getAsNumber()).getChild("name").getAsString());
}
}{gdjs.evtsExt__resize_image_from_url__LoadURLIntoSprite.func(runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(8).getChild("images").getChild(((gdjs.sceneCode.GDspriteObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.sceneCode.GDspriteObjects6[0].getVariables()).get("name").getAsString()).getAsString(), gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDspriteObjects6Objects, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.sceneCode.GDspriteObjects6.length ;i < len;++i) {
    gdjs.sceneCode.GDspriteObjects6[i].getBehavior("Resizable").setSize(runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.sceneCode.localVariables[1].getFromIndex(0).getAsNumber()).getChild("width").getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.sceneCode.localVariables[1].getFromIndex(0).getAsNumber()).getChild("height").getAsNumber());
}
}{gdjs.sceneCode.localVariables[1].getFromIndex(0).add(1);
}
{ //Subevents: 
gdjs.sceneCode.eventsList6(runtimeScene, asyncObjectsList);} //Subevents end.
}
}

}


};gdjs.sceneCode.userFunc0x11cd758 = function GDJSInlineCode(runtimeScene, objects) {
"use strict";
console.log(objects[0])

};
gdjs.sceneCode.eventsList8 = function(runtimeScene, asyncObjectsList) {

{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("climb", variable);
}
gdjs.sceneCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.sceneCode.eventsList7(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.sceneCode.localVariables.pop();

}


{

gdjs.copyArray(runtimeScene.getObjects("x"), gdjs.sceneCode.GDxObjects4);

var objects = [];
objects.push.apply(objects,gdjs.sceneCode.GDxObjects4);
gdjs.sceneCode.userFunc0x11cd758(runtimeScene, objects);

}


};gdjs.sceneCode.asyncCallback21679996 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.sceneCode.localVariables);

{ //Subevents
gdjs.sceneCode.eventsList8(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.sceneCode.localVariables.length = 0;
}
gdjs.sceneCode.eventsList9 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.sceneCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.sceneCode.asyncCallback21679996(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.sceneCode.asyncCallback21679644 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.sceneCode.localVariables);
{gdjs.evtTools.network.jsonToVariableStructure(gdjs.sceneCode.localVariables[0].getFromIndex(2).getAsString(), runtimeScene.getScene().getVariables().getFromIndex(1));
}
{ //Subevents
gdjs.sceneCode.eventsList9(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.sceneCode.localVariables.length = 0;
}
gdjs.sceneCode.eventsList10 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.sceneCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.sceneCode.asyncCallback21679644(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.sceneCode.asyncCallback21679252 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.sceneCode.localVariables);
{gdjs.evtTools.network.jsonToVariableStructure(gdjs.sceneCode.localVariables[0].getFromIndex(1).getAsString(), runtimeScene.getScene().getVariables().getFromIndex(8));
}
{ //Subevents
gdjs.sceneCode.eventsList10(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.sceneCode.localVariables.length = 0;
}
gdjs.sceneCode.eventsList11 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.sceneCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.sceneCode.asyncCallback21679252(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDspriteObjects1Objects = Hashtable.newFrom({"sprite": gdjs.sceneCode.GDspriteObjects1});
gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDspriteObjects2Objects = Hashtable.newFrom({"sprite": gdjs.sceneCode.GDspriteObjects2});
gdjs.sceneCode.eventsList12 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(gdjs.sceneCode.localVariables[0].getFromIndex(0)) == gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDspriteObjects2Objects);
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(3).setString("p");
}}

}


};gdjs.sceneCode.asyncCallback21707564 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.sceneCode.localVariables);

{ //Subevents
gdjs.sceneCode.eventsList12(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.sceneCode.localVariables.length = 0;
}
gdjs.sceneCode.eventsList13 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.sceneCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.3), (runtimeScene) => (gdjs.sceneCode.asyncCallback21707564(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.sceneCode.eventsList14 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("sprite"), gdjs.sceneCode.GDspriteObjects1);

for (gdjs.sceneCode.forEachIndex2 = 0;gdjs.sceneCode.forEachIndex2 < gdjs.sceneCode.GDspriteObjects1.length;++gdjs.sceneCode.forEachIndex2) {
gdjs.sceneCode.GDspriteObjects2.length = 0;


gdjs.sceneCode.forEachTemporary2 = gdjs.sceneCode.GDspriteObjects1[gdjs.sceneCode.forEachIndex2];
gdjs.sceneCode.GDspriteObjects2.push(gdjs.sceneCode.forEachTemporary2);
let isConditionTrue_0 = false;
if (true) {
{for(var i = 0, len = gdjs.sceneCode.GDspriteObjects2.length ;i < len;++i) {
    gdjs.sceneCode.GDspriteObjects2[i].getBehavior("Resizable").setSize(runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.sceneCode.localVariables[0].getFromIndex(0).getAsNumber()).getChild("width").getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.sceneCode.localVariables[0].getFromIndex(0).getAsNumber()).getChild("height").getAsNumber());
}
}{gdjs.sceneCode.localVariables[0].getFromIndex(0).add(1);
}
{ //Subevents: 
gdjs.sceneCode.eventsList13(runtimeScene);} //Subevents end.
}
}

}


};gdjs.sceneCode.eventsList15 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("state"), gdjs.sceneCode.GDstateObjects4);
{gdjs.evtTools.storage.writeStringInJSONFile("MGDproject", "ObjInstaceData", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(1)));
}{for(var i = 0, len = gdjs.sceneCode.GDstateObjects4.length ;i < len;++i) {
    gdjs.sceneCode.GDstateObjects4[i].getBehavior("Text").setText("saving...");
}
}}

}


};gdjs.sceneCode.eventsList16 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("sprite"), gdjs.sceneCode.GDspriteObjects2);

for (gdjs.sceneCode.forEachIndex3 = 0;gdjs.sceneCode.forEachIndex3 < gdjs.sceneCode.GDspriteObjects2.length;++gdjs.sceneCode.forEachIndex3) {
gdjs.sceneCode.GDspriteObjects3.length = 0;


gdjs.sceneCode.forEachTemporary3 = gdjs.sceneCode.GDspriteObjects2[gdjs.sceneCode.forEachIndex3];
gdjs.sceneCode.GDspriteObjects3.push(gdjs.sceneCode.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {
{runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.sceneCode.localVariables[0].getFromIndex(0).getAsNumber()).getChild("name").setString(((gdjs.sceneCode.GDspriteObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.sceneCode.GDspriteObjects3[0].getVariables()).get("name").getAsString());
}{runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.sceneCode.localVariables[0].getFromIndex(0).getAsNumber()).getChild("type").setString((( gdjs.sceneCode.GDspriteObjects3.length === 0 ) ? "" :gdjs.sceneCode.GDspriteObjects3[0].getName()));
}{runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.sceneCode.localVariables[0].getFromIndex(0).getAsNumber()).getChild("x").setNumber((( gdjs.sceneCode.GDspriteObjects3.length === 0 ) ? 0 :gdjs.sceneCode.GDspriteObjects3[0].getPointX("")));
}{runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.sceneCode.localVariables[0].getFromIndex(0).getAsNumber()).getChild("y").setNumber((( gdjs.sceneCode.GDspriteObjects3.length === 0 ) ? 0 :gdjs.sceneCode.GDspriteObjects3[0].getPointY("")));
}{runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.sceneCode.localVariables[0].getFromIndex(0).getAsNumber()).getChild("width").setNumber((( gdjs.sceneCode.GDspriteObjects3.length === 0 ) ? 0 :gdjs.sceneCode.GDspriteObjects3[0].getWidth()));
}{runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.sceneCode.localVariables[0].getFromIndex(0).getAsNumber()).getChild("height").setNumber((( gdjs.sceneCode.GDspriteObjects3.length === 0 ) ? 0 :gdjs.sceneCode.GDspriteObjects3[0].getHeight()));
}{gdjs.sceneCode.localVariables[0].getFromIndex(0).add(1);
}
{ //Subevents: 
gdjs.sceneCode.eventsList15(runtimeScene);} //Subevents end.
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("state"), gdjs.sceneCode.GDstateObjects1);
{for(var i = 0, len = gdjs.sceneCode.GDstateObjects1.length ;i < len;++i) {
    gdjs.sceneCode.GDstateObjects1[i].getBehavior("Text").setText("saved");
}
}}

}


};gdjs.sceneCode.eventsList17 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{runtimeScene.getScene().getVariables().getFromIndex(0).getChild(runtimeScene.getGame().getVariables().getFromIndex(4).getAsString()).getChild("script").setString(runtimeScene.getGame().getVariables().getFromIndex(5).getAsString());
}}

}


{



}


{



}


};gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDspriteObjects2Objects = Hashtable.newFrom({"sprite": gdjs.sceneCode.GDspriteObjects2});
gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDspriteObjects2Objects = Hashtable.newFrom({"sprite": gdjs.sceneCode.GDspriteObjects2});
gdjs.sceneCode.eventsList18 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("sprite"), gdjs.sceneCode.GDspriteObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDspriteObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("height"), gdjs.sceneCode.GDheightObjects2);
gdjs.copyArray(runtimeScene.getObjects("objectName2"), gdjs.sceneCode.GDobjectName2Objects2);
/* Reuse gdjs.sceneCode.GDspriteObjects2 */
gdjs.copyArray(runtimeScene.getObjects("width"), gdjs.sceneCode.GDwidthObjects2);
gdjs.copyArray(runtimeScene.getObjects("x"), gdjs.sceneCode.GDxObjects2);
gdjs.copyArray(runtimeScene.getObjects("y"), gdjs.sceneCode.GDyObjects2);
{gdjs.sceneCode.localVariables[0].getFromIndex(0).setString(((gdjs.sceneCode.GDspriteObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.sceneCode.GDspriteObjects2[0].getVariables()).get("name").getAsString());
}{for(var i = 0, len = gdjs.sceneCode.GDobjectName2Objects2.length ;i < len;++i) {
    gdjs.sceneCode.GDobjectName2Objects2[i].getBehavior("Text").setText(gdjs.sceneCode.localVariables[0].getFromIndex(0).getAsString());
}
}{for(var i = 0, len = gdjs.sceneCode.GDwidthObjects2.length ;i < len;++i) {
    gdjs.sceneCode.GDwidthObjects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString((( gdjs.sceneCode.GDspriteObjects2.length === 0 ) ? 0 :gdjs.sceneCode.GDspriteObjects2[0].getWidth())));
}
}{for(var i = 0, len = gdjs.sceneCode.GDheightObjects2.length ;i < len;++i) {
    gdjs.sceneCode.GDheightObjects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString((( gdjs.sceneCode.GDspriteObjects2.length === 0 ) ? 0 :gdjs.sceneCode.GDspriteObjects2[0].getHeight())));
}
}{for(var i = 0, len = gdjs.sceneCode.GDyObjects2.length ;i < len;++i) {
    gdjs.sceneCode.GDyObjects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString((( gdjs.sceneCode.GDspriteObjects2.length === 0 ) ? 0 :gdjs.sceneCode.GDspriteObjects2[0].getPointY(""))));
}
}{for(var i = 0, len = gdjs.sceneCode.GDxObjects2.length ;i < len;++i) {
    gdjs.sceneCode.GDxObjects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString((( gdjs.sceneCode.GDspriteObjects2.length === 0 ) ? 0 :gdjs.sceneCode.GDspriteObjects2[0].getPointX(""))));
}
}{for(var i = 0, len = gdjs.sceneCode.GDobjectName2Objects2.length ;i < len;++i) {
    gdjs.sceneCode.GDobjectName2Objects2[i].setColor("255;255;255");
}
}{runtimeScene.getScene().getVariables().getFromIndex(13).add(1);
}{for(var i = 0, len = gdjs.sceneCode.GDspriteObjects2.length ;i < len;++i) {
    gdjs.sceneCode.GDspriteObjects2[i].returnVariable(gdjs.sceneCode.GDspriteObjects2[i].getVariables().get("id")).setNumber(runtimeScene.getScene().getVariables().getFromIndex(13).getAsNumber());
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("sprite"), gdjs.sceneCode.GDspriteObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDspriteObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
/* Reuse gdjs.sceneCode.GDspriteObjects2 */
{for(var i = 0, len = gdjs.sceneCode.GDspriteObjects2.length ;i < len;++i) {
    gdjs.sceneCode.GDspriteObjects2[i].returnVariable(gdjs.sceneCode.GDspriteObjects2[i].getVariables().get("id")).setNumber(0);
}
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.sceneCode.eventsList19 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.sceneCode.GDspriteObjects3, gdjs.sceneCode.GDspriteObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.sceneCode.GDspriteObjects4.length;i<l;++i) {
    if ( gdjs.sceneCode.GDspriteObjects4[i].getBehavior("Resizable").getHeight() < 4 ) {
        isConditionTrue_0 = true;
        gdjs.sceneCode.GDspriteObjects4[k] = gdjs.sceneCode.GDspriteObjects4[i];
        ++k;
    }
}
gdjs.sceneCode.GDspriteObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.sceneCode.GDspriteObjects4 */
{for(var i = 0, len = gdjs.sceneCode.GDspriteObjects4.length ;i < len;++i) {
    gdjs.sceneCode.GDspriteObjects4[i].getBehavior("Resizable").setHeight(4);
}
}}

}


{

/* Reuse gdjs.sceneCode.GDspriteObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.sceneCode.GDspriteObjects3.length;i<l;++i) {
    if ( gdjs.sceneCode.GDspriteObjects3[i].getBehavior("Resizable").getWidth() < 4 ) {
        isConditionTrue_0 = true;
        gdjs.sceneCode.GDspriteObjects3[k] = gdjs.sceneCode.GDspriteObjects3[i];
        ++k;
    }
}
gdjs.sceneCode.GDspriteObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.sceneCode.GDspriteObjects3 */
{for(var i = 0, len = gdjs.sceneCode.GDspriteObjects3.length ;i < len;++i) {
    gdjs.sceneCode.GDspriteObjects3[i].getBehavior("Resizable").setWidth(4);
}
}}

}


};gdjs.sceneCode.eventsList20 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.sceneCode.GDspriteObjects2, gdjs.sceneCode.GDspriteObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.sceneCode.GDspriteObjects3.length;i<l;++i) {
    if ( gdjs.sceneCode.GDspriteObjects3[i].getVariableNumber(gdjs.sceneCode.GDspriteObjects3[i].getVariables().getFromIndex(0)) == runtimeScene.getScene().getVariables().getFromIndex(13).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.sceneCode.GDspriteObjects3[k] = gdjs.sceneCode.GDspriteObjects3[i];
        ++k;
    }
}
gdjs.sceneCode.GDspriteObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("height"), gdjs.sceneCode.GDheightObjects3);
gdjs.copyArray(runtimeScene.getObjects("objectName2"), gdjs.sceneCode.GDobjectName2Objects3);
/* Reuse gdjs.sceneCode.GDspriteObjects3 */
gdjs.copyArray(runtimeScene.getObjects("width"), gdjs.sceneCode.GDwidthObjects3);
gdjs.copyArray(runtimeScene.getObjects("x"), gdjs.sceneCode.GDxObjects3);
gdjs.copyArray(runtimeScene.getObjects("y"), gdjs.sceneCode.GDyObjects3);
{for(var i = 0, len = gdjs.sceneCode.GDspriteObjects3.length ;i < len;++i) {
    gdjs.sceneCode.GDspriteObjects3[i].setX(gdjs.evtTools.common.toNumber((( gdjs.sceneCode.GDxObjects3.length === 0 ) ? "" :gdjs.sceneCode.GDxObjects3[0].getBehavior("Text").getText())));
}
}{for(var i = 0, len = gdjs.sceneCode.GDspriteObjects3.length ;i < len;++i) {
    gdjs.sceneCode.GDspriteObjects3[i].setY(gdjs.evtTools.common.toNumber((( gdjs.sceneCode.GDyObjects3.length === 0 ) ? "" :gdjs.sceneCode.GDyObjects3[0].getBehavior("Text").getText())));
}
}{for(var i = 0, len = gdjs.sceneCode.GDspriteObjects3.length ;i < len;++i) {
    gdjs.sceneCode.GDspriteObjects3[i].getBehavior("Resizable").setWidth(gdjs.evtTools.common.toNumber((( gdjs.sceneCode.GDwidthObjects3.length === 0 ) ? "" :gdjs.sceneCode.GDwidthObjects3[0].getBehavior("Text").getText())));
}
}{for(var i = 0, len = gdjs.sceneCode.GDspriteObjects3.length ;i < len;++i) {
    gdjs.sceneCode.GDspriteObjects3[i].getBehavior("Resizable").setHeight(gdjs.evtTools.common.toNumber((( gdjs.sceneCode.GDheightObjects3.length === 0 ) ? "" :gdjs.sceneCode.GDheightObjects3[0].getBehavior("Text").getText())));
}
}{for(var i = 0, len = gdjs.sceneCode.GDobjectName2Objects3.length ;i < len;++i) {
    gdjs.sceneCode.GDobjectName2Objects3[i].getBehavior("Text").setText(((gdjs.sceneCode.GDspriteObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.sceneCode.GDspriteObjects3[0].getVariables()).get("name").getAsString());
}
}
{ //Subevents
gdjs.sceneCode.eventsList19(runtimeScene);} //End of subevents
}

}


};gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDobjectNameObjects1Objects = Hashtable.newFrom({"objectName": gdjs.sceneCode.GDobjectNameObjects1});
gdjs.sceneCode.eventsList21 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "ide");
}}

}


};gdjs.sceneCode.mapOfEmptyGDspriteObjects = Hashtable.newFrom({"sprite": []});
gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDaddObjects1Objects = Hashtable.newFrom({"add": gdjs.sceneCode.GDaddObjects1});
gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDspriteObjects1Objects = Hashtable.newFrom({"sprite": gdjs.sceneCode.GDspriteObjects1});
gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDobjectNameObjects1Objects = Hashtable.newFrom({"objectName": gdjs.sceneCode.GDobjectNameObjects1});
gdjs.sceneCode.eventsList22 = function(runtimeScene) {

};gdjs.sceneCode.eventsList23 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("sprite"), gdjs.sceneCode.GDspriteObjects2);

for (gdjs.sceneCode.forEachIndex3 = 0;gdjs.sceneCode.forEachIndex3 < gdjs.sceneCode.GDspriteObjects2.length;++gdjs.sceneCode.forEachIndex3) {
gdjs.copyArray(gdjs.sceneCode.GDobjectNameObjects1, gdjs.sceneCode.GDobjectNameObjects3);

gdjs.sceneCode.GDspriteObjects3.length = 0;


gdjs.sceneCode.forEachTemporary3 = gdjs.sceneCode.GDspriteObjects2[gdjs.sceneCode.forEachIndex3];
gdjs.sceneCode.GDspriteObjects3.push(gdjs.sceneCode.forEachTemporary3);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.sceneCode.GDspriteObjects3.length;i<l;++i) {
    if ( gdjs.sceneCode.GDspriteObjects3[i].getVariableString(gdjs.sceneCode.GDspriteObjects3[i].getVariables().get("name")) == (( gdjs.sceneCode.GDobjectNameObjects3.length === 0 ) ? "" :gdjs.sceneCode.GDobjectNameObjects3[0].getBehavior("Text").getText()) ) {
        isConditionTrue_0 = true;
        gdjs.sceneCode.GDspriteObjects3[k] = gdjs.sceneCode.GDspriteObjects3[i];
        ++k;
    }
}
gdjs.sceneCode.GDspriteObjects3.length = k;
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.sceneCode.GDspriteObjects3.length ;i < len;++i) {
    gdjs.sceneCode.GDspriteObjects3[i].deleteFromScene(runtimeScene);
}
}}
}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.camera.hideLayer(runtimeScene, "co");
}}

}


};gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDcreateObjects1Objects = Hashtable.newFrom({"create": gdjs.sceneCode.GDcreateObjects1});
gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDreObjects1Objects = Hashtable.newFrom({"re": gdjs.sceneCode.GDreObjects1});
gdjs.sceneCode.eventsList24 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.camera.hideLayer(runtimeScene, "co");
}}

}


};gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDcreateObjects1Objects = Hashtable.newFrom({"create": gdjs.sceneCode.GDcreateObjects1});
gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDreObjects1Objects = Hashtable.newFrom({"re": gdjs.sceneCode.GDreObjects1});
gdjs.sceneCode.eventsList25 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.camera.hideLayer(runtimeScene, "co");
}}

}


};gdjs.sceneCode.mapOfEmptyGDdragNdropObjects = Hashtable.newFrom({"dragNdrop": []});
gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDspriteObjects1Objects = Hashtable.newFrom({"sprite": gdjs.sceneCode.GDspriteObjects1});
gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDspriteObjects1Objects = Hashtable.newFrom({"sprite": gdjs.sceneCode.GDspriteObjects1});
gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDobjectNameObjects1Objects = Hashtable.newFrom({"objectName": gdjs.sceneCode.GDobjectNameObjects1});
gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDdragNdropObjects1Objects = Hashtable.newFrom({"dragNdrop": gdjs.sceneCode.GDdragNdropObjects1});
gdjs.sceneCode.userFunc0x9ba498 = function GDJSInlineCode(runtimeScene) {
"use strict";
const ar = []
for (let childName in runtimeScene.getVariables().get("objects").getAllChildren()){
    ar.push(childName)
}
runtimeScene.getVariables().get("list").fromJSON(JSON.stringify(ar))
console.log(ar)
};
gdjs.sceneCode.eventsList26 = function(runtimeScene) {

{


gdjs.sceneCode.userFunc0x9ba498(runtimeScene);

}


};gdjs.sceneCode.mapOfEmptyGDobjectNameObjects = Hashtable.newFrom({"objectName": []});
gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDobjectNameObjects2Objects = Hashtable.newFrom({"objectName": gdjs.sceneCode.GDobjectNameObjects2});
gdjs.sceneCode.eventsList27 = function(runtimeScene) {

};gdjs.sceneCode.eventsList28 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{


const repeatCount2 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(2));
for (let repeatIndex2 = 0;repeatIndex2 < repeatCount2;++repeatIndex2) {
gdjs.copyArray(gdjs.sceneCode.GDobjectNameObjects1, gdjs.sceneCode.GDobjectNameObjects2);


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDobjectNameObjects2Objects, 1080, gdjs.sceneCode.localVariables[0].getFromIndex(0).getAsNumber(), "object_select");
}{for(var i = 0, len = gdjs.sceneCode.GDobjectNameObjects2.length ;i < len;++i) {
    gdjs.sceneCode.GDobjectNameObjects2[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(2).getChild(gdjs.sceneCode.localVariables[0].getFromIndex(1).getAsNumber()).getAsString());
}
}{gdjs.sceneCode.localVariables[0].getFromIndex(1).add(1);
}{gdjs.sceneCode.localVariables[0].getFromIndex(0).add(32);
}}
}

}


};gdjs.sceneCode.eventsList29 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "a");
if (isConditionTrue_0) {
{gdjs.fileSystem.makeDirectory(gdjs.fileSystem.getDesktopPath(runtimeScene) + gdjs.fileSystem.getPathDelimiter() + "hack", gdjs.VariablesContainer.badVariable);
}
{ //Subevents
gdjs.sceneCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "c");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(10), false, false);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(10).setBoolean(true);
}{runtimeScene.getScene().getVariables().getFromIndex(5).setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(0).setString("//game made with MGdev \n//the javascript generated might not function as expected if it is outside this enviroment\n//html5 file follows the arrangement as a gdevelop html5 file\nlet obj = runtimeScene.getObjects('sprite')\nvar id = 0");
}
{ //Subevents
gdjs.sceneCode.eventsList1(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(5)) < gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.sceneCode.mapOfEmptyGDspriteObjects);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(5)) != -(1);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(10), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.sceneCode.mapOfEmptyGDspriteObjects) > 0;
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("state"), gdjs.sceneCode.GDstateObjects1);
{for(var i = 0, len = gdjs.sceneCode.GDstateObjects1.length ;i < len;++i) {
    gdjs.sceneCode.GDstateObjects1[i].getBehavior("Text").setText("collecting code....");
}
}
{ //Subevents
gdjs.sceneCode.eventsList2(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(5)) == gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.sceneCode.mapOfEmptyGDspriteObjects);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(10), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.sceneCode.mapOfEmptyGDspriteObjects) > 0;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("state"), gdjs.sceneCode.GDstateObjects1);
{for(var i = 0, len = gdjs.sceneCode.GDstateObjects1.length ;i < len;++i) {
    gdjs.sceneCode.GDstateObjects1[i].getBehavior("Text").setText("collecting object position....");
}
}{gdjs.evtTools.variable.variableClearChildren(runtimeScene.getGame().getVariables().getFromIndex(1));
}
{ //Subevents
gdjs.sceneCode.eventsList5(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(5)) > gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.sceneCode.mapOfEmptyGDspriteObjects);
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(10).setBoolean(false);
}{runtimeScene.getScene().getVariables().getFromIndex(5).setNumber(0);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(3)) == "u";
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(6), false, false);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(6).setBoolean(true);
}{runtimeScene.getScene().getVariables().getFromIndex(5).add(1);
}{runtimeScene.getScene().getVariables().getFromIndex(3).setString("p");
}{runtimeScene.getScene().getVariables().getFromIndex(6).setBoolean(false);
}}

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setString("");
variables._declare("Ojson", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("");
variables._declare("Rjson", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("");
variables._declare("TOjsom", variable);
}
gdjs.sceneCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readStringFromJSONFile("MGDproject", "object", runtimeScene, gdjs.sceneCode.localVariables[0].getFromIndex(0));
}{gdjs.evtTools.storage.readStringFromJSONFile("MGDproject", "resources", runtimeScene, gdjs.sceneCode.localVariables[0].getFromIndex(1));
}{gdjs.evtTools.storage.readStringFromJSONFile("MGDproject", "ObjInstaceData", runtimeScene, gdjs.sceneCode.localVariables[0].getFromIndex(2));
}{gdjs.evtTools.network.jsonToVariableStructure(gdjs.sceneCode.localVariables[0].getFromIndex(0).getAsString(), runtimeScene.getScene().getVariables().getFromIndex(0));
}
{ //Subevents
gdjs.sceneCode.eventsList11(runtimeScene);} //End of subevents
}
gdjs.sceneCode.localVariables.pop();

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("debug"), gdjs.sceneCode.GDdebugObjects1);
gdjs.copyArray(runtimeScene.getObjects("sprite"), gdjs.sceneCode.GDspriteObjects1);
{for(var i = 0, len = gdjs.sceneCode.GDdebugObjects1.length ;i < len;++i) {
    gdjs.sceneCode.GDdebugObjects1[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(3).getAsString() + gdjs.evtTools.string.newLine() + runtimeScene.getScene().getVariables().getFromIndex(5).getAsString() + gdjs.evtTools.string.newLine() + ((gdjs.sceneCode.GDspriteObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.sceneCode.GDspriteObjects1[0].getVariables()).getFromIndex(0).getAsString() + " instance of sprites: " + gdjs.evtTools.common.toString(gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDspriteObjects1Objects)));
}
}}

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("climb", variable);
}
gdjs.sceneCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(3)) == "h";
if (isConditionTrue_0) {
{gdjs.sceneCode.localVariables[0].getFromIndex(0).setNumber(0);
}
{ //Subevents
gdjs.sceneCode.eventsList14(runtimeScene);} //End of subevents
}
gdjs.sceneCode.localVariables.pop();

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("climb", variable);
}
gdjs.sceneCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LControl");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
}
if (isConditionTrue_0) {
{gdjs.evtTools.storage.writeStringInJSONFile("MGDproject", "object", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(0)));
}{gdjs.evtTools.storage.writeStringInJSONFile("MGDproject", "resources", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(8)));
}{gdjs.evtTools.variable.variableClearChildren(runtimeScene.getScene().getVariables().getFromIndex(1));
}
{ //Subevents
gdjs.sceneCode.eventsList16(runtimeScene);} //End of subevents
}
gdjs.sceneCode.localVariables.pop();

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustResumed(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.sceneCode.eventsList17(runtimeScene);} //End of subevents
}

}


{



}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setString("0");
variables._declare("objN", variable);
}
gdjs.sceneCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.sceneCode.eventsList18(runtimeScene);} //End of subevents
}
gdjs.sceneCode.localVariables.pop();

}


{

gdjs.copyArray(runtimeScene.getObjects("sprite"), gdjs.sceneCode.GDspriteObjects1);

for (gdjs.sceneCode.forEachIndex2 = 0;gdjs.sceneCode.forEachIndex2 < gdjs.sceneCode.GDspriteObjects1.length;++gdjs.sceneCode.forEachIndex2) {
gdjs.sceneCode.GDspriteObjects2.length = 0;


gdjs.sceneCode.forEachTemporary2 = gdjs.sceneCode.GDspriteObjects1[gdjs.sceneCode.forEachIndex2];
gdjs.sceneCode.GDspriteObjects2.push(gdjs.sceneCode.forEachTemporary2);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.sceneCode.eventsList20(runtimeScene);} //Subevents end.
}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("objectName"), gdjs.sceneCode.GDobjectNameObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDobjectNameObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "s");
}
if (isConditionTrue_0) {
/* Reuse gdjs.sceneCode.GDobjectNameObjects1 */
{runtimeScene.getGame().getVariables().getFromIndex(4).setString((( gdjs.sceneCode.GDobjectNameObjects1.length === 0 ) ? "" :gdjs.sceneCode.GDobjectNameObjects1[0].getBehavior("Text").getText()));
}{runtimeScene.getGame().getVariables().getFromIndex(3).setString(runtimeScene.getScene().getVariables().getFromIndex(0).getChild((( gdjs.sceneCode.GDobjectNameObjects1.length === 0 ) ? "" :gdjs.sceneCode.GDobjectNameObjects1[0].getBehavior("Text").getText())).getChild("script").getAsString());
}{runtimeScene.getGame().getVariables().getFromIndex(5).setString("");
}
{ //Subevents
gdjs.sceneCode.eventsList21(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("obj_scp"), gdjs.sceneCode.GDobj_9595scpObjects1);
{for(var i = 0, len = gdjs.sceneCode.GDobj_9595scpObjects1.length ;i < len;++i) {
    gdjs.sceneCode.GDobj_9595scpObjects1[i].getBehavior("Resizable").setHeight((gdjs.evtsExt__InputValidation__CountNewLines.func(runtimeScene, (gdjs.sceneCode.GDobj_9595scpObjects1[i].getBehavior("Text").getText()), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) * 23) + 23);
}
}{runtimeScene.getScene().getVariables().getFromIndex(11).setNumber(gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.sceneCode.mapOfEmptyGDspriteObjects) - 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("add"), gdjs.sceneCode.GDaddObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDaddObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "co");
}{runtimeScene.getScene().getVariables().getFromIndex(7).setString(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(4)));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("sprite"), gdjs.sceneCode.GDspriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDspriteObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22048340);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.sceneCode.GDspriteObjects1 */
{for(var i = 0, len = gdjs.sceneCode.GDspriteObjects1.length ;i < len;++i) {
    gdjs.sceneCode.GDspriteObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("objectName"), gdjs.sceneCode.GDobjectNameObjects1);

{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setString("\"");
variables._declare("json1", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("");
variables._declare("name", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("\":{\"animated\":false,\"animation\":[],\"image\":0,\"name\":\"sprite\",\"script\":\"0\"}}");
variables._declare("json2", variable);
}
gdjs.sceneCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDobjectNameObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(15), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22049564);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.sceneCode.GDobjectNameObjects1 */
{gdjs.evtTools.variable.variableRemoveChild(runtimeScene.getScene().getVariables().getFromIndex(0), (( gdjs.sceneCode.GDobjectNameObjects1.length === 0 ) ? "" :gdjs.sceneCode.GDobjectNameObjects1[0].getBehavior("Text").getText()));
}
{ //Subevents
gdjs.sceneCode.eventsList23(runtimeScene);} //End of subevents
}
gdjs.sceneCode.localVariables.pop();

}


{

gdjs.copyArray(runtimeScene.getObjects("create"), gdjs.sceneCode.GDcreateObjects1);

{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setString("\"");
variables._declare("json1", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("");
variables._declare("name", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("\":{\"animated\":false,\"animation\":[],\"image\":0,\"name\":\"sprite\",\"script\":\"0\"}}");
variables._declare("json2", variable);
}
gdjs.sceneCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "co");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDcreateObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(15), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(0)) > 0;
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("obj_name_giver"), gdjs.sceneCode.GDobj_9595name_9595giverObjects1);
gdjs.copyArray(runtimeScene.getObjects("re"), gdjs.sceneCode.GDreObjects1);
{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.string.subStr(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(0)), 0, gdjs.evtTools.string.strLen(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(0))) - 1) + "," + gdjs.sceneCode.localVariables[0].getFromIndex(0).getAsString() + (( gdjs.sceneCode.GDobj_9595name_9595giverObjects1.length === 0 ) ? "" :gdjs.sceneCode.GDobj_9595name_9595giverObjects1[0].getBehavior("Text").getText()) + gdjs.sceneCode.localVariables[0].getFromIndex(2).getAsString(), runtimeScene.getScene().getVariables().getFromIndex(0));
}{gdjs.evtsExt__UploadDownloadImageFile__UploadImageFile.func(runtimeScene, gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDreObjects1Objects, false, runtimeScene.getScene().getVariables().getFromIndex(8).getChild("images").getChild((( gdjs.sceneCode.GDobj_9595name_9595giverObjects1.length === 0 ) ? "" :gdjs.sceneCode.GDobj_9595name_9595giverObjects1[0].getBehavior("Text").getText())), gdjs.VariablesContainer.badVariable, gdjs.VariablesContainer.badVariable, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.sceneCode.eventsList24(runtimeScene);} //End of subevents
}
gdjs.sceneCode.localVariables.pop();

}


{

gdjs.copyArray(runtimeScene.getObjects("create"), gdjs.sceneCode.GDcreateObjects1);

{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setString("\"");
variables._declare("json1", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("");
variables._declare("name", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("\":{\"animated\":false,\"animation\":[],\"image\":0,\"name\":\"sprite\",\"script\":\"0\"}}");
variables._declare("json2", variable);
}
gdjs.sceneCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "co");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDcreateObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(15), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(0)) == 0;
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("obj_name_giver"), gdjs.sceneCode.GDobj_9595name_9595giverObjects1);
gdjs.copyArray(runtimeScene.getObjects("re"), gdjs.sceneCode.GDreObjects1);
{gdjs.evtTools.network.jsonToVariableStructure("{" + gdjs.sceneCode.localVariables[0].getFromIndex(0).getAsString() + (( gdjs.sceneCode.GDobj_9595name_9595giverObjects1.length === 0 ) ? "" :gdjs.sceneCode.GDobj_9595name_9595giverObjects1[0].getBehavior("Text").getText()) + gdjs.sceneCode.localVariables[0].getFromIndex(2).getAsString(), runtimeScene.getScene().getVariables().getFromIndex(0));
}{gdjs.evtsExt__UploadDownloadImageFile__UploadImageFile.func(runtimeScene, gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDreObjects1Objects, false, runtimeScene.getScene().getVariables().getFromIndex(8).getChild("images").getChild((( gdjs.sceneCode.GDobj_9595name_9595giverObjects1.length === 0 ) ? "" :gdjs.sceneCode.GDobj_9595name_9595giverObjects1[0].getBehavior("Text").getText())), gdjs.VariablesContainer.badVariable, gdjs.VariablesContainer.badVariable, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.sceneCode.eventsList25(runtimeScene);} //End of subevents
}
gdjs.sceneCode.localVariables.pop();

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setString("0");
variables._declare("cn", variable);
}
gdjs.sceneCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{
}
gdjs.sceneCode.localVariables.pop();

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("dragNdrop"), gdjs.sceneCode.GDdragNdropObjects1);
{for(var i = 0, len = gdjs.sceneCode.GDdragNdropObjects1.length ;i < len;++i) {
    gdjs.sceneCode.GDdragNdropObjects1[i].setPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0),gdjs.evtTools.input.getCursorY(runtimeScene, "", 0));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.sceneCode.mapOfEmptyGDdragNdropObjects) > 0;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("dragNdrop"), gdjs.sceneCode.GDdragNdropObjects1);
gdjs.sceneCode.GDspriteObjects1.length = 0;

{for(var i = 0, len = gdjs.sceneCode.GDdragNdropObjects1.length ;i < len;++i) {
    gdjs.sceneCode.GDdragNdropObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDspriteObjects1Objects, gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), "");
}{for(var i = 0, len = gdjs.sceneCode.GDspriteObjects1.length ;i < len;++i) {
    gdjs.sceneCode.GDspriteObjects1[i].returnVariable(gdjs.sceneCode.GDspriteObjects1[i].getVariables().getFromIndex(1)).setString(runtimeScene.getScene().getVariables().getFromIndex(16).getAsString());
}
}{gdjs.evtsExt__resize_image_from_url__LoadURLIntoSprite.func(runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(8).getChild("images").getChild(((gdjs.sceneCode.GDspriteObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.sceneCode.GDspriteObjects1[0].getVariables()).get("name").getAsString()).getAsString(), gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDspriteObjects1Objects, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("objectName"), gdjs.sceneCode.GDobjectNameObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDobjectNameObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22062732);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.sceneCode.GDobjectNameObjects1 */
gdjs.sceneCode.GDdragNdropObjects1.length = 0;

{runtimeScene.getScene().getVariables().getFromIndex(16).setString((( gdjs.sceneCode.GDobjectNameObjects1.length === 0 ) ? "" :gdjs.sceneCode.GDobjectNameObjects1[0].getBehavior("Text").getText()));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.sceneCode.mapOfGDgdjs_9546sceneCode_9546GDdragNdropObjects1Objects, gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), "");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(0)) != gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(2));
if (isConditionTrue_0) {

{ //Subevents
gdjs.sceneCode.eventsList26(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + (1), "", 0);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - (1), "", 0);
}}

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(50);
variables._declare("count", variable);
}
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("climb", variable);
}
gdjs.sceneCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(2)) != gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.sceneCode.mapOfEmptyGDobjectNameObjects);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("objectName"), gdjs.sceneCode.GDobjectNameObjects1);
{for(var i = 0, len = gdjs.sceneCode.GDobjectNameObjects1.length ;i < len;++i) {
    gdjs.sceneCode.GDobjectNameObjects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.sceneCode.eventsList28(runtimeScene);} //End of subevents
}
gdjs.sceneCode.localVariables.pop();

}


};

gdjs.sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.sceneCode.GDspriteObjects1.length = 0;
gdjs.sceneCode.GDspriteObjects2.length = 0;
gdjs.sceneCode.GDspriteObjects3.length = 0;
gdjs.sceneCode.GDspriteObjects4.length = 0;
gdjs.sceneCode.GDspriteObjects5.length = 0;
gdjs.sceneCode.GDspriteObjects6.length = 0;
gdjs.sceneCode.GDspriteObjects7.length = 0;
gdjs.sceneCode.GDspriteObjects8.length = 0;
gdjs.sceneCode.GDdebugObjects1.length = 0;
gdjs.sceneCode.GDdebugObjects2.length = 0;
gdjs.sceneCode.GDdebugObjects3.length = 0;
gdjs.sceneCode.GDdebugObjects4.length = 0;
gdjs.sceneCode.GDdebugObjects5.length = 0;
gdjs.sceneCode.GDdebugObjects6.length = 0;
gdjs.sceneCode.GDdebugObjects7.length = 0;
gdjs.sceneCode.GDdebugObjects8.length = 0;
gdjs.sceneCode.GDdialougObjects1.length = 0;
gdjs.sceneCode.GDdialougObjects2.length = 0;
gdjs.sceneCode.GDdialougObjects3.length = 0;
gdjs.sceneCode.GDdialougObjects4.length = 0;
gdjs.sceneCode.GDdialougObjects5.length = 0;
gdjs.sceneCode.GDdialougObjects6.length = 0;
gdjs.sceneCode.GDdialougObjects7.length = 0;
gdjs.sceneCode.GDdialougObjects8.length = 0;
gdjs.sceneCode.GDobject_9595var_9595inputObjects1.length = 0;
gdjs.sceneCode.GDobject_9595var_9595inputObjects2.length = 0;
gdjs.sceneCode.GDobject_9595var_9595inputObjects3.length = 0;
gdjs.sceneCode.GDobject_9595var_9595inputObjects4.length = 0;
gdjs.sceneCode.GDobject_9595var_9595inputObjects5.length = 0;
gdjs.sceneCode.GDobject_9595var_9595inputObjects6.length = 0;
gdjs.sceneCode.GDobject_9595var_9595inputObjects7.length = 0;
gdjs.sceneCode.GDobject_9595var_9595inputObjects8.length = 0;
gdjs.sceneCode.GDobjectNamesObjects1.length = 0;
gdjs.sceneCode.GDobjectNamesObjects2.length = 0;
gdjs.sceneCode.GDobjectNamesObjects3.length = 0;
gdjs.sceneCode.GDobjectNamesObjects4.length = 0;
gdjs.sceneCode.GDobjectNamesObjects5.length = 0;
gdjs.sceneCode.GDobjectNamesObjects6.length = 0;
gdjs.sceneCode.GDobjectNamesObjects7.length = 0;
gdjs.sceneCode.GDobjectNamesObjects8.length = 0;
gdjs.sceneCode.GDobjectNameObjects1.length = 0;
gdjs.sceneCode.GDobjectNameObjects2.length = 0;
gdjs.sceneCode.GDobjectNameObjects3.length = 0;
gdjs.sceneCode.GDobjectNameObjects4.length = 0;
gdjs.sceneCode.GDobjectNameObjects5.length = 0;
gdjs.sceneCode.GDobjectNameObjects6.length = 0;
gdjs.sceneCode.GDobjectNameObjects7.length = 0;
gdjs.sceneCode.GDobjectNameObjects8.length = 0;
gdjs.sceneCode.GDdragNdropObjects1.length = 0;
gdjs.sceneCode.GDdragNdropObjects2.length = 0;
gdjs.sceneCode.GDdragNdropObjects3.length = 0;
gdjs.sceneCode.GDdragNdropObjects4.length = 0;
gdjs.sceneCode.GDdragNdropObjects5.length = 0;
gdjs.sceneCode.GDdragNdropObjects6.length = 0;
gdjs.sceneCode.GDdragNdropObjects7.length = 0;
gdjs.sceneCode.GDdragNdropObjects8.length = 0;
gdjs.sceneCode.GDobj_9595scpObjects1.length = 0;
gdjs.sceneCode.GDobj_9595scpObjects2.length = 0;
gdjs.sceneCode.GDobj_9595scpObjects3.length = 0;
gdjs.sceneCode.GDobj_9595scpObjects4.length = 0;
gdjs.sceneCode.GDobj_9595scpObjects5.length = 0;
gdjs.sceneCode.GDobj_9595scpObjects6.length = 0;
gdjs.sceneCode.GDobj_9595scpObjects7.length = 0;
gdjs.sceneCode.GDobj_9595scpObjects8.length = 0;
gdjs.sceneCode.GDobjectName2Objects1.length = 0;
gdjs.sceneCode.GDobjectName2Objects2.length = 0;
gdjs.sceneCode.GDobjectName2Objects3.length = 0;
gdjs.sceneCode.GDobjectName2Objects4.length = 0;
gdjs.sceneCode.GDobjectName2Objects5.length = 0;
gdjs.sceneCode.GDobjectName2Objects6.length = 0;
gdjs.sceneCode.GDobjectName2Objects7.length = 0;
gdjs.sceneCode.GDobjectName2Objects8.length = 0;
gdjs.sceneCode.GDfake_9595cuObjects1.length = 0;
gdjs.sceneCode.GDfake_9595cuObjects2.length = 0;
gdjs.sceneCode.GDfake_9595cuObjects3.length = 0;
gdjs.sceneCode.GDfake_9595cuObjects4.length = 0;
gdjs.sceneCode.GDfake_9595cuObjects5.length = 0;
gdjs.sceneCode.GDfake_9595cuObjects6.length = 0;
gdjs.sceneCode.GDfake_9595cuObjects7.length = 0;
gdjs.sceneCode.GDfake_9595cuObjects8.length = 0;
gdjs.sceneCode.GDijObjects1.length = 0;
gdjs.sceneCode.GDijObjects2.length = 0;
gdjs.sceneCode.GDijObjects3.length = 0;
gdjs.sceneCode.GDijObjects4.length = 0;
gdjs.sceneCode.GDijObjects5.length = 0;
gdjs.sceneCode.GDijObjects6.length = 0;
gdjs.sceneCode.GDijObjects7.length = 0;
gdjs.sceneCode.GDijObjects8.length = 0;
gdjs.sceneCode.GDscrObjects1.length = 0;
gdjs.sceneCode.GDscrObjects2.length = 0;
gdjs.sceneCode.GDscrObjects3.length = 0;
gdjs.sceneCode.GDscrObjects4.length = 0;
gdjs.sceneCode.GDscrObjects5.length = 0;
gdjs.sceneCode.GDscrObjects6.length = 0;
gdjs.sceneCode.GDscrObjects7.length = 0;
gdjs.sceneCode.GDscrObjects8.length = 0;
gdjs.sceneCode.GDwidthObjects1.length = 0;
gdjs.sceneCode.GDwidthObjects2.length = 0;
gdjs.sceneCode.GDwidthObjects3.length = 0;
gdjs.sceneCode.GDwidthObjects4.length = 0;
gdjs.sceneCode.GDwidthObjects5.length = 0;
gdjs.sceneCode.GDwidthObjects6.length = 0;
gdjs.sceneCode.GDwidthObjects7.length = 0;
gdjs.sceneCode.GDwidthObjects8.length = 0;
gdjs.sceneCode.GDheightObjects1.length = 0;
gdjs.sceneCode.GDheightObjects2.length = 0;
gdjs.sceneCode.GDheightObjects3.length = 0;
gdjs.sceneCode.GDheightObjects4.length = 0;
gdjs.sceneCode.GDheightObjects5.length = 0;
gdjs.sceneCode.GDheightObjects6.length = 0;
gdjs.sceneCode.GDheightObjects7.length = 0;
gdjs.sceneCode.GDheightObjects8.length = 0;
gdjs.sceneCode.GDxObjects1.length = 0;
gdjs.sceneCode.GDxObjects2.length = 0;
gdjs.sceneCode.GDxObjects3.length = 0;
gdjs.sceneCode.GDxObjects4.length = 0;
gdjs.sceneCode.GDxObjects5.length = 0;
gdjs.sceneCode.GDxObjects6.length = 0;
gdjs.sceneCode.GDxObjects7.length = 0;
gdjs.sceneCode.GDxObjects8.length = 0;
gdjs.sceneCode.GDyObjects1.length = 0;
gdjs.sceneCode.GDyObjects2.length = 0;
gdjs.sceneCode.GDyObjects3.length = 0;
gdjs.sceneCode.GDyObjects4.length = 0;
gdjs.sceneCode.GDyObjects5.length = 0;
gdjs.sceneCode.GDyObjects6.length = 0;
gdjs.sceneCode.GDyObjects7.length = 0;
gdjs.sceneCode.GDyObjects8.length = 0;
gdjs.sceneCode.GDNewTextObjects1.length = 0;
gdjs.sceneCode.GDNewTextObjects2.length = 0;
gdjs.sceneCode.GDNewTextObjects3.length = 0;
gdjs.sceneCode.GDNewTextObjects4.length = 0;
gdjs.sceneCode.GDNewTextObjects5.length = 0;
gdjs.sceneCode.GDNewTextObjects6.length = 0;
gdjs.sceneCode.GDNewTextObjects7.length = 0;
gdjs.sceneCode.GDNewTextObjects8.length = 0;
gdjs.sceneCode.GDstateObjects1.length = 0;
gdjs.sceneCode.GDstateObjects2.length = 0;
gdjs.sceneCode.GDstateObjects3.length = 0;
gdjs.sceneCode.GDstateObjects4.length = 0;
gdjs.sceneCode.GDstateObjects5.length = 0;
gdjs.sceneCode.GDstateObjects6.length = 0;
gdjs.sceneCode.GDstateObjects7.length = 0;
gdjs.sceneCode.GDstateObjects8.length = 0;
gdjs.sceneCode.GDboxObjects1.length = 0;
gdjs.sceneCode.GDboxObjects2.length = 0;
gdjs.sceneCode.GDboxObjects3.length = 0;
gdjs.sceneCode.GDboxObjects4.length = 0;
gdjs.sceneCode.GDboxObjects5.length = 0;
gdjs.sceneCode.GDboxObjects6.length = 0;
gdjs.sceneCode.GDboxObjects7.length = 0;
gdjs.sceneCode.GDboxObjects8.length = 0;
gdjs.sceneCode.GDaddObjects1.length = 0;
gdjs.sceneCode.GDaddObjects2.length = 0;
gdjs.sceneCode.GDaddObjects3.length = 0;
gdjs.sceneCode.GDaddObjects4.length = 0;
gdjs.sceneCode.GDaddObjects5.length = 0;
gdjs.sceneCode.GDaddObjects6.length = 0;
gdjs.sceneCode.GDaddObjects7.length = 0;
gdjs.sceneCode.GDaddObjects8.length = 0;
gdjs.sceneCode.GDobj_9595name_9595giverObjects1.length = 0;
gdjs.sceneCode.GDobj_9595name_9595giverObjects2.length = 0;
gdjs.sceneCode.GDobj_9595name_9595giverObjects3.length = 0;
gdjs.sceneCode.GDobj_9595name_9595giverObjects4.length = 0;
gdjs.sceneCode.GDobj_9595name_9595giverObjects5.length = 0;
gdjs.sceneCode.GDobj_9595name_9595giverObjects6.length = 0;
gdjs.sceneCode.GDobj_9595name_9595giverObjects7.length = 0;
gdjs.sceneCode.GDobj_9595name_9595giverObjects8.length = 0;
gdjs.sceneCode.GDcreateObjects1.length = 0;
gdjs.sceneCode.GDcreateObjects2.length = 0;
gdjs.sceneCode.GDcreateObjects3.length = 0;
gdjs.sceneCode.GDcreateObjects4.length = 0;
gdjs.sceneCode.GDcreateObjects5.length = 0;
gdjs.sceneCode.GDcreateObjects6.length = 0;
gdjs.sceneCode.GDcreateObjects7.length = 0;
gdjs.sceneCode.GDcreateObjects8.length = 0;
gdjs.sceneCode.GDreObjects1.length = 0;
gdjs.sceneCode.GDreObjects2.length = 0;
gdjs.sceneCode.GDreObjects3.length = 0;
gdjs.sceneCode.GDreObjects4.length = 0;
gdjs.sceneCode.GDreObjects5.length = 0;
gdjs.sceneCode.GDreObjects6.length = 0;
gdjs.sceneCode.GDreObjects7.length = 0;
gdjs.sceneCode.GDreObjects8.length = 0;

gdjs.sceneCode.eventsList29(runtimeScene);
gdjs.sceneCode.GDspriteObjects1.length = 0;
gdjs.sceneCode.GDspriteObjects2.length = 0;
gdjs.sceneCode.GDspriteObjects3.length = 0;
gdjs.sceneCode.GDspriteObjects4.length = 0;
gdjs.sceneCode.GDspriteObjects5.length = 0;
gdjs.sceneCode.GDspriteObjects6.length = 0;
gdjs.sceneCode.GDspriteObjects7.length = 0;
gdjs.sceneCode.GDspriteObjects8.length = 0;
gdjs.sceneCode.GDdebugObjects1.length = 0;
gdjs.sceneCode.GDdebugObjects2.length = 0;
gdjs.sceneCode.GDdebugObjects3.length = 0;
gdjs.sceneCode.GDdebugObjects4.length = 0;
gdjs.sceneCode.GDdebugObjects5.length = 0;
gdjs.sceneCode.GDdebugObjects6.length = 0;
gdjs.sceneCode.GDdebugObjects7.length = 0;
gdjs.sceneCode.GDdebugObjects8.length = 0;
gdjs.sceneCode.GDdialougObjects1.length = 0;
gdjs.sceneCode.GDdialougObjects2.length = 0;
gdjs.sceneCode.GDdialougObjects3.length = 0;
gdjs.sceneCode.GDdialougObjects4.length = 0;
gdjs.sceneCode.GDdialougObjects5.length = 0;
gdjs.sceneCode.GDdialougObjects6.length = 0;
gdjs.sceneCode.GDdialougObjects7.length = 0;
gdjs.sceneCode.GDdialougObjects8.length = 0;
gdjs.sceneCode.GDobject_9595var_9595inputObjects1.length = 0;
gdjs.sceneCode.GDobject_9595var_9595inputObjects2.length = 0;
gdjs.sceneCode.GDobject_9595var_9595inputObjects3.length = 0;
gdjs.sceneCode.GDobject_9595var_9595inputObjects4.length = 0;
gdjs.sceneCode.GDobject_9595var_9595inputObjects5.length = 0;
gdjs.sceneCode.GDobject_9595var_9595inputObjects6.length = 0;
gdjs.sceneCode.GDobject_9595var_9595inputObjects7.length = 0;
gdjs.sceneCode.GDobject_9595var_9595inputObjects8.length = 0;
gdjs.sceneCode.GDobjectNamesObjects1.length = 0;
gdjs.sceneCode.GDobjectNamesObjects2.length = 0;
gdjs.sceneCode.GDobjectNamesObjects3.length = 0;
gdjs.sceneCode.GDobjectNamesObjects4.length = 0;
gdjs.sceneCode.GDobjectNamesObjects5.length = 0;
gdjs.sceneCode.GDobjectNamesObjects6.length = 0;
gdjs.sceneCode.GDobjectNamesObjects7.length = 0;
gdjs.sceneCode.GDobjectNamesObjects8.length = 0;
gdjs.sceneCode.GDobjectNameObjects1.length = 0;
gdjs.sceneCode.GDobjectNameObjects2.length = 0;
gdjs.sceneCode.GDobjectNameObjects3.length = 0;
gdjs.sceneCode.GDobjectNameObjects4.length = 0;
gdjs.sceneCode.GDobjectNameObjects5.length = 0;
gdjs.sceneCode.GDobjectNameObjects6.length = 0;
gdjs.sceneCode.GDobjectNameObjects7.length = 0;
gdjs.sceneCode.GDobjectNameObjects8.length = 0;
gdjs.sceneCode.GDdragNdropObjects1.length = 0;
gdjs.sceneCode.GDdragNdropObjects2.length = 0;
gdjs.sceneCode.GDdragNdropObjects3.length = 0;
gdjs.sceneCode.GDdragNdropObjects4.length = 0;
gdjs.sceneCode.GDdragNdropObjects5.length = 0;
gdjs.sceneCode.GDdragNdropObjects6.length = 0;
gdjs.sceneCode.GDdragNdropObjects7.length = 0;
gdjs.sceneCode.GDdragNdropObjects8.length = 0;
gdjs.sceneCode.GDobj_9595scpObjects1.length = 0;
gdjs.sceneCode.GDobj_9595scpObjects2.length = 0;
gdjs.sceneCode.GDobj_9595scpObjects3.length = 0;
gdjs.sceneCode.GDobj_9595scpObjects4.length = 0;
gdjs.sceneCode.GDobj_9595scpObjects5.length = 0;
gdjs.sceneCode.GDobj_9595scpObjects6.length = 0;
gdjs.sceneCode.GDobj_9595scpObjects7.length = 0;
gdjs.sceneCode.GDobj_9595scpObjects8.length = 0;
gdjs.sceneCode.GDobjectName2Objects1.length = 0;
gdjs.sceneCode.GDobjectName2Objects2.length = 0;
gdjs.sceneCode.GDobjectName2Objects3.length = 0;
gdjs.sceneCode.GDobjectName2Objects4.length = 0;
gdjs.sceneCode.GDobjectName2Objects5.length = 0;
gdjs.sceneCode.GDobjectName2Objects6.length = 0;
gdjs.sceneCode.GDobjectName2Objects7.length = 0;
gdjs.sceneCode.GDobjectName2Objects8.length = 0;
gdjs.sceneCode.GDfake_9595cuObjects1.length = 0;
gdjs.sceneCode.GDfake_9595cuObjects2.length = 0;
gdjs.sceneCode.GDfake_9595cuObjects3.length = 0;
gdjs.sceneCode.GDfake_9595cuObjects4.length = 0;
gdjs.sceneCode.GDfake_9595cuObjects5.length = 0;
gdjs.sceneCode.GDfake_9595cuObjects6.length = 0;
gdjs.sceneCode.GDfake_9595cuObjects7.length = 0;
gdjs.sceneCode.GDfake_9595cuObjects8.length = 0;
gdjs.sceneCode.GDijObjects1.length = 0;
gdjs.sceneCode.GDijObjects2.length = 0;
gdjs.sceneCode.GDijObjects3.length = 0;
gdjs.sceneCode.GDijObjects4.length = 0;
gdjs.sceneCode.GDijObjects5.length = 0;
gdjs.sceneCode.GDijObjects6.length = 0;
gdjs.sceneCode.GDijObjects7.length = 0;
gdjs.sceneCode.GDijObjects8.length = 0;
gdjs.sceneCode.GDscrObjects1.length = 0;
gdjs.sceneCode.GDscrObjects2.length = 0;
gdjs.sceneCode.GDscrObjects3.length = 0;
gdjs.sceneCode.GDscrObjects4.length = 0;
gdjs.sceneCode.GDscrObjects5.length = 0;
gdjs.sceneCode.GDscrObjects6.length = 0;
gdjs.sceneCode.GDscrObjects7.length = 0;
gdjs.sceneCode.GDscrObjects8.length = 0;
gdjs.sceneCode.GDwidthObjects1.length = 0;
gdjs.sceneCode.GDwidthObjects2.length = 0;
gdjs.sceneCode.GDwidthObjects3.length = 0;
gdjs.sceneCode.GDwidthObjects4.length = 0;
gdjs.sceneCode.GDwidthObjects5.length = 0;
gdjs.sceneCode.GDwidthObjects6.length = 0;
gdjs.sceneCode.GDwidthObjects7.length = 0;
gdjs.sceneCode.GDwidthObjects8.length = 0;
gdjs.sceneCode.GDheightObjects1.length = 0;
gdjs.sceneCode.GDheightObjects2.length = 0;
gdjs.sceneCode.GDheightObjects3.length = 0;
gdjs.sceneCode.GDheightObjects4.length = 0;
gdjs.sceneCode.GDheightObjects5.length = 0;
gdjs.sceneCode.GDheightObjects6.length = 0;
gdjs.sceneCode.GDheightObjects7.length = 0;
gdjs.sceneCode.GDheightObjects8.length = 0;
gdjs.sceneCode.GDxObjects1.length = 0;
gdjs.sceneCode.GDxObjects2.length = 0;
gdjs.sceneCode.GDxObjects3.length = 0;
gdjs.sceneCode.GDxObjects4.length = 0;
gdjs.sceneCode.GDxObjects5.length = 0;
gdjs.sceneCode.GDxObjects6.length = 0;
gdjs.sceneCode.GDxObjects7.length = 0;
gdjs.sceneCode.GDxObjects8.length = 0;
gdjs.sceneCode.GDyObjects1.length = 0;
gdjs.sceneCode.GDyObjects2.length = 0;
gdjs.sceneCode.GDyObjects3.length = 0;
gdjs.sceneCode.GDyObjects4.length = 0;
gdjs.sceneCode.GDyObjects5.length = 0;
gdjs.sceneCode.GDyObjects6.length = 0;
gdjs.sceneCode.GDyObjects7.length = 0;
gdjs.sceneCode.GDyObjects8.length = 0;
gdjs.sceneCode.GDNewTextObjects1.length = 0;
gdjs.sceneCode.GDNewTextObjects2.length = 0;
gdjs.sceneCode.GDNewTextObjects3.length = 0;
gdjs.sceneCode.GDNewTextObjects4.length = 0;
gdjs.sceneCode.GDNewTextObjects5.length = 0;
gdjs.sceneCode.GDNewTextObjects6.length = 0;
gdjs.sceneCode.GDNewTextObjects7.length = 0;
gdjs.sceneCode.GDNewTextObjects8.length = 0;
gdjs.sceneCode.GDstateObjects1.length = 0;
gdjs.sceneCode.GDstateObjects2.length = 0;
gdjs.sceneCode.GDstateObjects3.length = 0;
gdjs.sceneCode.GDstateObjects4.length = 0;
gdjs.sceneCode.GDstateObjects5.length = 0;
gdjs.sceneCode.GDstateObjects6.length = 0;
gdjs.sceneCode.GDstateObjects7.length = 0;
gdjs.sceneCode.GDstateObjects8.length = 0;
gdjs.sceneCode.GDboxObjects1.length = 0;
gdjs.sceneCode.GDboxObjects2.length = 0;
gdjs.sceneCode.GDboxObjects3.length = 0;
gdjs.sceneCode.GDboxObjects4.length = 0;
gdjs.sceneCode.GDboxObjects5.length = 0;
gdjs.sceneCode.GDboxObjects6.length = 0;
gdjs.sceneCode.GDboxObjects7.length = 0;
gdjs.sceneCode.GDboxObjects8.length = 0;
gdjs.sceneCode.GDaddObjects1.length = 0;
gdjs.sceneCode.GDaddObjects2.length = 0;
gdjs.sceneCode.GDaddObjects3.length = 0;
gdjs.sceneCode.GDaddObjects4.length = 0;
gdjs.sceneCode.GDaddObjects5.length = 0;
gdjs.sceneCode.GDaddObjects6.length = 0;
gdjs.sceneCode.GDaddObjects7.length = 0;
gdjs.sceneCode.GDaddObjects8.length = 0;
gdjs.sceneCode.GDobj_9595name_9595giverObjects1.length = 0;
gdjs.sceneCode.GDobj_9595name_9595giverObjects2.length = 0;
gdjs.sceneCode.GDobj_9595name_9595giverObjects3.length = 0;
gdjs.sceneCode.GDobj_9595name_9595giverObjects4.length = 0;
gdjs.sceneCode.GDobj_9595name_9595giverObjects5.length = 0;
gdjs.sceneCode.GDobj_9595name_9595giverObjects6.length = 0;
gdjs.sceneCode.GDobj_9595name_9595giverObjects7.length = 0;
gdjs.sceneCode.GDobj_9595name_9595giverObjects8.length = 0;
gdjs.sceneCode.GDcreateObjects1.length = 0;
gdjs.sceneCode.GDcreateObjects2.length = 0;
gdjs.sceneCode.GDcreateObjects3.length = 0;
gdjs.sceneCode.GDcreateObjects4.length = 0;
gdjs.sceneCode.GDcreateObjects5.length = 0;
gdjs.sceneCode.GDcreateObjects6.length = 0;
gdjs.sceneCode.GDcreateObjects7.length = 0;
gdjs.sceneCode.GDcreateObjects8.length = 0;
gdjs.sceneCode.GDreObjects1.length = 0;
gdjs.sceneCode.GDreObjects2.length = 0;
gdjs.sceneCode.GDreObjects3.length = 0;
gdjs.sceneCode.GDreObjects4.length = 0;
gdjs.sceneCode.GDreObjects5.length = 0;
gdjs.sceneCode.GDreObjects6.length = 0;
gdjs.sceneCode.GDreObjects7.length = 0;
gdjs.sceneCode.GDreObjects8.length = 0;


return;

}

gdjs['sceneCode'] = gdjs.sceneCode;
