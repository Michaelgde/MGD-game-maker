gdjs.scratchCode = {};
gdjs.scratchCode.localVariables = [];
gdjs.scratchCode.GDconsole_9595blockObjects1= [];
gdjs.scratchCode.GDconsole_9595blockObjects2= [];
gdjs.scratchCode.GDconsole_9595blockObjects3= [];
gdjs.scratchCode.GDChevronArrowLeftObjects1= [];
gdjs.scratchCode.GDChevronArrowLeftObjects2= [];
gdjs.scratchCode.GDChevronArrowLeftObjects3= [];
gdjs.scratchCode.GDFileScriptObjects1= [];
gdjs.scratchCode.GDFileScriptObjects2= [];
gdjs.scratchCode.GDFileScriptObjects3= [];


gdjs.scratchCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = (gdjs.evtTools.variable.getVariableString(gdjs.scratchCode.localVariables[0].getFromIndex(0))).startsWith("<xml");
if (isConditionTrue_0) {
{gdjs.evtsExt__Clipboard__WriteText.func(runtimeScene, gdjs.scratchCode.localVariables[0].getFromIndex(0).getAsString(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.scratchCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}}

}


};gdjs.scratchCode.mapOfGDgdjs_9546scratchCode_9546GDFileScriptObjects1Objects = Hashtable.newFrom({"FileScript": gdjs.scratchCode.GDFileScriptObjects1});
gdjs.scratchCode.eventsList2 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = (gdjs.evtTools.variable.getVariableString(gdjs.scratchCode.localVariables[0].getFromIndex(0))).startsWith("<xml");
if (isConditionTrue_0) {
{gdjs.evtTools.storage.writeStringInJSONFile("scratch", "scratch", gdjs.scratchCode.localVariables[0].getFromIndex(0).getAsString());
}}

}


};gdjs.scratchCode.asyncCallback24790140 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.scratchCode.localVariables);

{ //Subevents
gdjs.scratchCode.eventsList2(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.scratchCode.localVariables.length = 0;
}
gdjs.scratchCode.eventsList3 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.scratchCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__Clipboard__AsynchronouslyReadTextCrossPlaform.func(runtimeScene, gdjs.scratchCode.localVariables[0].getFromIndex(0), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.scratchCode.asyncCallback24790140(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.scratchCode.eventsList4 = function(runtimeScene) {

{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setString("");
variables._declare("clipboard", variable);
}
gdjs.scratchCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readStringFromJSONFile("scratch", "scratch", runtimeScene, gdjs.scratchCode.localVariables[0].getFromIndex(0));
}
{ //Subevents
gdjs.scratchCode.eventsList0(runtimeScene);} //End of subevents
}
gdjs.scratchCode.localVariables.pop();

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Escape");
if (isConditionTrue_0) {
{gdjs.evtsExt__Iframe__Delete.func(runtimeScene, "f", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.scratchCode.eventsList1(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(24788564);
}
if (isConditionTrue_0) {
{gdjs.evtsExt__Iframe__Create.func(runtimeScene, "f", runtimeScene.getScene().getVariables().getFromIndex(1).getAsString(), 1200, 660, 0, 0, true, true, "", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("FileScript"), gdjs.scratchCode.GDFileScriptObjects1);

{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setString("");
variables._declare("clipboard", variable);
}
gdjs.scratchCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.scratchCode.mapOfGDgdjs_9546scratchCode_9546GDFileScriptObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(24789900);
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.scratchCode.eventsList3(runtimeScene);} //End of subevents
}
gdjs.scratchCode.localVariables.pop();

}


};

gdjs.scratchCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.scratchCode.GDconsole_9595blockObjects1.length = 0;
gdjs.scratchCode.GDconsole_9595blockObjects2.length = 0;
gdjs.scratchCode.GDconsole_9595blockObjects3.length = 0;
gdjs.scratchCode.GDChevronArrowLeftObjects1.length = 0;
gdjs.scratchCode.GDChevronArrowLeftObjects2.length = 0;
gdjs.scratchCode.GDChevronArrowLeftObjects3.length = 0;
gdjs.scratchCode.GDFileScriptObjects1.length = 0;
gdjs.scratchCode.GDFileScriptObjects2.length = 0;
gdjs.scratchCode.GDFileScriptObjects3.length = 0;

gdjs.scratchCode.eventsList4(runtimeScene);
gdjs.scratchCode.GDconsole_9595blockObjects1.length = 0;
gdjs.scratchCode.GDconsole_9595blockObjects2.length = 0;
gdjs.scratchCode.GDconsole_9595blockObjects3.length = 0;
gdjs.scratchCode.GDChevronArrowLeftObjects1.length = 0;
gdjs.scratchCode.GDChevronArrowLeftObjects2.length = 0;
gdjs.scratchCode.GDChevronArrowLeftObjects3.length = 0;
gdjs.scratchCode.GDFileScriptObjects1.length = 0;
gdjs.scratchCode.GDFileScriptObjects2.length = 0;
gdjs.scratchCode.GDFileScriptObjects3.length = 0;


return;

}

gdjs['scratchCode'] = gdjs.scratchCode;
