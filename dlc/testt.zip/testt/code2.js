gdjs.mainCode = {};
gdjs.mainCode.localVariables = [];


gdjs.mainCode.eventsList0 = function(runtimeScene) {

};

gdjs.mainCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();


gdjs.mainCode.eventsList0(runtimeScene);


return;

}

gdjs['mainCode'] = gdjs.mainCode;
