gdjs.renderCode = {};
gdjs.renderCode.localVariables = [];
gdjs.renderCode.GDRuntimeObjObjects1= [];
gdjs.renderCode.GDRuntimeObjObjects2= [];
gdjs.renderCode.GDRuntimeObjObjects3= [];
gdjs.renderCode.GDdObjects1= [];
gdjs.renderCode.GDdObjects2= [];
gdjs.renderCode.GDdObjects3= [];
gdjs.renderCode.GDaObjects1= [];
gdjs.renderCode.GDaObjects2= [];
gdjs.renderCode.GDaObjects3= [];
gdjs.renderCode.GDtooooObjects1= [];
gdjs.renderCode.GDtooooObjects2= [];
gdjs.renderCode.GDtooooObjects3= [];


gdjs.renderCode.userFunc0xf40a88 = function GDJSInlineCode(runtimeScene) {
"use strict";
// Access the scene PIXI container
//const runtimeScene = eventsFunctionContext ? eventsFunctionContext.getScene() : runtimeScene;
const renderer = runtimeScene.getRenderer();
const pixiContainer = renderer.getPIXIContainer();

// Create a custom PixiJS object (e.g., a rectangle)
const customObject = new PIXI.Graphics();
customObject.beginFill(0xff0000); // Red color
customObject.drawRect(200, 100, 100, 50); // Rectangle of width 100, height 50
customObject.endFill();

// Set its position
customObject.x = 200;
customObject.y = 150;

// Add the custom object to the PixiJS container
pixiContainer.addChild(customObject);

// Optional: Store it in a variable for later use
runtimeScene.getVariables().get("myCustomObject").setString("Created!");

};
gdjs.renderCode.userFunc0xffff18 = function GDJSInlineCode(runtimeScene) {
"use strict";
console.log(runtimeScene._objects)

};
gdjs.renderCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{


gdjs.renderCode.userFunc0xffff18(runtimeScene);

}


};gdjs.renderCode.eventsList1 = function(runtimeScene) {

{


gdjs.renderCode.userFunc0xf40a88(runtimeScene);

}


{



}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("d"), gdjs.renderCode.GDdObjects1);
gdjs.copyArray(runtimeScene.getObjects("toooo"), gdjs.renderCode.GDtooooObjects1);
{for(var i = 0, len = gdjs.renderCode.GDdObjects1.length ;i < len;++i) {
    gdjs.renderCode.GDdObjects1[i].getBehavior("Text").setText("angle: " + gdjs.evtTools.common.toString((( gdjs.renderCode.GDtooooObjects1.length === 0 ) ? 0 :gdjs.renderCode.GDtooooObjects1[0].getAngle())) + "\npos: " + gdjs.evtTools.common.toString((( gdjs.renderCode.GDtooooObjects1.length === 0 ) ? 0 :gdjs.renderCode.GDtooooObjects1[0].getPointX(""))) + " , " + gdjs.evtTools.common.toString((( gdjs.renderCode.GDtooooObjects1.length === 0 ) ? 0 :gdjs.renderCode.GDtooooObjects1[0].getPointY(""))));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "a");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("a"), gdjs.renderCode.GDaObjects1);
gdjs.copyArray(runtimeScene.getObjects("toooo"), gdjs.renderCode.GDtooooObjects1);
{for(var i = 0, len = gdjs.renderCode.GDtooooObjects1.length ;i < len;++i) {
    gdjs.renderCode.GDtooooObjects1[i].addPolarForce(gdjs.evtTools.common.toNumber((( gdjs.renderCode.GDaObjects1.length === 0 ) ? "" :gdjs.renderCode.GDaObjects1[0].getBehavior("Text").getText())) - 90, 2, 0);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "q");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("toooo"), gdjs.renderCode.GDtooooObjects1);
{for(var i = 0, len = gdjs.renderCode.GDtooooObjects1.length ;i < len;++i) {
    gdjs.renderCode.GDtooooObjects1[i].setPosition(0,0);
}
}
{ //Subevents
gdjs.renderCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.renderCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.renderCode.GDRuntimeObjObjects1.length = 0;
gdjs.renderCode.GDRuntimeObjObjects2.length = 0;
gdjs.renderCode.GDRuntimeObjObjects3.length = 0;
gdjs.renderCode.GDdObjects1.length = 0;
gdjs.renderCode.GDdObjects2.length = 0;
gdjs.renderCode.GDdObjects3.length = 0;
gdjs.renderCode.GDaObjects1.length = 0;
gdjs.renderCode.GDaObjects2.length = 0;
gdjs.renderCode.GDaObjects3.length = 0;
gdjs.renderCode.GDtooooObjects1.length = 0;
gdjs.renderCode.GDtooooObjects2.length = 0;
gdjs.renderCode.GDtooooObjects3.length = 0;

gdjs.renderCode.eventsList1(runtimeScene);
gdjs.renderCode.GDRuntimeObjObjects1.length = 0;
gdjs.renderCode.GDRuntimeObjObjects2.length = 0;
gdjs.renderCode.GDRuntimeObjObjects3.length = 0;
gdjs.renderCode.GDdObjects1.length = 0;
gdjs.renderCode.GDdObjects2.length = 0;
gdjs.renderCode.GDdObjects3.length = 0;
gdjs.renderCode.GDaObjects1.length = 0;
gdjs.renderCode.GDaObjects2.length = 0;
gdjs.renderCode.GDaObjects3.length = 0;
gdjs.renderCode.GDtooooObjects1.length = 0;
gdjs.renderCode.GDtooooObjects2.length = 0;
gdjs.renderCode.GDtooooObjects3.length = 0;


return;

}

gdjs['renderCode'] = gdjs.renderCode;
