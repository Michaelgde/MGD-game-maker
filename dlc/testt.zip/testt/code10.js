gdjs.PreviewSceneCode = {};
gdjs.PreviewSceneCode.localVariables = [];
gdjs.PreviewSceneCode.forEachIndex2 = 0;

gdjs.PreviewSceneCode.forEachIndex3 = 0;

gdjs.PreviewSceneCode.forEachObjects2 = [];

gdjs.PreviewSceneCode.forEachObjects3 = [];

gdjs.PreviewSceneCode.forEachTemporary2 = null;

gdjs.PreviewSceneCode.forEachTemporary3 = null;

gdjs.PreviewSceneCode.forEachTotalCount2 = 0;

gdjs.PreviewSceneCode.forEachTotalCount3 = 0;

gdjs.PreviewSceneCode.GDspriteObjects1= [];
gdjs.PreviewSceneCode.GDspriteObjects2= [];
gdjs.PreviewSceneCode.GDspriteObjects3= [];
gdjs.PreviewSceneCode.GDspriteObjects4= [];
gdjs.PreviewSceneCode.GDspriteObjects5= [];
gdjs.PreviewSceneCode.GDdebugObjects1= [];
gdjs.PreviewSceneCode.GDdebugObjects2= [];
gdjs.PreviewSceneCode.GDdebugObjects3= [];
gdjs.PreviewSceneCode.GDdebugObjects4= [];
gdjs.PreviewSceneCode.GDdebugObjects5= [];
gdjs.PreviewSceneCode.GDdialougObjects1= [];
gdjs.PreviewSceneCode.GDdialougObjects2= [];
gdjs.PreviewSceneCode.GDdialougObjects3= [];
gdjs.PreviewSceneCode.GDdialougObjects4= [];
gdjs.PreviewSceneCode.GDdialougObjects5= [];
gdjs.PreviewSceneCode.GDobject_9595var_9595inputObjects1= [];
gdjs.PreviewSceneCode.GDobject_9595var_9595inputObjects2= [];
gdjs.PreviewSceneCode.GDobject_9595var_9595inputObjects3= [];
gdjs.PreviewSceneCode.GDobject_9595var_9595inputObjects4= [];
gdjs.PreviewSceneCode.GDobject_9595var_9595inputObjects5= [];
gdjs.PreviewSceneCode.GDobjectNamesObjects1= [];
gdjs.PreviewSceneCode.GDobjectNamesObjects2= [];
gdjs.PreviewSceneCode.GDobjectNamesObjects3= [];
gdjs.PreviewSceneCode.GDobjectNamesObjects4= [];
gdjs.PreviewSceneCode.GDobjectNamesObjects5= [];
gdjs.PreviewSceneCode.GDobjectNameObjects1= [];
gdjs.PreviewSceneCode.GDobjectNameObjects2= [];
gdjs.PreviewSceneCode.GDobjectNameObjects3= [];
gdjs.PreviewSceneCode.GDobjectNameObjects4= [];
gdjs.PreviewSceneCode.GDobjectNameObjects5= [];
gdjs.PreviewSceneCode.GDdragNdropObjects1= [];
gdjs.PreviewSceneCode.GDdragNdropObjects2= [];
gdjs.PreviewSceneCode.GDdragNdropObjects3= [];
gdjs.PreviewSceneCode.GDdragNdropObjects4= [];
gdjs.PreviewSceneCode.GDdragNdropObjects5= [];
gdjs.PreviewSceneCode.GDobj_9595scpObjects1= [];
gdjs.PreviewSceneCode.GDobj_9595scpObjects2= [];
gdjs.PreviewSceneCode.GDobj_9595scpObjects3= [];
gdjs.PreviewSceneCode.GDobj_9595scpObjects4= [];
gdjs.PreviewSceneCode.GDobj_9595scpObjects5= [];
gdjs.PreviewSceneCode.GDobjectName2Objects1= [];
gdjs.PreviewSceneCode.GDobjectName2Objects2= [];
gdjs.PreviewSceneCode.GDobjectName2Objects3= [];
gdjs.PreviewSceneCode.GDobjectName2Objects4= [];
gdjs.PreviewSceneCode.GDobjectName2Objects5= [];
gdjs.PreviewSceneCode.GDfake_9595cuObjects1= [];
gdjs.PreviewSceneCode.GDfake_9595cuObjects2= [];
gdjs.PreviewSceneCode.GDfake_9595cuObjects3= [];
gdjs.PreviewSceneCode.GDfake_9595cuObjects4= [];
gdjs.PreviewSceneCode.GDfake_9595cuObjects5= [];
gdjs.PreviewSceneCode.GDijObjects1= [];
gdjs.PreviewSceneCode.GDijObjects2= [];
gdjs.PreviewSceneCode.GDijObjects3= [];
gdjs.PreviewSceneCode.GDijObjects4= [];
gdjs.PreviewSceneCode.GDijObjects5= [];
gdjs.PreviewSceneCode.GDscrObjects1= [];
gdjs.PreviewSceneCode.GDscrObjects2= [];
gdjs.PreviewSceneCode.GDscrObjects3= [];
gdjs.PreviewSceneCode.GDscrObjects4= [];
gdjs.PreviewSceneCode.GDscrObjects5= [];
gdjs.PreviewSceneCode.GDwidthObjects1= [];
gdjs.PreviewSceneCode.GDwidthObjects2= [];
gdjs.PreviewSceneCode.GDwidthObjects3= [];
gdjs.PreviewSceneCode.GDwidthObjects4= [];
gdjs.PreviewSceneCode.GDwidthObjects5= [];
gdjs.PreviewSceneCode.GDheightObjects1= [];
gdjs.PreviewSceneCode.GDheightObjects2= [];
gdjs.PreviewSceneCode.GDheightObjects3= [];
gdjs.PreviewSceneCode.GDheightObjects4= [];
gdjs.PreviewSceneCode.GDheightObjects5= [];
gdjs.PreviewSceneCode.GDxObjects1= [];
gdjs.PreviewSceneCode.GDxObjects2= [];
gdjs.PreviewSceneCode.GDxObjects3= [];
gdjs.PreviewSceneCode.GDxObjects4= [];
gdjs.PreviewSceneCode.GDxObjects5= [];
gdjs.PreviewSceneCode.GDyObjects1= [];
gdjs.PreviewSceneCode.GDyObjects2= [];
gdjs.PreviewSceneCode.GDyObjects3= [];
gdjs.PreviewSceneCode.GDyObjects4= [];
gdjs.PreviewSceneCode.GDyObjects5= [];
gdjs.PreviewSceneCode.GDNewTextObjects1= [];
gdjs.PreviewSceneCode.GDNewTextObjects2= [];
gdjs.PreviewSceneCode.GDNewTextObjects3= [];
gdjs.PreviewSceneCode.GDNewTextObjects4= [];
gdjs.PreviewSceneCode.GDNewTextObjects5= [];
gdjs.PreviewSceneCode.GDerrorObjects1= [];
gdjs.PreviewSceneCode.GDerrorObjects2= [];
gdjs.PreviewSceneCode.GDerrorObjects3= [];
gdjs.PreviewSceneCode.GDerrorObjects4= [];
gdjs.PreviewSceneCode.GDerrorObjects5= [];
gdjs.PreviewSceneCode.GDy2Objects1= [];
gdjs.PreviewSceneCode.GDy2Objects2= [];
gdjs.PreviewSceneCode.GDy2Objects3= [];
gdjs.PreviewSceneCode.GDy2Objects4= [];
gdjs.PreviewSceneCode.GDy2Objects5= [];
gdjs.PreviewSceneCode.GDstaticObjects1= [];
gdjs.PreviewSceneCode.GDstaticObjects2= [];
gdjs.PreviewSceneCode.GDstaticObjects3= [];
gdjs.PreviewSceneCode.GDstaticObjects4= [];
gdjs.PreviewSceneCode.GDstaticObjects5= [];
gdjs.PreviewSceneCode.GDdynamicObjects1= [];
gdjs.PreviewSceneCode.GDdynamicObjects2= [];
gdjs.PreviewSceneCode.GDdynamicObjects3= [];
gdjs.PreviewSceneCode.GDdynamicObjects4= [];
gdjs.PreviewSceneCode.GDdynamicObjects5= [];


gdjs.PreviewSceneCode.eventsList0 = function(runtimeScene, asyncObjectsList) {

};gdjs.PreviewSceneCode.eventsList1 = function(runtimeScene, asyncObjectsList) {

{

gdjs.copyArray(runtimeScene.getObjects("sprite"), gdjs.PreviewSceneCode.GDspriteObjects2);

for (gdjs.PreviewSceneCode.forEachIndex3 = 0;gdjs.PreviewSceneCode.forEachIndex3 < gdjs.PreviewSceneCode.GDspriteObjects2.length;++gdjs.PreviewSceneCode.forEachIndex3) {
gdjs.PreviewSceneCode.GDspriteObjects3.length = 0;


gdjs.PreviewSceneCode.forEachTemporary3 = gdjs.PreviewSceneCode.GDspriteObjects2[gdjs.PreviewSceneCode.forEachIndex3];
gdjs.PreviewSceneCode.GDspriteObjects3.push(gdjs.PreviewSceneCode.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {
{for(var i = 0, len = gdjs.PreviewSceneCode.GDspriteObjects3.length ;i < len;++i) {
    gdjs.PreviewSceneCode.GDspriteObjects3[i].getBehavior("Resizable").setSize(runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.PreviewSceneCode.localVariables[0].getFromIndex(0).getAsNumber()).getChild("width").getAsNumber(), runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.PreviewSceneCode.localVariables[0].getFromIndex(0).getAsNumber()).getChild("height").getAsNumber());
}
}{gdjs.PreviewSceneCode.localVariables[0].getFromIndex(0).add(1);
}}
}

}


};gdjs.PreviewSceneCode.asyncCallback24387308 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.PreviewSceneCode.localVariables);

{ //Subevents
gdjs.PreviewSceneCode.eventsList1(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.PreviewSceneCode.localVariables.length = 0;
}
gdjs.PreviewSceneCode.eventsList2 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.PreviewSceneCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.PreviewSceneCode.asyncCallback24387308(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.PreviewSceneCode.eventsList3 = function(runtimeScene) {

{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("counterNM", variable);
}
gdjs.PreviewSceneCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.PreviewSceneCode.eventsList2(runtimeScene);} //End of subevents
}
gdjs.PreviewSceneCode.localVariables.pop();

}


};gdjs.PreviewSceneCode.mapOfGDgdjs_9546PreviewSceneCode_9546GDspriteObjects1Objects = Hashtable.newFrom({"sprite": gdjs.PreviewSceneCode.GDspriteObjects1});
gdjs.PreviewSceneCode.mapOfGDgdjs_9546PreviewSceneCode_9546GDspriteObjects3Objects = Hashtable.newFrom({"sprite": gdjs.PreviewSceneCode.GDspriteObjects3});
gdjs.PreviewSceneCode.mapOfGDgdjs_9546PreviewSceneCode_9546GDstaticObjects3Objects = Hashtable.newFrom({"static": gdjs.PreviewSceneCode.GDstaticObjects3});
gdjs.PreviewSceneCode.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.PreviewSceneCode.GDspriteObjects2, gdjs.PreviewSceneCode.GDspriteObjects3);

gdjs.copyArray(runtimeScene.getObjects("static"), gdjs.PreviewSceneCode.GDstaticObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PreviewSceneCode.GDstaticObjects3.length;i<l;++i) {
    if ( gdjs.PreviewSceneCode.GDstaticObjects3[i].getVariableString(gdjs.PreviewSceneCode.GDstaticObjects3[i].getVariables().getFromIndex(0)) == ((gdjs.PreviewSceneCode.GDspriteObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.PreviewSceneCode.GDspriteObjects3[0].getVariables()).get("name").getAsString() + ((gdjs.PreviewSceneCode.GDspriteObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.PreviewSceneCode.GDspriteObjects3[0].getVariables()).get("id").getAsString() ) {
        isConditionTrue_0 = true;
        gdjs.PreviewSceneCode.GDstaticObjects3[k] = gdjs.PreviewSceneCode.GDstaticObjects3[i];
        ++k;
    }
}
gdjs.PreviewSceneCode.GDstaticObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PreviewSceneCode.GDspriteObjects3.length;i<l;++i) {
    if ( gdjs.PreviewSceneCode.GDspriteObjects3[i].getVariableString(gdjs.PreviewSceneCode.GDspriteObjects3[i].getVariables().get("type")) == "c" ) {
        isConditionTrue_0 = true;
        gdjs.PreviewSceneCode.GDspriteObjects3[k] = gdjs.PreviewSceneCode.GDspriteObjects3[i];
        ++k;
    }
}
gdjs.PreviewSceneCode.GDspriteObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.PreviewSceneCode.GDspriteObjects3 */
/* Reuse gdjs.PreviewSceneCode.GDstaticObjects3 */
{for(var i = 0, len = gdjs.PreviewSceneCode.GDstaticObjects3.length ;i < len;++i) {
    gdjs.PreviewSceneCode.GDstaticObjects3[i].setPosition((( gdjs.PreviewSceneCode.GDspriteObjects3.length === 0 ) ? 0 :gdjs.PreviewSceneCode.GDspriteObjects3[0].getPointX("")),(( gdjs.PreviewSceneCode.GDspriteObjects3.length === 0 ) ? 0 :gdjs.PreviewSceneCode.GDspriteObjects3[0].getPointY("")));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("dynamic"), gdjs.PreviewSceneCode.GDdynamicObjects3);
gdjs.copyArray(gdjs.PreviewSceneCode.GDspriteObjects2, gdjs.PreviewSceneCode.GDspriteObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PreviewSceneCode.GDdynamicObjects3.length;i<l;++i) {
    if ( gdjs.PreviewSceneCode.GDdynamicObjects3[i].getVariableString(gdjs.PreviewSceneCode.GDdynamicObjects3[i].getVariables().getFromIndex(0)) == ((gdjs.PreviewSceneCode.GDspriteObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.PreviewSceneCode.GDspriteObjects3[0].getVariables()).get("name").getAsString() + ((gdjs.PreviewSceneCode.GDspriteObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.PreviewSceneCode.GDspriteObjects3[0].getVariables()).get("id").getAsString() ) {
        isConditionTrue_0 = true;
        gdjs.PreviewSceneCode.GDdynamicObjects3[k] = gdjs.PreviewSceneCode.GDdynamicObjects3[i];
        ++k;
    }
}
gdjs.PreviewSceneCode.GDdynamicObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PreviewSceneCode.GDspriteObjects3.length;i<l;++i) {
    if ( gdjs.PreviewSceneCode.GDspriteObjects3[i].getVariableString(gdjs.PreviewSceneCode.GDspriteObjects3[i].getVariables().get("type")) == "d" ) {
        isConditionTrue_0 = true;
        gdjs.PreviewSceneCode.GDspriteObjects3[k] = gdjs.PreviewSceneCode.GDspriteObjects3[i];
        ++k;
    }
}
gdjs.PreviewSceneCode.GDspriteObjects3.length = k;
}
if (isConditionTrue_0) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("dynamic"), gdjs.PreviewSceneCode.GDdynamicObjects3);
gdjs.copyArray(gdjs.PreviewSceneCode.GDspriteObjects2, gdjs.PreviewSceneCode.GDspriteObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.PreviewSceneCode.mapOfGDgdjs_9546PreviewSceneCode_9546GDspriteObjects3Objects, (gdjs.PreviewSceneCode.GDdynamicObjects3.length !== 0 ? gdjs.PreviewSceneCode.GDdynamicObjects3[0] : null), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
/* Reuse gdjs.PreviewSceneCode.GDdynamicObjects3 */
/* Reuse gdjs.PreviewSceneCode.GDspriteObjects3 */
{for(var i = 0, len = gdjs.PreviewSceneCode.GDdynamicObjects3.length ;i < len;++i) {
    gdjs.PreviewSceneCode.GDdynamicObjects3[i].setPosition(((gdjs.PreviewSceneCode.GDspriteObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.PreviewSceneCode.GDspriteObjects3[0].getVariables()).get("x").getAsNumber(),((gdjs.PreviewSceneCode.GDspriteObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.PreviewSceneCode.GDspriteObjects3[0].getVariables()).get("y").getAsNumber());
}
}{for(var i = 0, len = gdjs.PreviewSceneCode.GDspriteObjects3.length ;i < len;++i) {
    gdjs.PreviewSceneCode.GDspriteObjects3[i].setPosition((( gdjs.PreviewSceneCode.GDdynamicObjects3.length === 0 ) ? 0 :gdjs.PreviewSceneCode.GDdynamicObjects3[0].getPointX("")),(( gdjs.PreviewSceneCode.GDdynamicObjects3.length === 0 ) ? 0 :gdjs.PreviewSceneCode.GDdynamicObjects3[0].getPointY("")));
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("dynamic"), gdjs.PreviewSceneCode.GDdynamicObjects3);
gdjs.copyArray(runtimeScene.getObjects("static"), gdjs.PreviewSceneCode.GDstaticObjects3);
{for(var i = 0, len = gdjs.PreviewSceneCode.GDdynamicObjects3.length ;i < len;++i) {
    gdjs.PreviewSceneCode.GDdynamicObjects3[i].separateFromObjectsList(gdjs.PreviewSceneCode.mapOfGDgdjs_9546PreviewSceneCode_9546GDstaticObjects3Objects, false);
}
}}

}


};gdjs.PreviewSceneCode.mapOfGDgdjs_9546PreviewSceneCode_9546GDspriteObjects2Objects = Hashtable.newFrom({"sprite": gdjs.PreviewSceneCode.GDspriteObjects2});
gdjs.PreviewSceneCode.mapOfGDgdjs_9546PreviewSceneCode_9546GDspriteObjects2Objects = Hashtable.newFrom({"sprite": gdjs.PreviewSceneCode.GDspriteObjects2});
gdjs.PreviewSceneCode.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(gdjs.PreviewSceneCode.localVariables[0].getFromIndex(0)) >= gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(1));
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(8).setBoolean(true);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.PreviewSceneCode.GDspriteObjects2, gdjs.PreviewSceneCode.GDspriteObjects3);

{for(var i = 0, len = gdjs.PreviewSceneCode.GDspriteObjects3.length ;i < len;++i) {
    gdjs.PreviewSceneCode.GDspriteObjects3[i].getBehavior("Resizable").setSize(runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.PreviewSceneCode.localVariables[0].getFromIndex(0).getAsNumber() - 1).getChild("width").getAsNumber(), runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.PreviewSceneCode.localVariables[0].getFromIndex(0).getAsNumber() - 1).getChild("height").getAsNumber());
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
}

}


{



}


};gdjs.PreviewSceneCode.eventsList6 = function(runtimeScene) {

{


const repeatCount2 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(1));
for (let repeatIndex2 = 0;repeatIndex2 < repeatCount2;++repeatIndex2) {
gdjs.PreviewSceneCode.GDspriteObjects2.length = 0;


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PreviewSceneCode.mapOfGDgdjs_9546PreviewSceneCode_9546GDspriteObjects2Objects, runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.PreviewSceneCode.localVariables[0].getFromIndex(0).getAsNumber()).getChild("type").getAsString(), runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.PreviewSceneCode.localVariables[0].getFromIndex(0).getAsNumber()).getChild("x").getAsNumber(), runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.PreviewSceneCode.localVariables[0].getFromIndex(0).getAsNumber()).getChild("y").getAsNumber(), "");
}{gdjs.evtsExt__resize_image_from_url__LoadURLIntoSprite.func(runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.PreviewSceneCode.localVariables[0].getFromIndex(0).getAsNumber()).getChild("image").getAsString(), gdjs.PreviewSceneCode.mapOfGDgdjs_9546PreviewSceneCode_9546GDspriteObjects2Objects, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.PreviewSceneCode.GDspriteObjects2.length ;i < len;++i) {
    gdjs.PreviewSceneCode.GDspriteObjects2[i].getBehavior("Resizable").setSize(runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.PreviewSceneCode.localVariables[0].getFromIndex(0).getAsNumber()).getChild("width").getAsNumber(), runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.PreviewSceneCode.localVariables[0].getFromIndex(0).getAsNumber()).getChild("height").getAsNumber());
}
}{for(var i = 0, len = gdjs.PreviewSceneCode.GDspriteObjects2.length ;i < len;++i) {
    gdjs.PreviewSceneCode.GDspriteObjects2[i].returnVariable(gdjs.PreviewSceneCode.GDspriteObjects2[i].getVariables().get("name")).setString(runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.PreviewSceneCode.localVariables[0].getFromIndex(0).getAsNumber()).getChild("name").getAsString());
}
}{for(var i = 0, len = gdjs.PreviewSceneCode.GDspriteObjects2.length ;i < len;++i) {
    gdjs.PreviewSceneCode.GDspriteObjects2[i].getBehavior("Resizable").setSize(runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.PreviewSceneCode.localVariables[0].getFromIndex(0).getAsNumber()).getChild("width").getAsNumber(), runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.PreviewSceneCode.localVariables[0].getFromIndex(0).getAsNumber()).getChild("height").getAsNumber());
}
}{runtimeScene.getScene().getVariables().getFromIndex(12).setNumber(gdjs.PreviewSceneCode.localVariables[0].getFromIndex(0).getAsNumber());
}{for(var i = 0, len = gdjs.PreviewSceneCode.GDspriteObjects2.length ;i < len;++i) {
    gdjs.PreviewSceneCode.GDspriteObjects2[i].returnVariable(gdjs.PreviewSceneCode.GDspriteObjects2[i].getVariables().get("id")).setNumber(gdjs.PreviewSceneCode.localVariables[0].getFromIndex(0).getAsNumber());
}
}{gdjs.PreviewSceneCode.localVariables[0].getFromIndex(0).add(1);
}
{ //Subevents: 
gdjs.PreviewSceneCode.eventsList5(runtimeScene);} //Subevents end.
}
}

}


};gdjs.PreviewSceneCode.eventsList7 = function(runtimeScene) {

{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("counterNMU", variable);
}
gdjs.PreviewSceneCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.PreviewSceneCode.eventsList6(runtimeScene);} //End of subevents
}
gdjs.PreviewSceneCode.localVariables.pop();

}


};gdjs.PreviewSceneCode.mapOfGDgdjs_9546PreviewSceneCode_9546GDstaticObjects4Objects = Hashtable.newFrom({"static": gdjs.PreviewSceneCode.GDstaticObjects4});
gdjs.PreviewSceneCode.mapOfGDgdjs_9546PreviewSceneCode_9546GDdynamicObjects4Objects = Hashtable.newFrom({"dynamic": gdjs.PreviewSceneCode.GDdynamicObjects4});
gdjs.PreviewSceneCode.eventsList8 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.PreviewSceneCode.GDspriteObjects3, gdjs.PreviewSceneCode.GDspriteObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PreviewSceneCode.GDspriteObjects4.length;i<l;++i) {
    if ( gdjs.PreviewSceneCode.GDspriteObjects4[i].getVariableString(gdjs.PreviewSceneCode.GDspriteObjects4[i].getVariables().get("type")) == "c" ) {
        isConditionTrue_0 = true;
        gdjs.PreviewSceneCode.GDspriteObjects4[k] = gdjs.PreviewSceneCode.GDspriteObjects4[i];
        ++k;
    }
}
gdjs.PreviewSceneCode.GDspriteObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(24404980);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.PreviewSceneCode.GDspriteObjects4 */
gdjs.PreviewSceneCode.GDstaticObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PreviewSceneCode.mapOfGDgdjs_9546PreviewSceneCode_9546GDstaticObjects4Objects, (( gdjs.PreviewSceneCode.GDspriteObjects4.length === 0 ) ? 0 :gdjs.PreviewSceneCode.GDspriteObjects4[0].getPointX("")), (( gdjs.PreviewSceneCode.GDspriteObjects4.length === 0 ) ? 0 :gdjs.PreviewSceneCode.GDspriteObjects4[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.PreviewSceneCode.GDstaticObjects4.length ;i < len;++i) {
    gdjs.PreviewSceneCode.GDstaticObjects4[i].returnVariable(gdjs.PreviewSceneCode.GDstaticObjects4[i].getVariables().getFromIndex(0)).setString(((gdjs.PreviewSceneCode.GDspriteObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.PreviewSceneCode.GDspriteObjects4[0].getVariables()).get("name").getAsString() + ((gdjs.PreviewSceneCode.GDspriteObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.PreviewSceneCode.GDspriteObjects4[0].getVariables()).get("id").getAsString());
}
}{runtimeScene.getScene().getVariables().getFromIndex(1).add(1);
}}

}


{

gdjs.copyArray(gdjs.PreviewSceneCode.GDspriteObjects3, gdjs.PreviewSceneCode.GDspriteObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PreviewSceneCode.GDspriteObjects4.length;i<l;++i) {
    if ( !(gdjs.PreviewSceneCode.GDspriteObjects4[i].getVariableString(gdjs.PreviewSceneCode.GDspriteObjects4[i].getVariables().get("type")) == "c") ) {
        isConditionTrue_0 = true;
        gdjs.PreviewSceneCode.GDspriteObjects4[k] = gdjs.PreviewSceneCode.GDspriteObjects4[i];
        ++k;
    }
}
gdjs.PreviewSceneCode.GDspriteObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PreviewSceneCode.GDspriteObjects4.length;i<l;++i) {
    if ( !(gdjs.PreviewSceneCode.GDspriteObjects4[i].getVariableString(gdjs.PreviewSceneCode.GDspriteObjects4[i].getVariables().get("type")) == "d") ) {
        isConditionTrue_0 = true;
        gdjs.PreviewSceneCode.GDspriteObjects4[k] = gdjs.PreviewSceneCode.GDspriteObjects4[i];
        ++k;
    }
}
gdjs.PreviewSceneCode.GDspriteObjects4.length = k;
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(1).add(1);
}}

}


{

gdjs.copyArray(gdjs.PreviewSceneCode.GDspriteObjects3, gdjs.PreviewSceneCode.GDspriteObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PreviewSceneCode.GDspriteObjects4.length;i<l;++i) {
    if ( gdjs.PreviewSceneCode.GDspriteObjects4[i].getVariableString(gdjs.PreviewSceneCode.GDspriteObjects4[i].getVariables().get("type")) == "d" ) {
        isConditionTrue_0 = true;
        gdjs.PreviewSceneCode.GDspriteObjects4[k] = gdjs.PreviewSceneCode.GDspriteObjects4[i];
        ++k;
    }
}
gdjs.PreviewSceneCode.GDspriteObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(24406116);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.PreviewSceneCode.GDspriteObjects4 */
gdjs.PreviewSceneCode.GDdynamicObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PreviewSceneCode.mapOfGDgdjs_9546PreviewSceneCode_9546GDdynamicObjects4Objects, (( gdjs.PreviewSceneCode.GDspriteObjects4.length === 0 ) ? 0 :gdjs.PreviewSceneCode.GDspriteObjects4[0].getPointX("")), (( gdjs.PreviewSceneCode.GDspriteObjects4.length === 0 ) ? 0 :gdjs.PreviewSceneCode.GDspriteObjects4[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.PreviewSceneCode.GDdynamicObjects4.length ;i < len;++i) {
    gdjs.PreviewSceneCode.GDdynamicObjects4[i].returnVariable(gdjs.PreviewSceneCode.GDdynamicObjects4[i].getVariables().getFromIndex(0)).setString(((gdjs.PreviewSceneCode.GDspriteObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.PreviewSceneCode.GDspriteObjects4[0].getVariables()).get("name").getAsString() + ((gdjs.PreviewSceneCode.GDspriteObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.PreviewSceneCode.GDspriteObjects4[0].getVariables()).get("id").getAsString());
}
}{runtimeScene.getScene().getVariables().getFromIndex(1).add(1);
}{for(var i = 0, len = gdjs.PreviewSceneCode.GDspriteObjects4.length ;i < len;++i) {
    gdjs.PreviewSceneCode.GDspriteObjects4[i].returnVariable(gdjs.PreviewSceneCode.GDspriteObjects4[i].getVariables().get("x")).setNumber((gdjs.PreviewSceneCode.GDspriteObjects4[i].getPointX("")));
}
}{for(var i = 0, len = gdjs.PreviewSceneCode.GDspriteObjects4.length ;i < len;++i) {
    gdjs.PreviewSceneCode.GDspriteObjects4[i].returnVariable(gdjs.PreviewSceneCode.GDspriteObjects4[i].getVariables().get("y")).setNumber((gdjs.PreviewSceneCode.GDspriteObjects4[i].getPointY("")));
}
}{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.PreviewSceneCode.GDspriteObjects4.length !== 0 ? gdjs.PreviewSceneCode.GDspriteObjects4[0] : null), (gdjs.PreviewSceneCode.GDdynamicObjects4.length !== 0 ? gdjs.PreviewSceneCode.GDdynamicObjects4[0] : null));
}}

}


};gdjs.PreviewSceneCode.userFunc0xfbedb0 = function GDJSInlineCode(runtimeScene) {
"use strict";
//functions
function setNumVar(v,n){runtimeScene.getVariables().get(v).setNumber(n)}
function getNumVar(v){return runtimeScene.getVariables().get(v).getAsNumber()}
function getObjh(vob){for (let i = 0; i < runtimeScene.getObjects("sprite").length; i++) {
    if(runtimeScene.getObjects("sprite")[i].getVariables().get("name").getAsString() === vob){
        return runtimeScene.getObjects('sprite')[i]
    }
}}
function getObj(viu){
    runtimeScene.getObjects("sprite").forEach(objf=> {if(objf.getVariables().get('name').getAsString()===viu){return objf.getVariables().get('id').getAsNumber()}})//{
    //return runtimeScene.getObjects("sprite")[runtimeScene.getObjects("sprite").forEach(objf=> objf.getVariables().get("id").getAsNumber())]
    //}
}
//const getVarNum = (name) => runtimeScene.getVariables().get(name).getNumber();


//excute script
eval(runtimeScene.getGame().getVariables().get("Script").getAsString())
};
gdjs.PreviewSceneCode.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("sprite"), gdjs.PreviewSceneCode.GDspriteObjects2);

for (gdjs.PreviewSceneCode.forEachIndex3 = 0;gdjs.PreviewSceneCode.forEachIndex3 < gdjs.PreviewSceneCode.GDspriteObjects2.length;++gdjs.PreviewSceneCode.forEachIndex3) {
gdjs.PreviewSceneCode.GDspriteObjects3.length = 0;


gdjs.PreviewSceneCode.forEachTemporary3 = gdjs.PreviewSceneCode.GDspriteObjects2[gdjs.PreviewSceneCode.forEachIndex3];
gdjs.PreviewSceneCode.GDspriteObjects3.push(gdjs.PreviewSceneCode.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.PreviewSceneCode.eventsList8(runtimeScene);} //Subevents end.
}
}

}


{


gdjs.PreviewSceneCode.userFunc0xfbedb0(runtimeScene);

}


};gdjs.PreviewSceneCode.eventsList10 = function(runtimeScene) {

{



}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Escape");
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "scene", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "a");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("dragNdrop"), gdjs.PreviewSceneCode.GDdragNdropObjects1);
{for(var i = 0, len = gdjs.PreviewSceneCode.GDdragNdropObjects1.length ;i < len;++i) {
    gdjs.PreviewSceneCode.GDdragNdropObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(24386756);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.PreviewSceneCode.eventsList3(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("debug"), gdjs.PreviewSceneCode.GDdebugObjects1);
gdjs.copyArray(runtimeScene.getObjects("sprite"), gdjs.PreviewSceneCode.GDspriteObjects1);
{for(var i = 0, len = gdjs.PreviewSceneCode.GDdebugObjects1.length ;i < len;++i) {
    gdjs.PreviewSceneCode.GDdebugObjects1[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(2).getAsString() + gdjs.evtTools.string.newLine() + runtimeScene.getScene().getVariables().getFromIndex(3).getAsString() + gdjs.evtTools.string.newLine() + ((gdjs.PreviewSceneCode.GDspriteObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.PreviewSceneCode.GDspriteObjects1[0].getVariables()).getFromIndex(0).getAsString() + " instance of sprites: " + gdjs.evtTools.common.toString(gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PreviewSceneCode.mapOfGDgdjs_9546PreviewSceneCode_9546GDspriteObjects1Objects)));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if (isConditionTrue_0) {
}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("sprite"), gdjs.PreviewSceneCode.GDspriteObjects1);

for (gdjs.PreviewSceneCode.forEachIndex2 = 0;gdjs.PreviewSceneCode.forEachIndex2 < gdjs.PreviewSceneCode.GDspriteObjects1.length;++gdjs.PreviewSceneCode.forEachIndex2) {
gdjs.PreviewSceneCode.GDspriteObjects2.length = 0;


gdjs.PreviewSceneCode.forEachTemporary2 = gdjs.PreviewSceneCode.GDspriteObjects1[gdjs.PreviewSceneCode.forEachIndex2];
gdjs.PreviewSceneCode.GDspriteObjects2.push(gdjs.PreviewSceneCode.forEachTemporary2);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.PreviewSceneCode.eventsList4(runtimeScene);} //Subevents end.
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(8).setBoolean(false);
}
{ //Subevents
gdjs.PreviewSceneCode.eventsList7(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(8), true, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.PreviewSceneCode.eventsList9(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.debuggerTools.enableDebugDraw(runtimeScene, true, false, true, true);
}}

}


};

gdjs.PreviewSceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.PreviewSceneCode.GDspriteObjects1.length = 0;
gdjs.PreviewSceneCode.GDspriteObjects2.length = 0;
gdjs.PreviewSceneCode.GDspriteObjects3.length = 0;
gdjs.PreviewSceneCode.GDspriteObjects4.length = 0;
gdjs.PreviewSceneCode.GDspriteObjects5.length = 0;
gdjs.PreviewSceneCode.GDdebugObjects1.length = 0;
gdjs.PreviewSceneCode.GDdebugObjects2.length = 0;
gdjs.PreviewSceneCode.GDdebugObjects3.length = 0;
gdjs.PreviewSceneCode.GDdebugObjects4.length = 0;
gdjs.PreviewSceneCode.GDdebugObjects5.length = 0;
gdjs.PreviewSceneCode.GDdialougObjects1.length = 0;
gdjs.PreviewSceneCode.GDdialougObjects2.length = 0;
gdjs.PreviewSceneCode.GDdialougObjects3.length = 0;
gdjs.PreviewSceneCode.GDdialougObjects4.length = 0;
gdjs.PreviewSceneCode.GDdialougObjects5.length = 0;
gdjs.PreviewSceneCode.GDobject_9595var_9595inputObjects1.length = 0;
gdjs.PreviewSceneCode.GDobject_9595var_9595inputObjects2.length = 0;
gdjs.PreviewSceneCode.GDobject_9595var_9595inputObjects3.length = 0;
gdjs.PreviewSceneCode.GDobject_9595var_9595inputObjects4.length = 0;
gdjs.PreviewSceneCode.GDobject_9595var_9595inputObjects5.length = 0;
gdjs.PreviewSceneCode.GDobjectNamesObjects1.length = 0;
gdjs.PreviewSceneCode.GDobjectNamesObjects2.length = 0;
gdjs.PreviewSceneCode.GDobjectNamesObjects3.length = 0;
gdjs.PreviewSceneCode.GDobjectNamesObjects4.length = 0;
gdjs.PreviewSceneCode.GDobjectNamesObjects5.length = 0;
gdjs.PreviewSceneCode.GDobjectNameObjects1.length = 0;
gdjs.PreviewSceneCode.GDobjectNameObjects2.length = 0;
gdjs.PreviewSceneCode.GDobjectNameObjects3.length = 0;
gdjs.PreviewSceneCode.GDobjectNameObjects4.length = 0;
gdjs.PreviewSceneCode.GDobjectNameObjects5.length = 0;
gdjs.PreviewSceneCode.GDdragNdropObjects1.length = 0;
gdjs.PreviewSceneCode.GDdragNdropObjects2.length = 0;
gdjs.PreviewSceneCode.GDdragNdropObjects3.length = 0;
gdjs.PreviewSceneCode.GDdragNdropObjects4.length = 0;
gdjs.PreviewSceneCode.GDdragNdropObjects5.length = 0;
gdjs.PreviewSceneCode.GDobj_9595scpObjects1.length = 0;
gdjs.PreviewSceneCode.GDobj_9595scpObjects2.length = 0;
gdjs.PreviewSceneCode.GDobj_9595scpObjects3.length = 0;
gdjs.PreviewSceneCode.GDobj_9595scpObjects4.length = 0;
gdjs.PreviewSceneCode.GDobj_9595scpObjects5.length = 0;
gdjs.PreviewSceneCode.GDobjectName2Objects1.length = 0;
gdjs.PreviewSceneCode.GDobjectName2Objects2.length = 0;
gdjs.PreviewSceneCode.GDobjectName2Objects3.length = 0;
gdjs.PreviewSceneCode.GDobjectName2Objects4.length = 0;
gdjs.PreviewSceneCode.GDobjectName2Objects5.length = 0;
gdjs.PreviewSceneCode.GDfake_9595cuObjects1.length = 0;
gdjs.PreviewSceneCode.GDfake_9595cuObjects2.length = 0;
gdjs.PreviewSceneCode.GDfake_9595cuObjects3.length = 0;
gdjs.PreviewSceneCode.GDfake_9595cuObjects4.length = 0;
gdjs.PreviewSceneCode.GDfake_9595cuObjects5.length = 0;
gdjs.PreviewSceneCode.GDijObjects1.length = 0;
gdjs.PreviewSceneCode.GDijObjects2.length = 0;
gdjs.PreviewSceneCode.GDijObjects3.length = 0;
gdjs.PreviewSceneCode.GDijObjects4.length = 0;
gdjs.PreviewSceneCode.GDijObjects5.length = 0;
gdjs.PreviewSceneCode.GDscrObjects1.length = 0;
gdjs.PreviewSceneCode.GDscrObjects2.length = 0;
gdjs.PreviewSceneCode.GDscrObjects3.length = 0;
gdjs.PreviewSceneCode.GDscrObjects4.length = 0;
gdjs.PreviewSceneCode.GDscrObjects5.length = 0;
gdjs.PreviewSceneCode.GDwidthObjects1.length = 0;
gdjs.PreviewSceneCode.GDwidthObjects2.length = 0;
gdjs.PreviewSceneCode.GDwidthObjects3.length = 0;
gdjs.PreviewSceneCode.GDwidthObjects4.length = 0;
gdjs.PreviewSceneCode.GDwidthObjects5.length = 0;
gdjs.PreviewSceneCode.GDheightObjects1.length = 0;
gdjs.PreviewSceneCode.GDheightObjects2.length = 0;
gdjs.PreviewSceneCode.GDheightObjects3.length = 0;
gdjs.PreviewSceneCode.GDheightObjects4.length = 0;
gdjs.PreviewSceneCode.GDheightObjects5.length = 0;
gdjs.PreviewSceneCode.GDxObjects1.length = 0;
gdjs.PreviewSceneCode.GDxObjects2.length = 0;
gdjs.PreviewSceneCode.GDxObjects3.length = 0;
gdjs.PreviewSceneCode.GDxObjects4.length = 0;
gdjs.PreviewSceneCode.GDxObjects5.length = 0;
gdjs.PreviewSceneCode.GDyObjects1.length = 0;
gdjs.PreviewSceneCode.GDyObjects2.length = 0;
gdjs.PreviewSceneCode.GDyObjects3.length = 0;
gdjs.PreviewSceneCode.GDyObjects4.length = 0;
gdjs.PreviewSceneCode.GDyObjects5.length = 0;
gdjs.PreviewSceneCode.GDNewTextObjects1.length = 0;
gdjs.PreviewSceneCode.GDNewTextObjects2.length = 0;
gdjs.PreviewSceneCode.GDNewTextObjects3.length = 0;
gdjs.PreviewSceneCode.GDNewTextObjects4.length = 0;
gdjs.PreviewSceneCode.GDNewTextObjects5.length = 0;
gdjs.PreviewSceneCode.GDerrorObjects1.length = 0;
gdjs.PreviewSceneCode.GDerrorObjects2.length = 0;
gdjs.PreviewSceneCode.GDerrorObjects3.length = 0;
gdjs.PreviewSceneCode.GDerrorObjects4.length = 0;
gdjs.PreviewSceneCode.GDerrorObjects5.length = 0;
gdjs.PreviewSceneCode.GDy2Objects1.length = 0;
gdjs.PreviewSceneCode.GDy2Objects2.length = 0;
gdjs.PreviewSceneCode.GDy2Objects3.length = 0;
gdjs.PreviewSceneCode.GDy2Objects4.length = 0;
gdjs.PreviewSceneCode.GDy2Objects5.length = 0;
gdjs.PreviewSceneCode.GDstaticObjects1.length = 0;
gdjs.PreviewSceneCode.GDstaticObjects2.length = 0;
gdjs.PreviewSceneCode.GDstaticObjects3.length = 0;
gdjs.PreviewSceneCode.GDstaticObjects4.length = 0;
gdjs.PreviewSceneCode.GDstaticObjects5.length = 0;
gdjs.PreviewSceneCode.GDdynamicObjects1.length = 0;
gdjs.PreviewSceneCode.GDdynamicObjects2.length = 0;
gdjs.PreviewSceneCode.GDdynamicObjects3.length = 0;
gdjs.PreviewSceneCode.GDdynamicObjects4.length = 0;
gdjs.PreviewSceneCode.GDdynamicObjects5.length = 0;

gdjs.PreviewSceneCode.eventsList10(runtimeScene);
gdjs.PreviewSceneCode.GDspriteObjects1.length = 0;
gdjs.PreviewSceneCode.GDspriteObjects2.length = 0;
gdjs.PreviewSceneCode.GDspriteObjects3.length = 0;
gdjs.PreviewSceneCode.GDspriteObjects4.length = 0;
gdjs.PreviewSceneCode.GDspriteObjects5.length = 0;
gdjs.PreviewSceneCode.GDdebugObjects1.length = 0;
gdjs.PreviewSceneCode.GDdebugObjects2.length = 0;
gdjs.PreviewSceneCode.GDdebugObjects3.length = 0;
gdjs.PreviewSceneCode.GDdebugObjects4.length = 0;
gdjs.PreviewSceneCode.GDdebugObjects5.length = 0;
gdjs.PreviewSceneCode.GDdialougObjects1.length = 0;
gdjs.PreviewSceneCode.GDdialougObjects2.length = 0;
gdjs.PreviewSceneCode.GDdialougObjects3.length = 0;
gdjs.PreviewSceneCode.GDdialougObjects4.length = 0;
gdjs.PreviewSceneCode.GDdialougObjects5.length = 0;
gdjs.PreviewSceneCode.GDobject_9595var_9595inputObjects1.length = 0;
gdjs.PreviewSceneCode.GDobject_9595var_9595inputObjects2.length = 0;
gdjs.PreviewSceneCode.GDobject_9595var_9595inputObjects3.length = 0;
gdjs.PreviewSceneCode.GDobject_9595var_9595inputObjects4.length = 0;
gdjs.PreviewSceneCode.GDobject_9595var_9595inputObjects5.length = 0;
gdjs.PreviewSceneCode.GDobjectNamesObjects1.length = 0;
gdjs.PreviewSceneCode.GDobjectNamesObjects2.length = 0;
gdjs.PreviewSceneCode.GDobjectNamesObjects3.length = 0;
gdjs.PreviewSceneCode.GDobjectNamesObjects4.length = 0;
gdjs.PreviewSceneCode.GDobjectNamesObjects5.length = 0;
gdjs.PreviewSceneCode.GDobjectNameObjects1.length = 0;
gdjs.PreviewSceneCode.GDobjectNameObjects2.length = 0;
gdjs.PreviewSceneCode.GDobjectNameObjects3.length = 0;
gdjs.PreviewSceneCode.GDobjectNameObjects4.length = 0;
gdjs.PreviewSceneCode.GDobjectNameObjects5.length = 0;
gdjs.PreviewSceneCode.GDdragNdropObjects1.length = 0;
gdjs.PreviewSceneCode.GDdragNdropObjects2.length = 0;
gdjs.PreviewSceneCode.GDdragNdropObjects3.length = 0;
gdjs.PreviewSceneCode.GDdragNdropObjects4.length = 0;
gdjs.PreviewSceneCode.GDdragNdropObjects5.length = 0;
gdjs.PreviewSceneCode.GDobj_9595scpObjects1.length = 0;
gdjs.PreviewSceneCode.GDobj_9595scpObjects2.length = 0;
gdjs.PreviewSceneCode.GDobj_9595scpObjects3.length = 0;
gdjs.PreviewSceneCode.GDobj_9595scpObjects4.length = 0;
gdjs.PreviewSceneCode.GDobj_9595scpObjects5.length = 0;
gdjs.PreviewSceneCode.GDobjectName2Objects1.length = 0;
gdjs.PreviewSceneCode.GDobjectName2Objects2.length = 0;
gdjs.PreviewSceneCode.GDobjectName2Objects3.length = 0;
gdjs.PreviewSceneCode.GDobjectName2Objects4.length = 0;
gdjs.PreviewSceneCode.GDobjectName2Objects5.length = 0;
gdjs.PreviewSceneCode.GDfake_9595cuObjects1.length = 0;
gdjs.PreviewSceneCode.GDfake_9595cuObjects2.length = 0;
gdjs.PreviewSceneCode.GDfake_9595cuObjects3.length = 0;
gdjs.PreviewSceneCode.GDfake_9595cuObjects4.length = 0;
gdjs.PreviewSceneCode.GDfake_9595cuObjects5.length = 0;
gdjs.PreviewSceneCode.GDijObjects1.length = 0;
gdjs.PreviewSceneCode.GDijObjects2.length = 0;
gdjs.PreviewSceneCode.GDijObjects3.length = 0;
gdjs.PreviewSceneCode.GDijObjects4.length = 0;
gdjs.PreviewSceneCode.GDijObjects5.length = 0;
gdjs.PreviewSceneCode.GDscrObjects1.length = 0;
gdjs.PreviewSceneCode.GDscrObjects2.length = 0;
gdjs.PreviewSceneCode.GDscrObjects3.length = 0;
gdjs.PreviewSceneCode.GDscrObjects4.length = 0;
gdjs.PreviewSceneCode.GDscrObjects5.length = 0;
gdjs.PreviewSceneCode.GDwidthObjects1.length = 0;
gdjs.PreviewSceneCode.GDwidthObjects2.length = 0;
gdjs.PreviewSceneCode.GDwidthObjects3.length = 0;
gdjs.PreviewSceneCode.GDwidthObjects4.length = 0;
gdjs.PreviewSceneCode.GDwidthObjects5.length = 0;
gdjs.PreviewSceneCode.GDheightObjects1.length = 0;
gdjs.PreviewSceneCode.GDheightObjects2.length = 0;
gdjs.PreviewSceneCode.GDheightObjects3.length = 0;
gdjs.PreviewSceneCode.GDheightObjects4.length = 0;
gdjs.PreviewSceneCode.GDheightObjects5.length = 0;
gdjs.PreviewSceneCode.GDxObjects1.length = 0;
gdjs.PreviewSceneCode.GDxObjects2.length = 0;
gdjs.PreviewSceneCode.GDxObjects3.length = 0;
gdjs.PreviewSceneCode.GDxObjects4.length = 0;
gdjs.PreviewSceneCode.GDxObjects5.length = 0;
gdjs.PreviewSceneCode.GDyObjects1.length = 0;
gdjs.PreviewSceneCode.GDyObjects2.length = 0;
gdjs.PreviewSceneCode.GDyObjects3.length = 0;
gdjs.PreviewSceneCode.GDyObjects4.length = 0;
gdjs.PreviewSceneCode.GDyObjects5.length = 0;
gdjs.PreviewSceneCode.GDNewTextObjects1.length = 0;
gdjs.PreviewSceneCode.GDNewTextObjects2.length = 0;
gdjs.PreviewSceneCode.GDNewTextObjects3.length = 0;
gdjs.PreviewSceneCode.GDNewTextObjects4.length = 0;
gdjs.PreviewSceneCode.GDNewTextObjects5.length = 0;
gdjs.PreviewSceneCode.GDerrorObjects1.length = 0;
gdjs.PreviewSceneCode.GDerrorObjects2.length = 0;
gdjs.PreviewSceneCode.GDerrorObjects3.length = 0;
gdjs.PreviewSceneCode.GDerrorObjects4.length = 0;
gdjs.PreviewSceneCode.GDerrorObjects5.length = 0;
gdjs.PreviewSceneCode.GDy2Objects1.length = 0;
gdjs.PreviewSceneCode.GDy2Objects2.length = 0;
gdjs.PreviewSceneCode.GDy2Objects3.length = 0;
gdjs.PreviewSceneCode.GDy2Objects4.length = 0;
gdjs.PreviewSceneCode.GDy2Objects5.length = 0;
gdjs.PreviewSceneCode.GDstaticObjects1.length = 0;
gdjs.PreviewSceneCode.GDstaticObjects2.length = 0;
gdjs.PreviewSceneCode.GDstaticObjects3.length = 0;
gdjs.PreviewSceneCode.GDstaticObjects4.length = 0;
gdjs.PreviewSceneCode.GDstaticObjects5.length = 0;
gdjs.PreviewSceneCode.GDdynamicObjects1.length = 0;
gdjs.PreviewSceneCode.GDdynamicObjects2.length = 0;
gdjs.PreviewSceneCode.GDdynamicObjects3.length = 0;
gdjs.PreviewSceneCode.GDdynamicObjects4.length = 0;
gdjs.PreviewSceneCode.GDdynamicObjects5.length = 0;


return;

}

gdjs['PreviewSceneCode'] = gdjs.PreviewSceneCode;
