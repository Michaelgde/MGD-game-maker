gdjs.g2Code = {};
gdjs.g2Code.localVariables = [];
gdjs.g2Code.GDNewSpriteObjects1= [];
gdjs.g2Code.GDNewSpriteObjects2= [];
gdjs.g2Code.GDNewSpriteObjects3= [];
gdjs.g2Code.GDNewSpriteObjects4= [];
gdjs.g2Code.GDNewSpriteObjects5= [];
gdjs.g2Code.GDdebugerObjects1= [];
gdjs.g2Code.GDdebugerObjects2= [];
gdjs.g2Code.GDdebugerObjects3= [];
gdjs.g2Code.GDdebugerObjects4= [];
gdjs.g2Code.GDdebugerObjects5= [];
gdjs.g2Code.GDeeObjects1= [];
gdjs.g2Code.GDeeObjects2= [];
gdjs.g2Code.GDeeObjects3= [];
gdjs.g2Code.GDeeObjects4= [];
gdjs.g2Code.GDeeObjects5= [];


gdjs.g2Code.userFunc0xf409d8 = function GDJSInlineCode(runtimeScene) {
"use strict";
var platformerBehavior = {
    "acceleration": 1500,
    "canGoDownFromJumpthru": true,
    "canGrabPlatforms": false,
    "canGrabWithoutMoving": true,
    "deceleration": 1500,
    "gravity": 1000,
    "ignoreDefaultControls": false,
    "jumpSpeed": 600,
    "jumpSustainTime": 0.2,
    "ladderClimbingSpeed": 150,
    "maxFallingSpeed": 700,
    "maxSpeed": 250,
    "name": "PlatformerObject",
    "slopeMaxAngle": 60,
    "type": "PlatformBehavior::PlatformerObjectBehavior",
    "useLegacyTrajectory": false,
    "xGrabTolerance": 10,
    "yGrabOffset": 0
}
var platform = {
    "canBeGrabbed": false,
    "name": "Platform",
    "platformType": "NormalPlatform",
    "type": "PlatformBehavior::PlatformBehavior",
    "yGrabOffset": 0
}

var obj = runtimeScene.getGame().getVariables().get('objectList').getChildAt(runtimeScene.getVariables().get('index').getAsNumber()).getAsString()
var prop = runtimeScene.getGame().getVariables().get("PerObjectProperties").getChildNamed(obj)
var re = runtimeScene.getGame().getVariables().get("re2").getChildNamed('images').getChildNamed(obj).getAsString()
var p1= {"x":prop.getChildNamed("p1").getChildNamed("x").getAsNumber(),"y":prop.getChildNamed("p1").getChildNamed("y").getAsNumber()}
var p2= {"x":prop.getChildNamed("p2").getChildNamed("x").getAsNumber(),"y":prop.getChildNamed("p2").getChildNamed("y").getAsNumber()}
var p3= {"x":prop.getChildNamed("p3").getChildNamed("x").getAsNumber(),"y":prop.getChildNamed("p3").getChildNamed("y").getAsNumber()}
var p4= {"x":prop.getChildNamed("p4").getChildNamed("x").getAsNumber(),"y":prop.getChildNamed("p4").getChildNamed("y").getAsNumber()}



function register(name,p1x,p1y,p2x,p2y,p3x,p3y,p4x,p4y,urlj){
    var behave = [
        {
            "name": "Animation",
            "type": "AnimatableCapability::AnimatableBehavior"
        },
        {
            "name": "Effect",
            "type": "EffectCapability::EffectBehavior"
        },
        {
            "name": "Flippable",
            "type": "FlippableCapability::FlippableBehavior"
        },
        {
            "name": "Opacity",
            "type": "OpacityCapability::OpacityBehavior"
        },
        {
            "name": "Resizable",
            "type": "ResizableCapability::ResizableBehavior"
        },
        {
            "name": "Scale",
            "type": "ScalableCapability::ScalableBehavior"
        },
        {
            "name": "urlChange",
            "type": "costom_objects::urlChange",
            "url": urlj,
            "width": 32,
            "height": 32
        }
    ]


    if( prop.getChildNamed('behavior').getAsString() === 'platformer'){
        behave.push(platformerBehavior)
    }
    if( prop.getChildNamed('behavior').getAsString() === 'platform'){
        behave.push(platform)
    }


    runtimeScene.registerObject({
    "adaptCollisionMaskAutomatically": true,
    "assetStoreId": "",
    "name": name,
    "type": "Sprite",
    "updateIfNotVisible": false,
    "variables": [],
    "effects": [],
    "behaviors": behave,
    "animations": [
        {
            "name": "",
            "useMultipleDirections": false,
            "directions": [
                {
                    "looping": false,
                    "timeBetweenFrames": 0.08,
                    "sprites": [
                        {
                            "hasCustomCollisionMask": true,
                            "image": "assets\\sprite.png",
                            "points": [],
                            "originPoint": {
                                "name": "origine",
                                "x": 0,
                                "y": 0
                            },
                            "centerPoint": {
                                "automatic": true,
                                "name": "centre",
                                "x": 0,
                                "y": 0
                            },
                            "customCollisionMask": [
                                [
                                    {
                                        "x": 0,
                                        "y": 0
                                    },
                                    {
                                        "x": p2x - p1x,
                                        "y": 0
                                    },
                                    {
                                        "x": p2x - p1x,
                                        "y": p4y - p2y
                                    },
                                    {
                                        "x": 0,
                                        "y": p4y - p2y
                                    }
                                ]
                            ]
                        }
                    ]
                }
            ]
        }
    ]
})
}




register(obj,p1.x,p1.y,p2.x,p2.y,p3.x,p3.y,p4.x,p4.y,re)
console.log('width: '+prop.getChildNamed("width").getAsNumber()+' height: '+prop.getChildNamed('height').getAsNumber()+' dataUrl='+re)
runtimeScene.getVariables().get('index').add(1)

};
gdjs.g2Code.eventsList0 = function(runtimeScene) {

{


gdjs.g2Code.userFunc0xf409d8(runtimeScene);

}


};gdjs.g2Code.eventsList1 = function(runtimeScene) {

};gdjs.g2Code.eventsList2 = function(runtimeScene) {

{


const repeatCount3 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(2));
for (let repeatIndex3 = 0;repeatIndex3 < repeatCount3;++repeatIndex3) {

let isConditionTrue_0 = false;
if (true)
{

{ //Subevents: 
gdjs.g2Code.eventsList0(runtimeScene);} //Subevents end.
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
{
}

}


{


gdjs.g2Code.eventsList1(runtimeScene);
}


{



}


};gdjs.g2Code.eventsList3 = function(runtimeScene) {

};gdjs.g2Code.eventsList4 = function(runtimeScene) {

{


const keyIteratorReference5 = runtimeScene.getScene().getVariables().getFromIndex(12);
const valueIteratorReference5 = runtimeScene.getScene().getVariables().getFromIndex(11);
const iterableReference5 = runtimeScene.getGame().getVariables().getFromIndex(7).getChild(runtimeScene.getGame().getVariables().getFromIndex(1).getChild(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() - 1).getChild("name").getAsNumberOrString());
if(!iterableReference5.isPrimitive()) {
for(
    const iteratorKey5 in 
    iterableReference5.getType() === "structure"
      ? iterableReference5.getAllChildren()
      : iterableReference5.getType() === "array"
        ? iterableReference5.getAllChildrenArray()
        : []
) {
    if(iterableReference5.getType() === "structure")
        keyIteratorReference5.setString(iteratorKey5);
    else if(iterableReference5.getType() === "array")
        keyIteratorReference5.setNumber(iteratorKey5);
    const structureChildVariable5 = iterableReference5.getChild(iteratorKey5)
    valueIteratorReference5.castTo(structureChildVariable5.getType())
    if(structureChildVariable5.isPrimitive()) {
        valueIteratorReference5.setValue(structureChildVariable5.getValue());
    } else if (structureChildVariable5.getType() === "structure") {
        // Structures are passed by reference like JS objects
        valueIteratorReference5.replaceChildren(structureChildVariable5.getAllChildren());
    } else if (structureChildVariable5.getType() === "array") {
        // Arrays are passed by reference like JS objects
        valueIteratorReference5.replaceChildrenArray(structureChildVariable5.getAllChildrenArray());
    } else console.warn("Cannot identify type: ", type);

let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtsExt__UntitledExtension__resixe.func(runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(1).getChild(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() - 1).getChild("name").getAsString(), runtimeScene.getGame().getVariables().getFromIndex(1).getChild(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() - 1).getChild("height").getAsNumber(), runtimeScene.getGame().getVariables().getFromIndex(1).getChild(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() - 1).getChild("width").getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(12).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1).getChild(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber()).getChild("name")) != gdjs.g2Code.localVariables[0].getFromIndex(1).getAsString();
if (isConditionTrue_0) {
{gdjs.g2Code.localVariables[0].getFromIndex(0).setNumber(0);
}}

}


};gdjs.g2Code.eventsList5 = function(runtimeScene) {

{


const repeatCount3 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(1));
for (let repeatIndex3 = 0;repeatIndex3 < repeatCount3;++repeatIndex3) {

let isConditionTrue_0 = false;
if (true)
{
{gdjs.g2Code.localVariables[0].getFromIndex(1).setString(runtimeScene.getGame().getVariables().getFromIndex(1).getChild(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber()).getChild("name").getAsString());
}{runtimeScene.getScene().getVariables().getFromIndex(2).add(1);
}{gdjs.g2Code.localVariables[0].getFromIndex(0).add(1);
}
{ //Subevents: 
gdjs.g2Code.eventsList4(runtimeScene);} //Subevents end.
}
}

}


};gdjs.g2Code.eventsList6 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22269292);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.g2Code.eventsList5(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) >= gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(1));
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(6).setNumber(1);
}}

}


};gdjs.g2Code.eventsList7 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) >= gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(1));
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(4).setBoolean(true);
}{runtimeScene.getScene().getVariables().getFromIndex(8).concatenateString("\nbo.setNumber(-2)\nconsole.log('done')");
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(-(1));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1).getChild(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber()).getChild("name")) != gdjs.g2Code.localVariables[0].getFromIndex(1).getAsString();
if (isConditionTrue_0) {
{gdjs.g2Code.localVariables[0].getFromIndex(0).setNumber(0);
}}

}


};gdjs.g2Code.eventsList8 = function(runtimeScene) {

{


const repeatCount2 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(1));
for (let repeatIndex2 = 0;repeatIndex2 < repeatCount2;++repeatIndex2) {

let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtsExt__UntitledExtension__create2.func(runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(1).getChild(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber()).getChild("name").getAsString(), runtimeScene.getGame().getVariables().getFromIndex(1).getChild(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber()).getChild("x").getAsNumber(), runtimeScene.getGame().getVariables().getFromIndex(1).getChild(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber()).getChild("y").getAsNumber(), gdjs.g2Code.localVariables[0].getFromIndex(0).getAsNumber(), runtimeScene.getGame().getVariables().getFromIndex(1).getChild(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber()).getChild("width").getAsNumber(), runtimeScene.getGame().getVariables().getFromIndex(1).getChild(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber()).getChild("height").getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.g2Code.localVariables[0].getFromIndex(1).setString(runtimeScene.getGame().getVariables().getFromIndex(1).getChild(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber()).getChild("name").getAsString());
}{runtimeScene.getScene().getVariables().getFromIndex(2).add(1);
}{gdjs.g2Code.localVariables[0].getFromIndex(0).add(1);
}
{ //Subevents: 
gdjs.g2Code.eventsList7(runtimeScene);} //Subevents end.
}
}

}


};gdjs.g2Code.userFunc0xfc1770 = function GDJSInlineCode(runtimeScene) {
"use strict";
function object(name){return runtimeScene.getObjects(name)}; function sceneVar(name){return runtimeScene.getVariables().get(name)}



};
gdjs.g2Code.userFunc0xfc1a00 = function GDJSInlineCode(runtimeScene) {
"use strict";
function object(name){return runtimeScene.getObjects(name)}; function sceneVar(name){return runtimeScene.getVariables().get(name)}

var Num1 = 49
var Num2 = 50
var Num3 = 51
var Num4 = 52
var Num5 = 53
var Num6 = 54
var Num7 = 55
var Num8 = 56
var Num9 = 57
var Num0 = 48
var q = 81
var w = 87
var e = 69
var r = 82
var t = 84
var y = 89
var u = 85
var i = 73
var o = 79
var p = 80
var a = 65
var s = 83
var d = 68
var f = 70
var g = 71
var h = 72
var j = 74
var k = 75
var l = 76
var z = 90
var x = 88
var c = 67
var v = 86
var b = 66
var n = 78
var m = 77
var Space = 32
var Left = 37
var Right = 39
var Up = 38
var Down = 40
var RShift = 2016
var LShift = 1016
var Return = 13
var Back = 8
var Equal = 187
var Dash = 189
var F1 = 112
var F2 = 113
var F3 = 114
var F4 = 115
var F5 = 116
var F6 = 117
var F7 = 118
var F8 = 119
var F9 = 120
var F10 = 121
var F11 = 122
var F12 = 123

function registerTxt(na,bold,italic){
    runtimeScene.registerObject({
    "assetStoreId": "",
    "bold": bold,
    "italic": italic,
    "name": na,
    "smoothed": true,
    "type": "TextObject::Text",
    "underlined": false,
    "variables": [],
    "effects": [],
    "behaviors": [
        {
            "name": "Effect",
            "type": "EffectCapability::EffectBehavior"
        },
        {
            "name": "Opacity",
            "type": "OpacityCapability::OpacityBehavior"
        },
        {
            "name": "Scale",
            "type": "ScalableCapability::ScalableBehavior"
        },
        {
            "name": "Text",
            "type": "TextContainerCapability::TextContainerBehavior"
        }
    ],
    "string": "Text",
    "font": "",
    "textAlignment": "left",
    "characterSize": 20,
    "color": {
        "b": 0,
        "g": 0,
        "r": 0
    },
    "content": {
        "bold": false,
        "isOutlineEnabled": false,
        "isShadowEnabled": false,
        "italic": false,
        "outlineColor": "255;255;255",
        "outlineThickness": 2,
        "shadowAngle": 90,
        "shadowBlurRadius": 2,
        "shadowColor": "0;0;0",
        "shadowDistance": 4,
        "shadowOpacity": 127,
        "smoothed": true,
        "underlined": false,
        "text": "Text",
        "font": "",
        "textAlignment": "left",
        "verticalTextAlignment": "top",
        "characterSize": 20,
        "color": "0;0;0"
    }
})
}

function keyPressed(code){
    return runtimeScene.getGame().getInputManager().isKeyPressed(code)
}
function seperate(a,b,id){runtimeScene.getObjects(a)[id].separateFromObjects(runtimeScene.getObjects(b))}
function isCollidingWith(a,b,t){
    return gdjs.RuntimeObject.collisionTest(a,b,t)
}
var bo = runtimeScene.getVariables().get('bo');
//eval(runtimeScene.getVariables().get('TempScript').getAsString())

function executeLoop(){
    try {
        eval(runtimeScene.getGame().getVariables().get('Script').getAsString());
        if(runtimeScene.getVariables().get('error').getAsString().concat('Error executing script:')){
            runtimeScene.getVariables().get('error').setString('')
        }
    } catch (e) {
        runtimeScene.getVariables().get('error').setString("Error executing script: "+ e);
    }
    requestAnimationFrame(executeLoop)
}
executeLoop()

};
gdjs.g2Code.eventsList9 = function(runtimeScene) {

{


gdjs.g2Code.userFunc0xfc1a00(runtimeScene);

}


};gdjs.g2Code.userFunc0xfc1c60 = function GDJSInlineCode(runtimeScene) {
"use strict";
var ar = []
ar = runtimeScene.getGame().getVariables().get('objectList').toJSObject()
ar.forEach(list=> runtimeScene.getObjects(list).forEach(obj=>{
    obj.setWidth(obj.getVariables().get('width').getAsNumber())
    obj.setHeight(obj.getVariables().get('height').getAsNumber())
    runtimeScene.getGame().getVariables().get('listOfInstance').sub(1)
}))
console.log(ar)

};
gdjs.g2Code.eventsList10 = function(runtimeScene) {

{


gdjs.g2Code.userFunc0xfc1c60(runtimeScene);

}


};gdjs.g2Code.eventsList11 = function(runtimeScene) {

{


gdjs.g2Code.userFunc0xfc1770(runtimeScene);

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22295340);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.g2Code.eventsList9(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(9)) > -(1);
if (isConditionTrue_0) {

{ //Subevents
gdjs.g2Code.eventsList10(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.g2Code.eventsList12 = function(runtimeScene) {

{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setString("");
variables._declare("json", variable);
}
gdjs.g2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(11).setBoolean(true);
}
{ //Subevents
gdjs.g2Code.eventsList2(runtimeScene);} //End of subevents
}
gdjs.g2Code.localVariables.pop();

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) == gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(2));
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(3).setBoolean(true);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(4), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(6)) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22267484);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(0);
}}

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("counter19", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("");
variables._declare("checkName", variable);
}
gdjs.g2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(4), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(6)) == 0;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.g2Code.eventsList6(runtimeScene);} //End of subevents
}
gdjs.g2Code.localVariables.pop();

}


{



}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("counter19", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("");
variables._declare("checkName", variable);
}
gdjs.g2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(3), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(4), false, false);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.g2Code.eventsList8(runtimeScene);} //End of subevents
}
gdjs.g2Code.localVariables.pop();

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(4), true, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.g2Code.eventsList11(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen(runtimeScene.getScene().getVariables().getFromIndex(13).getAsString()) > 2);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ee"), gdjs.g2Code.GDeeObjects1);
{gdjs.evtTools.camera.showLayer(runtimeScene, "error");
}{for(var i = 0, len = gdjs.g2Code.GDeeObjects1.length ;i < len;++i) {
    gdjs.g2Code.GDeeObjects1[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(13).getAsString());
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen(runtimeScene.getScene().getVariables().getFromIndex(13).getAsString()) < 2);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ee"), gdjs.g2Code.GDeeObjects1);
{gdjs.evtTools.camera.hideLayer(runtimeScene, "error");
}{for(var i = 0, len = gdjs.g2Code.GDeeObjects1.length ;i < len;++i) {
    gdjs.g2Code.GDeeObjects1[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(13).getAsString());
}
}}

}


};

gdjs.g2Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.g2Code.GDNewSpriteObjects1.length = 0;
gdjs.g2Code.GDNewSpriteObjects2.length = 0;
gdjs.g2Code.GDNewSpriteObjects3.length = 0;
gdjs.g2Code.GDNewSpriteObjects4.length = 0;
gdjs.g2Code.GDNewSpriteObjects5.length = 0;
gdjs.g2Code.GDdebugerObjects1.length = 0;
gdjs.g2Code.GDdebugerObjects2.length = 0;
gdjs.g2Code.GDdebugerObjects3.length = 0;
gdjs.g2Code.GDdebugerObjects4.length = 0;
gdjs.g2Code.GDdebugerObjects5.length = 0;
gdjs.g2Code.GDeeObjects1.length = 0;
gdjs.g2Code.GDeeObjects2.length = 0;
gdjs.g2Code.GDeeObjects3.length = 0;
gdjs.g2Code.GDeeObjects4.length = 0;
gdjs.g2Code.GDeeObjects5.length = 0;

gdjs.g2Code.eventsList12(runtimeScene);
gdjs.g2Code.GDNewSpriteObjects1.length = 0;
gdjs.g2Code.GDNewSpriteObjects2.length = 0;
gdjs.g2Code.GDNewSpriteObjects3.length = 0;
gdjs.g2Code.GDNewSpriteObjects4.length = 0;
gdjs.g2Code.GDNewSpriteObjects5.length = 0;
gdjs.g2Code.GDdebugerObjects1.length = 0;
gdjs.g2Code.GDdebugerObjects2.length = 0;
gdjs.g2Code.GDdebugerObjects3.length = 0;
gdjs.g2Code.GDdebugerObjects4.length = 0;
gdjs.g2Code.GDdebugerObjects5.length = 0;
gdjs.g2Code.GDeeObjects1.length = 0;
gdjs.g2Code.GDeeObjects2.length = 0;
gdjs.g2Code.GDeeObjects3.length = 0;
gdjs.g2Code.GDeeObjects4.length = 0;
gdjs.g2Code.GDeeObjects5.length = 0;


return;

}

gdjs['g2Code'] = gdjs.g2Code;
